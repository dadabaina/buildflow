<?php $__env->startSection('title', 'Alerts - UI elements'); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-6 mb-6">
    <!-- Basic Alerts -->
    <div class="col-md">
        <div class="card">
            <h5 class="card-header">Basic Alerts</h5>
            <div class="card-body">
                <div class="alert alert-primary" role="alert">This is a primary alert — check it out!</div>

                <div class="alert alert-secondary" role="alert">This is a secondary alert — check it out!</div>

                <div class="alert alert-success" role="alert">This is a success alert — check it out!</div>

                <div class="alert alert-danger" role="alert">This is a danger alert — check it out!</div>

                <div class="alert alert-warning" role="alert">This is a warning alert — check it out!</div>

                <div class="alert alert-info" role="alert">This is an info alert — check it out!</div>

                <div class="alert alert-dark mb-0" role="alert">This is a dark alert — check it out!</div>
            </div>
        </div>
    </div>
    <!--/ Basic Alerts -->
    <!-- Dismissible Alerts -->
    <div class="col-md">
        <div class="card">
            <h5 class="card-header">Dismissible Alerts</h5>
            <div class="card-body">
                <div class="alert alert-primary alert-dismissible" role="alert">
                    This is a primary dismissible alert — check it out!
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>

                <div class="alert alert-secondary alert-dismissible" role="alert">
                    This is a secondary dismissible alert — check it out!
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>

                <div class="alert alert-success alert-dismissible" role="alert">
                    This is a success dismissible alert — check it out!
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>

                <div class="alert alert-danger alert-dismissible" role="alert">
                    This is a danger dismissible alert — check it out!
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>

                <div class="alert alert-warning alert-dismissible" role="alert">
                    This is a warning dismissible alert — check it out!
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>

                <div class="alert alert-info alert-dismissible" role="alert">
                    This is an info dismissible alert — check it out!
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>

                <div class="alert alert-dark alert-dismissible mb-0" role="alert">
                    This is a dark dismissible alert — check it out!
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </div>
        </div>
    </div>
    <!--/ Dismissible Alerts -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sneat\free-laravel-internal\full-version\resources\views/content/user-interface/ui-alerts.blade.php ENDPATH**/ ?>