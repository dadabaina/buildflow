<x-layouts.app :title="$client->name">
    <x-slot name="breadcrumb">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Accueil</a></li>
                <li class="breadcrumb-item"><a href="{{ route('clients.index') }}">Clients</a></li>
                <li class="breadcrumb-item active">{{ $client->name }}</li>
            </ol>
        </nav>
    </x-slot>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h5 class="mb-0 fw-bold">{{ $client->name }}</h5>
        <div class="d-flex gap-2">
            @can('clients.edit')
            <a href="{{ route('clients.edit', $client) }}" class="btn btn-primary btn-sm">
                <i class="bi bi-pencil me-1"></i>Modifier
            </a>
            @endcan
            @can('clients.delete')
            <form method="POST" action="{{ route('clients.destroy', $client) }}"
                  onsubmit="return confirm('Supprimer ce client ?')">
                @csrf @method('DELETE')
                <button class="btn btn-outline-danger btn-sm">
                    <i class="bi bi-trash me-1"></i>Supprimer
                </button>
            </form>
            @endcan
        </div>
    </div>

    <div class="row g-4">
        <div class="col-md-5">
            <div class="card">
                <div class="card-header">
                    <h6 class="mb-0 fw-semibold">Informations</h6>
                </div>
                <div class="card-body">
                    <dl class="row mb-0">
                        <dt class="col-sm-4 text-muted small">Type</dt>
                        <dd class="col-sm-8">{{ ucfirst($client->type) }}</dd>

                        <dt class="col-sm-4 text-muted small">Téléphone</dt>
                        <dd class="col-sm-8">{{ $client->phone ?? '—' }}</dd>

                        <dt class="col-sm-4 text-muted small">Email</dt>
                        <dd class="col-sm-8">{{ $client->email ?? '—' }}</dd>

                        <dt class="col-sm-4 text-muted small">Adresse</dt>
                        <dd class="col-sm-8">
                            {{ $client->address ?? '' }}
                            {{ $client->city ? ', '.$client->city : '' }}
                        </dd>

                        <dt class="col-sm-4 text-muted small">Région</dt>
                        <dd class="col-sm-8">{{ $client->region?->name ?? '—' }}</dd>

                        <dt class="col-sm-4 text-muted small">NIF</dt>
                        <dd class="col-sm-8">{{ $client->nif ?? '—' }}</dd>

                        <dt class="col-sm-4 text-muted small">STAT</dt>
                        <dd class="col-sm-8">{{ $client->stat ?? '—' }}</dd>

                        <dt class="col-sm-4 text-muted small">RCS</dt>
                        <dd class="col-sm-8">{{ $client->rcs ?? '—' }}</dd>

                        @if($client->notes)
                        <dt class="col-sm-4 text-muted small">Notes</dt>
                        <dd class="col-sm-8">{{ $client->notes }}</dd>
                        @endif
                    </dl>
                </div>
            </div>
        </div>

        <div class="col-md-7">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h6 class="mb-0 fw-semibold">Chantiers</h6>
                    <a href="{{ route('projects.index', ['client_id' => $client->id]) }}"
                       class="btn btn-sm btn-outline-primary">Voir tout</a>
                </div>
                <div class="table-responsive">
                    <table class="table table-sm mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Chantier</th>
                                <th>Statut</th>
                                <th>Début</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($client->projects->take(8) as $project)
                            <tr>
                                <td>
                                    <a href="{{ route('projects.show', $project) }}" class="text-decoration-none small">
                                        {{ $project->name }}
                                    </a>
                                </td>
                                <td>
                                    <span class="badge {{ $project->status_badge_class }} small">
                                        {{ $project->status_libelle }}
                                    </span>
                                </td>
                                <td class="text-muted small">{{ $project->start_date?->format('d/m/Y') ?? '—' }}</td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="3" class="text-muted text-center py-2 small">Aucun chantier</td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</x-layouts.app>
