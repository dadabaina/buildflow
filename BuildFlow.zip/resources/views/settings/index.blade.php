<x-layouts.app title="Paramètres Système">
    <x-slot name="breadcrumb">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="{{ route('dashboard') }}" class="text-decoration-none opacity-50 text-dark">Accueil</a></li>
                <li class="breadcrumb-item active fw-bold text-dark">Paramètres</li>
            </ol>
        </nav>
    </x-slot>

    <div class="mb-4">
        <h3 class="fw-bold text-dark mb-1">Paramètres</h3>
        <p class="text-secondary small">Configurez votre entreprise et personnalisez votre espace de travail.</p>
    </div>

    <div class="row g-4" x-data="{ 
            activeTab: window.location.hash ? window.location.hash.substring(1) : (localStorage.getItem('settingsTab') || 'entreprise') 
         }" 
         x-init="
            $watch('activeTab', value => {
                localStorage.setItem('settingsTab', value);
                window.location.hash = value;
            });
            window.addEventListener('set-tab', (e) => activeTab = e.detail);
         ">
        
        {{-- Navigation Verticale --}}
        <div class="col-lg-3">
            <div class="card border-0 shadow-sm-app rounded-4 p-3 bg-white sticky-top" style="top: 90px; z-index: 100;">
                <nav class="nav flex-column settings-nav">
                    <button class="nav-link" :class="{ 'active': activeTab === 'entreprise' }" @click="activeTab = 'entreprise'">
                        <i class="bi bi-building"></i> <span>Entreprise</span>
                    </button>
                    <button class="nav-link" :class="{ 'active': activeTab === 'regions' }" @click="activeTab = 'regions'">
                        <i class="bi bi-geo-alt"></i> <span>Régions</span>
                    </button>
                    <button class="nav-link" :class="{ 'active': activeTab === 'metiers' }" @click="activeTab = 'metiers'">
                        <i class="bi bi-person-badge"></i> <span>Postes & Fonctions</span>
                    </button>
                    <button class="nav-link" :class="{ 'active': activeTab === 'unites' }" @click="activeTab = 'unites'">
                        <i class="bi bi-rulers"></i> <span>Unités de mesure</span>
                    </button>
                    <button class="nav-link" :class="{ 'active': activeTab === 'categories' }" @click="activeTab = 'categories'">
                        <i class="bi bi-tags"></i> <span>Catégories dépenses</span>
                    </button>
                    <button class="nav-link" :class="{ 'active': activeTab === 'salaires' }" @click="activeTab = 'salaires'">
                        <i class="bi bi-currency-dollar"></i> <span>Grille salariale</span>
                    </button>
                    <button class="nav-link" :class="{ 'active': activeTab === 'mat_categories' }" @click="activeTab = 'mat_categories'">
                        <i class="bi bi-boxes"></i> <span>Catégories matériaux</span>
                    </button>
                </nav>
            </div>
        </div>

        {{-- Contenu des onglets --}}
        <div class="col-lg-9">
            
            {{-- Onglet Entreprise --}}
            <div x-show="activeTab === 'entreprise'" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform translate-y-2">
                <x-card title="Informations de l'entreprise" subtitle="Ces informations apparaîtront sur vos documents officiels (devis, factures).">
                    <form method="POST" action="{{ route('settings.company') }}">
                        @csrf @method('PATCH')
                        <div class="row g-4">
                            <div class="col-md-8">
                                <label class="form-label fw-semibold text-dark small">Nom de l'entreprise <span class="text-danger">*</span></label>
                                <input type="text" name="name" class="form-control" value="{{ old('name', $company->name) }}" required placeholder="Ex: BuildFlow Madagascar">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold text-dark small">TVA par défaut (%)</label>
                                <div class="input-group">
                                    <input type="number" name="tva_rate" class="form-control" step="0.01" value="{{ old('tva_rate', $company->tva_rate ?? 20) }}">
                                    <span class="input-group-text bg-light">%</span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold text-dark small">Email de contact</label>
                                <input type="email" name="email" class="form-control" value="{{ old('email', $company->email) }}" placeholder="contact@entreprise.mg">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold text-dark small">Téléphone</label>
                                <input type="text" name="phone" class="form-control" value="{{ old('phone', $company->phone) }}" placeholder="+261 ...">
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-semibold text-dark small">Adresse du siège</label>
                                <textarea name="address" class="form-control" rows="2" placeholder="Numéro, Rue, Ville...">{{ old('address', $company->address) }}</textarea>
                            </div>
                            
                            <div class="col-12 mt-4">
                                <h6 class="text-secondary text-uppercase fw-bold mb-3" style="font-size: 0.75rem; letter-spacing: 0.1em;">Identifiants Fiscaux</h6>
                                <div class="row g-3">
                                    <div class="col-md-4">
                                        <label class="form-label fw-semibold text-dark small">NIF</label>
                                        <input type="text" name="nif" class="form-control" value="{{ old('nif', $company->nif) }}">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label fw-semibold text-dark small">STAT</label>
                                        <input type="text" name="stat" class="form-control" value="{{ old('stat', $company->stat) }}">
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label fw-semibold text-dark small">RCS</label>
                                        <input type="text" name="rcs" class="form-control" value="{{ old('rcs', $company->rcs) }}">
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 mt-4">
                                <h6 class="text-secondary text-uppercase fw-bold mb-3" style="font-size: 0.75rem; letter-spacing: 0.1em;">Préfixes de numérotation</h6>
                                <div class="row g-3">
                                    <div class="col-md-3">
                                        <label class="form-label fw-semibold text-dark small">Devis</label>
                                        <input type="text" name="quote_prefix" class="form-control" value="{{ old('quote_prefix', $company->quote_prefix) }}">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label fw-semibold text-dark small">Facture</label>
                                        <input type="text" name="invoice_prefix" class="form-control" value="{{ old('invoice_prefix', $company->invoice_prefix) }}">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label fw-semibold text-dark small">Avoir</label>
                                        <input type="text" name="credit_note_prefix" class="form-control" value="{{ old('credit_note_prefix', $company->credit_note_prefix) }}">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label fw-semibold text-dark small">Chantier</label>
                                        <input type="text" name="project_prefix" class="form-control" value="{{ old('project_prefix', $company->project_prefix) }}">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="mt-4 pt-3 border-top d-flex justify-content-end">
                            <button type="submit" class="btn btn-primary px-4 shadow-app">
                                <i class="bi bi-check2-circle me-2"></i>Enregistrer les modifications
                            </button>
                        </div>
                    </form>
                </x-card>
            </div>

            {{-- Onglet Régions --}}
            <div x-show="activeTab === 'regions'" x-cloak x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform translate-y-2">
                <x-card title="Régions d'intervention" subtitle="Gérez les régions géographiques pour vos clients et chantiers.">
                    <form method="POST" action="{{ route('settings.regions.store') }}" class="mb-4">
                        @csrf
                        <div class="row g-2">
                            <div class="col-md-6">
                                <input type="text" name="name" class="form-control" placeholder="Ajouter une nouvelle région..." required>
                            </div>
                            <div class="col-auto">
                                <button class="btn btn-primary px-3 shadow-sm-app"><i class="bi bi-plus-lg me-1"></i> Ajouter</button>
                            </div>
                        </div>
                    </form>
                    
                    <div class="list-group list-group-flush border rounded-4 overflow-hidden">
                        @foreach($regions as $region)
                        <div class="list-group-item d-flex justify-content-between align-items-center p-3 px-4">
                            <div class="d-flex align-items-center">
                                <div class="bg-light rounded-circle p-2 me-3 d-flex align-items-center justify-content-center" style="width: 36px; height: 36px;">
                                    <i class="bi bi-geo-alt text-primary"></i>
                                </div>
                                <span class="fw-bold text-dark">{{ $region->name }}</span>
                            </div>
                            <form method="POST" action="{{ route('settings.regions.destroy', $region) }}"
                                  onsubmit="return confirm('Voulez-vous vraiment supprimer cette région ?')">
                                @csrf @method('DELETE')
                                <button class="btn btn-light btn-sm rounded-circle text-danger shadow-sm-app"><i class="bi bi-trash"></i></button>
                            </form>
                        </div>
                        @endforeach
                        @if($regions->isEmpty())
                            <div class="p-5 text-center text-muted">Aucune région configurée.</div>
                        @endif
                    </div>
                </x-card>
            </div>

            {{-- Onglet Postes --}}
            <div x-show="activeTab === 'metiers'" x-cloak x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform translate-y-2">
                <x-card title="Postes & Fonctions" subtitle="Définissez les rôles professionnels pour vos employés.">
                    <form method="POST" action="{{ route('settings.job_types.store') }}" class="mb-4">
                        @csrf
                        <div class="row g-2">
                            <div class="col-md-6">
                                <input type="text" name="name" class="form-control" placeholder="Ex: Chef de Chantier, Maçon..." required>
                            </div>
                            <div class="col-auto">
                                <button class="btn btn-primary px-3 shadow-sm-app"><i class="bi bi-plus-lg me-1"></i> Ajouter</button>
                            </div>
                        </div>
                    </form>
                    
                    <div class="list-group list-group-flush border rounded-4 overflow-hidden">
                        @foreach($jobTypes as $jt)
                        <div class="list-group-item d-flex justify-content-between align-items-center p-3 px-4 hov-light">
                            <div class="d-flex align-items-center">
                                <div class="bg-light rounded-circle p-2 me-3 d-flex align-items-center justify-content-center" style="width: 36px; height: 36px;">
                                    <i class="bi bi-person-badge text-indigo"></i>
                                </div>
                                <span class="fw-bold text-dark">{{ $jt->name }}</span>
                            </div>
                            <form method="POST" action="{{ route('settings.job_types.destroy', $jt) }}"
                                  onsubmit="return confirm('Supprimer ce poste ?')">
                                @csrf @method('DELETE')
                                <button class="btn btn-light btn-sm rounded-circle text-danger shadow-sm-app"><i class="bi bi-trash"></i></button>
                            </form>
                        </div>
                        @endforeach
                    </div>
                </x-card>
            </div>

            {{-- Onglet Unités --}}
            <div x-show="activeTab === 'unites'" x-cloak x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform translate-y-2">
                <x-card title="Unités de mesure" subtitle="Gérez les unités utilisées pour vos matériaux et devis.">
                    <form method="POST" action="{{ route('settings.unit_types.store') }}" class="mb-4">
                        @csrf
                        <div class="row g-2">
                            <div class="col-md-5">
                                <input type="text" name="name" class="form-control" placeholder="Nom (ex: Mètre cube)" required>
                            </div>
                            <div class="col-md-2">
                                <input type="text" name="symbol" class="form-control" placeholder="Symbole (m³)">
                            </div>
                            <div class="col-auto">
                                <button class="btn btn-primary px-3 shadow-sm-app"><i class="bi bi-plus-lg me-1"></i> Ajouter</button>
                            </div>
                        </div>
                    </form>
                    
                    <div class="list-group list-group-flush border rounded-4 overflow-hidden">
                        @foreach($unitTypes as $ut)
                        <div class="list-group-item d-flex justify-content-between align-items-center p-3 px-4 hov-light">
                            <div class="d-flex align-items-center">
                                <div class="bg-light rounded-3 p-2 me-3 d-flex align-items-center justify-content-center fw-bold text-primary" style="width: 40px; height: 36px; font-size: 0.8rem;">
                                    {{ $ut->symbol ?? '??' }}
                                </div>
                                <span class="fw-bold text-dark">{{ $ut->name }}</span>
                            </div>
                            <form method="POST" action="{{ route('settings.unit_types.destroy', $ut) }}"
                                  onsubmit="return confirm('Supprimer cette unité ?')">
                                @csrf @method('DELETE')
                                <button class="btn btn-light btn-sm rounded-circle text-danger shadow-sm-app"><i class="bi bi-trash"></i></button>
                            </form>
                        </div>
                        @endforeach
                    </div>
                </x-card>
            </div>

            {{-- Onglet Catégories --}}
            <div x-show="activeTab === 'categories'" x-cloak x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform translate-y-2">
                <x-card title="Catégories de dépenses" subtitle="Organisez vos dépenses par catégories personnalisées.">
                    <form method="POST" action="{{ route('settings.expense_categories.store') }}" class="mb-4">
                        @csrf
                        <div class="row g-2">
                            <div class="col-md-6">
                                <input type="text" name="name" class="form-control" placeholder="Ex: Matériaux, Main d'œuvre..." required>
                            </div>
                            <div class="col-auto">
                                <button class="btn btn-primary px-3 shadow-sm-app"><i class="bi bi-plus-lg me-1"></i> Ajouter</button>
                            </div>
                        </div>
                    </form>
                    
                    <div class="row g-3">
                        @foreach($categories as $cat)
                        <div class="col-md-6">
                            <div class="p-3 bg-white border rounded-4 d-flex justify-content-between align-items-center shadow-sm-app">
                                <div class="d-flex align-items-center">
                                    <div class="bg-primary-subtle text-primary rounded-circle p-2 me-3 d-flex align-items-center justify-content-center" style="width: 36px; height: 36px;">
                                        <i class="bi bi-tag-fill"></i>
                                    </div>
                                    <span class="fw-bold text-dark">{{ $cat->name }}</span>
                                </div>
                                <form method="POST" action="{{ route('settings.expense_categories.destroy', $cat) }}"
                                      onsubmit="return confirm('Supprimer cette catégorie ?')">
                                    @csrf @method('DELETE')
                                    <button class="btn btn-light btn-sm rounded-circle text-danger"><i class="bi bi-trash"></i></button>
                                </form>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </x-card>
            </div>

            {{-- Grille salariale --}}
            <div x-show="activeTab === 'salaires'" x-cloak x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform translate-y-2">
                <x-card title="Grille salariale" subtitle="Définissez les tarifs journaliers par métier et région.">
                    <form method="POST" action="{{ route('settings.salary_rates.store') }}" class="mb-4">
                        @csrf
                        <div class="row g-2 align-items-end">
                            <div class="col-md-3">
                                <label class="form-label small fw-medium">Poste / Métier <span class="text-danger">*</span></label>
                                <select name="job_type_id" class="form-select" required>
                                    <option value="">— Sélectionner —</option>
                                    @foreach($jobTypes as $jt)
                                        <option value="{{ $jt->id }}">{{ $jt->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small fw-medium">Région</label>
                                <select name="region_id" class="form-select">
                                    <option value="">Nationale</option>
                                    @foreach($regions as $reg)
                                        <option value="{{ $reg->id }}">{{ $reg->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small fw-medium">Taux/jour (Ar) <span class="text-danger">*</span></label>
                                <input type="number" name="daily_rate" class="form-control" step="0.01" min="0" required>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small fw-medium">Taux/heure (Ar)</label>
                                <input type="number" name="hourly_rate" class="form-control" step="0.01" min="0">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small fw-medium">Date effet <span class="text-danger">*</span></label>
                                <input type="date" name="effective_date" class="form-control" value="{{ now()->format('Y-m-d') }}" required>
                            </div>
                            <div class="col-auto">
                                <button class="btn btn-primary shadow-sm-app"><i class="bi bi-plus-lg me-1"></i>Ajouter</button>
                            </div>
                        </div>
                    </form>

                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th>Poste</th>
                                    <th>Région</th>
                                    <th class="text-end">Taux/jour</th>
                                    <th class="text-end">Taux/h</th>
                                    <th>Date effet</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($salaryRates as $sr)
                                <tr>
                                    <td class="fw-semibold">{{ $sr->jobType->name ?? '—' }}</td>
                                    <td class="text-muted">{{ $sr->region->name ?? 'Nationale' }}</td>
                                    <td class="text-end">{{ number_format($sr->daily_rate, 0, ',', ' ') }} Ar</td>
                                    <td class="text-end">{{ $sr->hourly_rate ? number_format($sr->hourly_rate, 0, ',', ' ') . ' Ar' : '—' }}</td>
                                    <td>{{ $sr->effective_date->format('d/m/Y') }}</td>
                                    <td>
                                        <form method="POST" action="{{ route('settings.salary_rates.destroy', $sr) }}" onsubmit="return confirm('Supprimer ?')">
                                            @csrf @method('DELETE')
                                            <button class="btn btn-light btn-sm rounded-circle text-danger"><i class="bi bi-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="6" class="text-center text-muted py-4">Aucune entrée de grille salariale.</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </x-card>
            </div>

            {{-- Catégories matériaux --}}
            <div x-show="activeTab === 'mat_categories'" x-cloak x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform translate-y-2">
                <x-card title="Catégories de matériaux" subtitle="Organisez votre catalogue matériaux par catégories.">
                    <form method="POST" action="{{ route('settings.material_categories.store') }}" class="mb-4">
                        @csrf
                        <div class="row g-2 align-items-end">
                            <div class="col-md-5">
                                <label class="form-label small fw-medium">Nom de la catégorie <span class="text-danger">*</span></label>
                                <input type="text" name="name" class="form-control" placeholder="Ex: Ciment, Ferraille, Bois..." required>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small fw-medium">Couleur</label>
                                <input type="color" name="color" class="form-control form-control-color w-100" value="#0d6efd">
                            </div>
                            <div class="col-auto">
                                <button class="btn btn-primary shadow-sm-app"><i class="bi bi-plus-lg me-1"></i>Ajouter</button>
                            </div>
                        </div>
                    </form>
                    <div class="row g-3">
                        @forelse($materialCategories as $mc)
                        <div class="col-md-6">
                            <div class="p-3 bg-white border rounded-4 d-flex justify-content-between align-items-center shadow-sm-app">
                                <div class="d-flex align-items-center gap-3">
                                    <div class="rounded-circle" style="width:16px;height:16px;background:{{ $mc->color ?? '#6c757d' }}"></div>
                                    <span class="fw-bold text-dark">{{ $mc->name }}</span>
                                    <span class="badge bg-light text-muted border">{{ $mc->materials_count ?? $mc->materials()->count() }} mat.</span>
                                </div>
                                <form method="POST" action="{{ route('settings.material_categories.destroy', $mc) }}"
                                      onsubmit="return confirm('Supprimer cette catégorie ?')">
                                    @csrf @method('DELETE')
                                    <button class="btn btn-light btn-sm rounded-circle text-danger"><i class="bi bi-trash"></i></button>
                                </form>
                            </div>
                        </div>
                        @empty
                        <div class="col-12 text-center text-muted py-4">Aucune catégorie de matériaux configurée.</div>
                        @endforelse
                    </div>
                </x-card>
            </div>

        </div>
    </div>
</x-layouts.app>
