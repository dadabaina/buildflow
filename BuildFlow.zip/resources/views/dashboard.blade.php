<x-layouts.app title="Tableau de bord">
    <x-slot name="breadcrumb">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="#" class="text-decoration-none opacity-50 text-dark">Accueil</a></li>
                <li class="breadcrumb-item active fw-bold text-dark">Tableau de bord</li>
            </ol>
        </nav>
    </x-slot>

    {{-- Welcome Section --}}
    <div class="row mb-4">
        <div class="col-12">
            <div class="card bg-primary text-white border-0">
                <div class="card-body p-4">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <h3 class="fw-bold mb-1 border-0 text-white">Félicitations {{ auth()->user()->name }}! 🎉</h3>
                            <p class="mb-3">Votre activité est en hausse de 12% aujourd'hui. <br>Vérifiez vos nouveaux devis en attente.</p>
                            <a href="{{ route('quotes.index') }}" class="btn btn-sm btn-outline-white text-white border-white">Voir les devis</a>
                        </div>
                        <div class="d-none d-md-block">
                            <img src="https://demos.themeselection.com/sneat-bootstrap-html-laravel-admin-template-free/demo/assets/img/illustrations/man-with-laptop.png" 
                                 height="140" alt="View Badge User">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- KPIs Row --}}
    <div class="row g-4 mb-4">
        <div class="col-sm-6 col-xl-3">
            <x-stat-card 
                label="Chantiers actifs" 
                value="{{ $activeProjects }}" 
                icon="bi-building" 
                color="primary"
                trend="12.5%"
                :trendUp="true"
            />
        </div>
        <div class="col-sm-6 col-xl-3">
            <x-stat-card 
                label="Clients totaux" 
                value="{{ $totalClients }}" 
                icon="bi-people" 
                color="success"
                trend="3"
                :trendUp="true"
            />
        </div>
        <div class="col-sm-6 col-xl-3">
            <x-stat-card 
                label="Dépenses (MGA)" 
                value="{{ number_format($monthlyExpenses, 0, ',', ' ') }}" 
                icon="bi-receipt" 
                color="warning"
                trend="5%"
                :trendUp="false"
            />
        </div>
        <div class="col-sm-6 col-xl-3">
            <x-stat-card 
                label="Factures impayées" 
                value="{{ $overdueInvoices }}" 
                icon="bi-exclamation-triangle" 
                color="danger"
            />
        </div>
    </div>

    <div class="row g-4">
        {{-- Chantiers récents --}}
        <div class="col-lg-8">
            <x-card title="Chantiers récents">
                <x-slot name="headerActions">
                    <a href="{{ route('projects.index') }}" class="btn btn-sm btn-light text-primary">Tout voir</a>
                </x-slot>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Chantier</th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Client</th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Statut</th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Début</th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($recentProjects as $project)
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="avatar bg-light text-primary rounded-3 p-2 me-3 d-flex align-items-center justify-content-center" style="width: 38px; height: 38px;">
                                            <i class="bi bi-briefcase-fill"></i>
                                        </div>
                                        <div>
                                            <a href="{{ route('projects.show', $project) }}" class="text-decoration-none fw-bold text-dark">
                                                {{ $project->name }}
                                            </a>
                                            <div class="text-muted small">{{ $project->reference ?? '#'.str_pad($project->id, 4, '0', STR_PAD_LEFT) }}</div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="fw-medium">{{ $project->client?->name ?? '—' }}</span>
                                </td>
                                <td>
                                    @php
                                        $statusClasses = [
                                            'en_cours' => 'badge-soft-success',
                                            'termine' => 'badge-soft-info',
                                            'annule' => 'badge-soft-danger',
                                            'en_pause' => 'badge-soft-warning',
                                        ];
                                        $badgeClass = $statusClasses[$project->status] ?? 'badge-soft-secondary';
                                    @endphp
                                    <span class="badge rounded-pill {{ $badgeClass }} px-3 py-2">
                                        {{ $project->status_libelle }}
                                    </span>
                                </td>
                                <td class="text-muted small">
                                    {{ $project->start_date?->format('d M Y') ?? '—' }}
                                </td>
                                <td class="text-end">
                                    <a href="{{ route('projects.show', $project) }}" class="btn btn-light btn-sm rounded-circle shadow-sm-app">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                </td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="5" class="text-center text-muted py-5">
                                    <div class="py-3">
                                        <i class="bi bi-folder2-open fs-1 opacity-25 d-block mb-3"></i>
                                        Aucun chantier pour l'instant
                                    </div>
                                </td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </x-card>
        </div>

        {{-- Dépenses en attente --}}
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-transparent d-flex justify-content-between align-items-center py-3">
                    <h5 class="mb-0 fw-bold">Dépenses à valider</h5>
                    @if($pendingExpenses->count() > 0)
                        <span class="badge bg-warning text-dark rounded-pill">
                            {{ $pendingExpenses->count() }}
                        </span>
                    @endif
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush">
                        @forelse($pendingExpenses as $expense)
                        <a href="{{ route('expenses.show', $expense) }}"
                           class="list-group-item list-group-item-action border-0 p-3">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <span class="fw-bold text-dark">{{ Str::limit($expense->description, 30) }}</span>
                                <span class="fw-bold text-danger">{{ number_format($expense->total_amount, 0, ',', ' ') }} <small>MGA</small></span>
                            </div>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="text-muted small">
                                    <i class="bi bi-tag me-1"></i> {{ $expense->category?->name }}
                                </div>
                                <div class="text-muted small">
                                    <i class="bi bi-calendar3 me-1"></i> {{ $expense->expense_date?->format('d/m') }}
                                </div>
                            </div>
                        </a>
                        @empty
                        <div class="p-5 text-center text-muted">
                            <i class="bi bi-check2-circle fs-1 opacity-25 d-block mb-3"></i>
                            Toutes les dépenses sont validées.
                        </div>
                        @endforelse
                    </div>
                </div>
                <div class="card-footer bg-transparent border-0 p-3">
                    <a href="{{ route('expenses.index', ['status' => 'saisie']) }}"
                       class="btn btn-warning w-100 fw-bold text-dark shadow-sm-app">
                        Gérer les dépenses
                    </a>
                </div>
            </div>
        </div>
    </div>

    {{-- Stats Row --}}
    <div class="row g-4 mt-2">
        <div class="col-12">
            <div class="card border-0 shadow-sm">
                <div class="card-body p-4">
                    <h6 class="fw-bold text-dark mb-4">Répartition des chantiers par statut</h6>
                    <div class="row g-3">
                        @php
                        $statusLabels = [
                            'prospection' => ['label' => 'Prospection', 'icon' => 'bi-search', 'color' => 'primary'],
                            'devis_en_cours' => ['label' => 'Devis en cours', 'icon' => 'bi-file-earmark-text', 'color' => 'info'],
                            'devis_envoye' => ['label' => 'Devis envoyé', 'icon' => 'bi-send', 'color' => 'info'],
                            'en_cours' => ['label' => 'En cours', 'icon' => 'bi-play-circle', 'color' => 'success'],
                            'en_pause' => ['label' => 'En pause', 'icon' => 'bi-pause-circle', 'color' => 'warning'],
                            'termine' => ['label' => 'Terminé', 'icon' => 'bi-check-circle', 'color' => 'primary'],
                            'cloture' => ['label' => 'Clôturé', 'icon' => 'bi-archive', 'color' => 'secondary'],
                            'annule' => ['label' => 'Annulé', 'icon' => 'bi-x-circle', 'color' => 'danger'],
                        ];
                        @endphp
                        @foreach($statusLabels as $key => $meta)
                        <div class="col-sm-6 col-md-4 col-lg-3 col-xl-auto">
                            <div class="p-3 border rounded-3 bg-light d-flex align-items-center gap-3 h-100">
                                <div class="bg-white rounded-circle p-2 d-flex align-items-center justify-content-center shadow-sm" style="width: 32px; height: 32px;">
                                    <i class="bi {{ $meta['icon'] }} text-{{ $meta['color'] }}"></i>
                                </div>
                                <div>
                                    <div class="fw-bold text-dark">{{ $projectStats[$key] ?? 0 }}</div>
                                    <div class="text-muted small">{{ $meta['label'] }}</div>
                                </div>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-layouts.app>
