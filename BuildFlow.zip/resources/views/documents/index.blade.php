<x-layouts.app title="Documents">
    <x-slot name="breadcrumb">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="{{ route('dashboard') }}" class="text-decoration-none opacity-50 text-dark">Accueil</a></li>
                <li class="breadcrumb-item active fw-bold text-dark">Documents</li>
            </ol>
        </nav>
    </x-slot>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show shadow-sm-app border-0 rounded-3">
            <i class="bi bi-check-circle me-2"></i>{{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <x-card title="Documents" icon="bi bi-folder2-open">
        <x-slot name="headerActions">
            @can('documents.create')
            <a href="{{ route('documents.create', request()->only('project_id')) }}" class="btn btn-primary btn-sm px-3 shadow-sm-app">
                <i class="bi bi-upload me-1"></i>Ajouter un document
            </a>
            @endcan
        </x-slot>

        {{-- Filtres --}}
        <form method="GET" class="row g-2 mb-4">
            <div class="col-md-4">
                <input type="text" name="search" class="form-control" placeholder="Nom du fichier..." value="{{ request('search') }}">
            </div>
            <div class="col-md-3">
                <select name="project_id" class="form-select">
                    <option value="">Tous les chantiers</option>
                    @foreach($projects as $proj)
                        <option value="{{ $proj->id }}" {{ request('project_id') == $proj->id ? 'selected' : '' }}>{{ $proj->name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-3">
                <select name="category" class="form-select">
                    <option value="">Toutes catégories</option>
                    @foreach($categories as $key => $label)
                        <option value="{{ $key }}" {{ request('category') === $key ? 'selected' : '' }}>{{ $label }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-2">
                <button class="btn btn-light border w-100">
                    <i class="bi bi-search me-1"></i>Filtrer
                </button>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-light">
                    <tr>
                        <th class="border-0">Nom du fichier</th>
                        <th class="border-0">Catégorie</th>
                        <th class="border-0">Chantier</th>
                        <th class="border-0">Taille</th>
                        <th class="border-0">Ajouté par</th>
                        <th class="border-0">Date</th>
                        <th class="border-0"></th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($documents as $doc)
                    <tr>
                        <td>
                            <div class="d-flex align-items-center">
                                <i class="bi {{ $doc->isPdf() ? 'bi-file-earmark-pdf text-danger' : ($doc->isImage() ? 'bi-file-earmark-image text-info' : 'bi-file-earmark text-muted') }} me-2 fs-5"></i>
                                <div>
                                    <div class="fw-bold text-dark small">{{ $doc->original_name }}</div>
                                    @if($doc->notes)
                                        <div class="text-muted" style="font-size:0.75rem">{{ Str::limit($doc->notes, 60) }}</div>
                                    @endif
                                </div>
                            </div>
                        </td>
                        <td><span class="badge badge-soft-secondary px-2 py-1 rounded-pill small">{{ $doc->category_libelle }}</span></td>
                        <td>
                            @if($doc->project)
                                <a href="{{ route('projects.show', $doc->project) }}" class="text-decoration-none text-muted small">{{ $doc->project->name }}</a>
                            @else
                                <span class="text-muted small">—</span>
                            @endif
                        </td>
                        <td class="text-muted small">{{ $doc->file_size_formatted }}</td>
                        <td class="text-muted small">{{ $doc->uploadedBy->name ?? '—' }}</td>
                        <td class="text-muted small">{{ $doc->created_at->format('d/m/Y') }}</td>
                        <td>
                            <div class="d-flex gap-1">
                                <a href="{{ route('documents.show', $doc) }}" class="btn btn-light btn-sm shadow-sm-app" title="Télécharger">
                                    <i class="bi bi-download"></i>
                                </a>
                                @can('documents.delete')
                                <form method="POST" action="{{ route('documents.destroy', $doc) }}" onsubmit="return confirm('Supprimer ce document ?')">
                                    @csrf @method('DELETE')
                                    <button class="btn btn-outline-danger btn-sm" title="Supprimer"><i class="bi bi-trash"></i></button>
                                </form>
                                @endcan
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" class="text-center py-5 text-muted">
                            <i class="bi bi-folder2-open fs-2 d-block mb-2 opacity-25"></i>
                            Aucun document trouvé.
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        @if($documents->hasPages())
        <div class="d-flex justify-content-center mt-4">
            {{ $documents->links() }}
        </div>
        @endif
    </x-card>
</x-layouts.app>
