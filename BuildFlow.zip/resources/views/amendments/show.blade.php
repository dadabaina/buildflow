<x-layouts.app :title="'Avenant ' . $amendment->reference">
    <x-slot name="breadcrumb">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="{{ route('dashboard') }}" class="text-decoration-none opacity-50 text-dark">Accueil</a></li>
                <li class="breadcrumb-item"><a href="{{ route('amendments.index') }}" class="text-decoration-none opacity-50 text-dark">Avenants</a></li>
                <li class="breadcrumb-item active fw-bold text-dark">{{ $amendment->reference }}</li>
            </ol>
        </nav>
    </x-slot>

    @foreach(['success','error'] as $t)
        @if(session($t))
        <div class="alert alert-{{ $t === 'success' ? 'success' : 'danger' }} alert-dismissible fade show">
            {{ session($t) }}<button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        @endif
    @endforeach

    <div class="row">
        <div class="col-xl-8">
            <div class="card mb-3">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        <i class="bi bi-file-earmark-plus me-2"></i>{{ $amendment->reference }}
                        <span class="badge {{ $amendment->status_badge_class }} ms-2">{{ $amendment->status_libelle }}</span>
                    </h5>
                    @if($amendment->status === 'brouillon')
                    <a href="{{ route('amendments.edit', $amendment) }}" class="btn btn-outline-secondary btn-sm">
                        <i class="bi bi-pencil me-1"></i>Modifier
                    </a>
                    @endif
                </div>
                <div class="card-body">
                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <small class="text-muted d-block">Chantier</small>
                            <strong>{{ $amendment->project->name ?? '—' }}</strong>
                        </div>
                        <div class="col-md-6">
                            <small class="text-muted d-block">Titre</small>
                            <strong>{{ $amendment->title }}</strong>
                        </div>
                        @if($amendment->quote)
                        <div class="col-md-6">
                            <small class="text-muted d-block">Devis de référence</small>
                            <a href="{{ route('quotes.show', $amendment->quote) }}" class="text-decoration-none fw-bold text-primary">{{ $amendment->quote->reference }}</a>
                        </div>
                        @endif
                        @if($amendment->description)
                        <div class="col-12">
                            <small class="text-muted d-block">Description</small>
                            <p class="mb-0">{{ $amendment->description }}</p>
                        </div>
                        @endif
                    </div>

                    <h6 class="mb-2">Lignes</h6>
                    <div class="table-responsive mb-3">
                        <table class="table table-bordered table-sm">
                            <thead class="table-light">
                                <tr>
                                    <th>Description</th>
                                    <th class="text-end">Quantité</th>
                                    <th>Unité</th>
                                    <th class="text-end">P.U. HT</th>
                                    <th class="text-end">Total HT</th>
                                    <th class="text-center">Type</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($amendment->items as $item)
                                <tr class="{{ $item->is_deduction ? 'table-danger' : '' }}">
                                    <td>{{ $item->description }}</td>
                                    <td class="text-end">{{ number_format($item->quantity, 3, ',', ' ') }}</td>
                                    <td>{{ $item->unit ?? '—' }}</td>
                                    <td class="text-end">{{ number_format($item->unit_price, 2, ',', ' ') }} Ar</td>
                                    <td class="text-end fw-semibold {{ $item->is_deduction ? 'text-danger' : '' }}">
                                        {{ $item->is_deduction ? '-' : '' }}{{ number_format($item->total_ht, 2, ',', ' ') }} Ar
                                    </td>
                                    <td class="text-center">
                                        <span class="badge {{ $item->is_deduction ? 'bg-danger' : 'bg-success' }} small">
                                            {{ $item->is_deduction ? 'Déduction' : 'Ajout' }}
                                        </span>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                            <tfoot class="table-light">
                                <tr>
                                    <td colspan="4" class="text-end fw-semibold">Total HT</td>
                                    <td class="text-end fw-bold {{ $amendment->subtotal_ht < 0 ? 'text-danger' : '' }}">{{ number_format($amendment->subtotal_ht, 2, ',', ' ') }} Ar</td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td colspan="4" class="text-end">TVA ({{ $amendment->tva_rate }}%)</td>
                                    <td class="text-end">{{ number_format($amendment->tva_amount, 2, ',', ' ') }} Ar</td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td colspan="4" class="text-end fw-bold">Total TTC</td>
                                    <td class="text-end fw-bold text-primary">{{ number_format($amendment->total_ttc, 2, ',', ' ') }} Ar</td>
                                    <td></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-4">
            {{-- Actions --}}
            <div class="card mb-3">
                <div class="card-header"><h6 class="mb-0">Actions</h6></div>
                <div class="card-body d-grid gap-2">
                    @if($amendment->status === 'brouillon')
                    <form method="POST" action="{{ route('amendments.send', $amendment) }}">
                        @csrf
                        <button class="btn btn-info text-white btn-sm w-100"><i class="bi bi-send me-1"></i>Marquer Envoyé</button>
                    </form>
                    @endif
                    @if($amendment->status === 'envoye')
                    <form method="POST" action="{{ route('amendments.accept', $amendment) }}">
                        @csrf
                        <button class="btn btn-success btn-sm w-100"><i class="bi bi-check-circle me-1"></i>Accepter</button>
                    </form>
                    @endif
                </div>
            </div>
            {{-- Danger zone --}}
            @can('amendments.delete')
            <div class="card border-danger">
                <div class="card-header bg-danger text-white"><h6 class="mb-0">Zone danger</h6></div>
                <div class="card-body">
                    <form method="POST" action="{{ route('amendments.destroy', $amendment) }}" onsubmit="return confirm('Supprimer cet avenant ?')">
                        @csrf @method('DELETE')
                        <button class="btn btn-danger btn-sm w-100"><i class="bi bi-trash me-1"></i>Supprimer</button>
                    </form>
                </div>
            </div>
            @endcan
        </div>
    </div>
</x-layouts.app>
