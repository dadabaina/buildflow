<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">

    <div class="app-brand demo">
        <a href="{{ route('dashboard') }}" class="app-brand-link">
            <span class="app-brand-logo demo">
                <svg width="25" viewBox="0 0 25 42" version="1.1" xmlns="http://www.w3.org/2000/svg">
                    <defs><path d="M13.7918663,0.358365126 L3.39788168,7.44174259 C0.566865006,9.69408886 -0.379795268,12.4788597 0.557900856,15.7960551 C0.68998853,16.2758821 0.916390131,16.7393026 1.13319071,17.0946578 L17.9666342,0.257mage42 C17.7380219,0.0992102505 17.4861549,0 17.2206107,0 L15.0939481,0 C14.6490961,0 14.2234007,0.151225355 13.7918663,0.358365126 Z" id="path-1"></path><path d="M17.12,0 L15.0939481,0 C14.6490961,0 14.2234007,0.151225355 13.7918663,0.358365126 L3.39788168,7.44174259 C0.566865006,9.69408886 -0.379795268,12.4788597 0.557900856,15.7960551 L19.1812627,0.51tion Z M14,6 L15.5,11 Z" id="path-2"></path></defs>
                    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                        <g id="Group" transform="translate(3.000000, 1.000000)">
                            <polygon class="shape-bg" fill="#696CFF" points="18.1 -0.3 1.2 15.6 0 23.4 18.1 24.5" opacity="0.2"></polygon>
                            <polygon class="shape-bg" fill="#696CFF" points="18.1 -0.3 1.2 15.6 12.7 18.6"></polygon>
                            <polygon fill="#696CFF" opacity="0.5" points="11.7 20.2 8.6 17.4 19.3 3.4"></polygon>
                            <polygon fill="#696CFF" points="18.1 -0.3 19.3 3.4 11.7 20.2 0 23.4 18.1 24.5"></polygon>
                            <polygon fill="#696CFF" opacity="0.6" points="0 23.4 11.7 20.2 18.1 24.5"></polygon>
                        </g>
                    </g>
                </svg>
            </span>
            <span class="app-brand-text demo menu-text fw-bold ms-2">BuildFlow</span>
        </a>

        <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
            <i class="icon-base bx bx-chevron-left icon-sm d-flex align-items-center justify-content-center"></i>
        </a>
    </div>

    <div class="menu-divider mt-0"></div>
    <div class="menu-inner-shadow"></div>

    <ul class="menu-inner py-1">

        <!-- Principal -->
        <li class="menu-header small text-uppercase">
            <span class="menu-header-text">Principal</span>
        </li>
        <li class="menu-item {{ request()->routeIs('dashboard') ? 'active' : '' }}">
            <a href="{{ route('dashboard') }}" class="menu-link">
                <i class="menu-icon icon-base bx bx-home-circle"></i>
                <div>Tableau de bord</div>
            </a>
        </li>

        <!-- Opérations -->
        <li class="menu-header small text-uppercase">
            <span class="menu-header-text">Opérations</span>
        </li>
        <li class="menu-item {{ request()->routeIs('projects.*') ? 'active' : '' }}">
            <a href="{{ route('projects.index') }}" class="menu-link">
                <i class="menu-icon icon-base bx bx-building"></i>
                <div>Chantiers</div>
            </a>
        </li>
        <li class="menu-item {{ request()->routeIs('expenses.*') ? 'active' : '' }}">
            <a href="{{ route('expenses.index') }}" class="menu-link">
                <i class="menu-icon icon-base bx bx-receipt"></i>
                <div>Dépenses</div>
            </a>
        </li>

        <!-- Contacts -->
        <li class="menu-item {{ request()->routeIs('clients.*', 'suppliers.*', 'employees.*') ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon icon-base bx bx-group"></i>
                <div>Contacts</div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item {{ request()->routeIs('clients.*') ? 'active' : '' }}">
                    <a href="{{ route('clients.index') }}" class="menu-link">
                        <div>Clients</div>
                    </a>
                </li>
                <li class="menu-item {{ request()->routeIs('suppliers.*') ? 'active' : '' }}">
                    <a href="{{ route('suppliers.index') }}" class="menu-link">
                        <div>Fournisseurs</div>
                    </a>
                </li>
                <li class="menu-item {{ request()->routeIs('employees.*') ? 'active' : '' }}">
                    <a href="{{ route('employees.index') }}" class="menu-link">
                        <div>Employés</div>
                    </a>
                </li>
            </ul>
        </li>

        <!-- Commercial -->
        <li class="menu-header small text-uppercase">
            <span class="menu-header-text">Commercial</span>
        </li>
        <li class="menu-item {{ request()->routeIs('quotes.*', 'invoices.*', 'payments.*') ? 'active open' : '' }}">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon icon-base bx bx-briefcase"></i>
                <div>Ventes</div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item {{ request()->routeIs('quotes.*') ? 'active' : '' }}">
                    <a href="{{ route('quotes.index') }}" class="menu-link">
                        <div>Devis</div>
                    </a>
                </li>
                <li class="menu-item {{ request()->routeIs('invoices.*') ? 'active' : '' }}">
                    <a href="{{ route('invoices.index') }}" class="menu-link">
                        <div>Factures</div>
                    </a>
                </li>
                <li class="menu-item {{ request()->routeIs('payments.*') ? 'active' : '' }}">
                    <a href="{{ route('payments.index') }}" class="menu-link">
                        <div>Paiements</div>
                    </a>
                </li>
            </ul>
        </li>

        @can('settings.view')
        <!-- Administration -->
        <li class="menu-header small text-uppercase">
            <span class="menu-header-text">Administration</span>
        </li>
        <li class="menu-item {{ request()->routeIs('settings.*') ? 'active' : '' }}">
            <a href="{{ route('settings.index') }}" class="menu-link">
                <i class="menu-icon icon-base bx bx-cog"></i>
                <div>Paramètres</div>
            </a>
        </li>
        <li class="menu-item {{ request()->routeIs('users.*') ? 'active' : '' }}">
            <a href="{{ route('users.index') }}" class="menu-link">
                <i class="menu-icon icon-base bx bx-shield-quarter"></i>
                <div>Rôles & Permissions</div>
            </a>
        </li>
        @endcan

    </ul>
</aside>


    <div class="menu-inner-shadow"></div>

    <ul class="menu-inner py-1">
        <li class="menu-header small text-uppercase"><span class="menu-header-text">Principal</span></li>
        <li class="menu-item {{ request()->routeIs('dashboard') ? 'active' : '' }}">
            <a href="{{ route('dashboard') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-home-circle"></i>
                <div>Tableau de bord</div>
            </a>
        </li>

        <li class="menu-header small text-uppercase"><span class="menu-header-text">Opérations</span></li>
        <li class="menu-item {{ request()->routeIs('projects.*') ? 'active' : '' }}">
            <a href="{{ route('projects.index') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-building"></i>
                <div>Chantiers</div>
            </a>
        </li>
        <li class="menu-item {{ request()->routeIs('expenses.*') ? 'active' : '' }}">
            <a href="{{ route('expenses.index') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-receipt"></i>
                <div>Dépenses</div>
            </a>
        </li>

        <li class="menu-item" x-data="{ open: {{ request()->routeIs('clients.*', 'suppliers.*', 'employees.*') ? 'true' : 'false' }} }">
            <a href="javascript:void(0);" class="menu-link menu-toggle" @click="open = !open">
                <i class="menu-icon tf-icons bx bx-group"></i>
                <div>Contacts</div>
            </a>
            <ul class="menu-submenu" x-show="open" x-cloak>
                <li class="menu-item {{ request()->routeIs('clients.*') ? 'active' : '' }}">
                    <a href="{{ route('clients.index') }}" class="menu-link"><div>Clients</div></a>
                </li>
                <li class="menu-item {{ request()->routeIs('suppliers.*') ? 'active' : '' }}">
                    <a href="{{ route('suppliers.index') }}" class="menu-link"><div>Fournisseurs</div></a>
                </li>
                <li class="menu-item {{ request()->routeIs('employees.*') ? 'active' : '' }}">
                    <a href="{{ route('employees.index') }}" class="menu-link"><div>Employés</div></a>
                </li>
            </ul>
        </li>

        <li class="menu-header small text-uppercase"><span class="menu-header-text">Commercial</span></li>
        <li class="menu-item" x-data="{ open: {{ request()->routeIs('quotes.*', 'invoices.*', 'payments.*') ? 'true' : 'false' }} }">
            <a href="javascript:void(0);" class="menu-link menu-toggle" @click="open = !open">
                <i class="menu-icon tf-icons bx bx-briefcase"></i>
                <div>Ventes</div>
            </a>
            <ul class="menu-submenu" x-show="open" x-cloak>
                <li class="menu-item {{ request()->routeIs('quotes.*') ? 'active' : '' }}">
                    <a href="{{ route('quotes.index') }}" class="menu-link"><div>Devis</div></a>
                </li>
                <li class="menu-item {{ request()->routeIs('invoices.*') ? 'active' : '' }}">
                    <a href="{{ route('invoices.index') }}" class="menu-link"><div>Factures</div></a>
                </li>
                <li class="menu-item {{ request()->routeIs('payments.*') ? 'active' : '' }}">
                    <a href="{{ route('payments.index') }}" class="menu-link"><div>Paiements</div></a>
                </li>
            </ul>
        </li>

        @can('settings.view')
        <li class="menu-header small text-uppercase"><span class="menu-header-text">Administration</span></li>
        <li class="menu-item {{ request()->routeIs('settings.*') ? 'active' : '' }}">
            <a href="{{ route('settings.index') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-cog"></i>
                <div>Paramètres</div>
            </a>
        </li>
        <li class="menu-item {{ request()->routeIs('users.*') ? 'active' : '' }}">
            <a href="{{ route('users.index') }}" class="menu-link">
                <i class="menu-icon tf-icons bx bx-shield-quarter"></i>
                <div>Rôles & Permissions</div>
            </a>
        </li>
        @endcan
    </ul>
</aside>
