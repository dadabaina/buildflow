<x-layouts.app :title="$invoice->reference">
    <x-slot name="breadcrumb">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="{{ route('dashboard') }}" class="text-decoration-none opacity-50 text-dark">Accueil</a></li>
                <li class="breadcrumb-item"><a href="{{ route('invoices.index') }}" class="text-decoration-none opacity-50 text-dark">Factures</a></li>
                <li class="breadcrumb-item active fw-bold text-dark">{{ $invoice->reference }}</li>
            </ol>
        </nav>
    </x-slot>

    @php
    $statusConfig = [
        'brouillon' => ['label' => 'Brouillon',  'class' => 'badge-soft-secondary'],
        'envoye'    => ['label' => 'Envoyée',     'class' => 'badge-soft-info'],
        'partiel'   => ['label' => 'Partiel',     'class' => 'badge-soft-warning'],
        'paye'      => ['label' => 'Payée',       'class' => 'badge-soft-success'],
        'en_retard' => ['label' => 'En retard',   'class' => 'badge-soft-danger'],
        'annule'    => ['label' => 'Annulée',     'class' => 'bg-dark text-white'],
    ];
    $sc = $statusConfig[$invoice->status] ?? ['label' => $invoice->status, 'class' => 'badge-soft-secondary'];
    @endphp

    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <div>
            <div class="d-flex align-items-center gap-3 mb-2">
                <h3 class="fw-bold text-dark mb-0">{{ $invoice->reference }}</h3>
                <span class="badge rounded-pill {{ $sc['class'] }} px-3 py-2">
                    {{ $sc['label'] }}
                </span>
                <span class="badge bg-light text-muted border-0 fw-bold px-3 py-2">
                    {{ strtoupper($invoice->type) }}
                </span>
            </div>
            <p class="text-secondary mb-0 fw-medium">{{ $invoice->title }}</p>
        </div>
        <div class="d-flex gap-2">
            @can('invoices.edit')
                @if($invoice->status === 'brouillon')
                <form method="POST" action="{{ route('invoices.send', $invoice) }}">
                    @csrf
                    <button class="btn btn-info text-white shadow-app fw-bold px-4">
                        <i class="bi bi-send-fill me-2"></i>Envoyer
                    </button>
                </form>
                <a href="{{ route('invoices.edit', $invoice) }}" class="btn btn-light border shadow-sm-app fw-bold px-4">
                    <i class="bi bi-pencil-square me-2"></i>Modifier
                </a>
                @endif
                @if(in_array($invoice->status, ['envoye', 'partiel']))
                <a href="{{ route('payments.create', ['invoice_id' => $invoice->id]) }}" class="btn btn-success shadow-app fw-bold px-4">
                    <i class="bi bi-cash me-2"></i>Payer
                </a>
                @endif
            @endcan
            <div class="dropdown">
                <button class="btn btn-light border shadow-sm-app px-3" data-bs-toggle="dropdown">
                    <i class="bi bi-three-dots-vertical"></i>
                </button>
                <ul class="dropdown-menu dropdown-menu-end shadow-app border-0">
                    <li><a class="dropdown-item py-2" href="#"><i class="bi bi-printer me-2 text-muted"></i> Imprimer</a></li>
                    <li><a class="dropdown-item py-2" href="#"><i class="bi bi-file-pdf me-2 text-muted"></i> Télécharger PDF</a></li>
                    @can('invoices.delete')
                    <li><hr class="dropdown-divider"></li>
                    <li>
                        <form method="POST" action="{{ route('invoices.destroy', $invoice) }}" onsubmit="return confirm('Supprimer cette facture ?')">
                            @csrf @method('DELETE')
                            <button type="submit" class="dropdown-item py-2 text-danger"><i class="bi bi-trash me-2"></i> Supprimer</button>
                        </form>
                    </li>
                    @endcan
                </ul>
            </div>
        </div>
    </div>

    <div class="row g-4">
        {{-- État des paiements --}}
        <div class="col-12">
            <div class="card border-0 shadow-sm-app rounded-4 bg-white overflow-hidden">
                <div class="card-body p-4">
                    <div class="row align-items-center">
                        <div class="col-md-3 border-end border-light">
                            <div class="text-muted small fw-bold text-uppercase mb-1">Total TTC</div>
                            <h3 class="fw-bold text-dark mb-0">{{ number_format($invoice->net_to_pay, 0, ',', ' ') }} <small class="fs-6 fw-normal text-muted">MGA</small></h3>
                        </div>
                        <div class="col-md-3 border-end border-light px-md-4">
                            <div class="text-success small fw-bold text-uppercase mb-1">Total Payé</div>
                            <h3 class="fw-bold text-success mb-0">{{ number_format($invoice->amount_paid, 0, ',', ' ') }} <small class="fs-6 fw-normal opacity-75">MGA</small></h3>
                        </div>
                        <div class="col-md-3 border-end border-light px-md-4">
                            <div class="text-danger small fw-bold text-uppercase mb-1">Reste à payer</div>
                            <h3 class="fw-bold text-danger mb-0">{{ number_format($invoice->amount_remaining, 0, ',', ' ') }} <small class="fs-6 fw-normal opacity-75">MGA</small></h3>
                        </div>
                        <div class="col-md-3 ps-md-4">
                            @php $percent = $invoice->net_to_pay > 0 ? ($invoice->amount_paid / $invoice->net_to_pay) * 100 : 0; @endphp
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span class="text-muted small fw-bold text-uppercase">Progression</span>
                                <span class="fw-bold text-primary">{{ number_format($percent, 0) }}%</span>
                            </div>
                            <div class="progress rounded-pill" style="height: 10px;">
                                <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary" role="progressbar" style="width: {{ $percent }}%"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Infos --}}
        <div class="col-lg-4">
            <x-card title="Informations" icon="bi bi-info-circle-fill">
                <div class="list-group list-group-flush border-0">
                    <div class="py-3 d-flex justify-content-between align-items-start border-bottom border-light">
                        <div class="text-muted small fw-bold text-uppercase">Client</div>
                        <div class="text-end fw-bold text-dark">{{ $invoice->client?->name ?? '—' }}</div>
                    </div>
                    <div class="py-3 d-flex justify-content-between border-bottom border-light">
                        <div class="text-muted small fw-bold text-uppercase">Chantier</div>
                        <div class="text-end fw-bold text-dark">{{ $invoice->project?->name ?? 'Indépendant' }}</div>
                    </div>
                    <div class="py-3 d-flex justify-content-between border-bottom border-light">
                        <div class="text-muted small fw-bold text-uppercase">Date d'émission</div>
                        <div class="text-end fw-bold text-dark">{{ $invoice->invoice_date?->format('d M Y') }}</div>
                    </div>
                    <div class="py-3 d-flex justify-content-between border-bottom border-light">
                        <div class="text-muted small fw-bold text-uppercase">Échéance</div>
                        <div class="text-end fw-bold {{ $invoice->due_date && $invoice->due_date->isPast() && $invoice->status !== 'paye' ? 'text-danger' : 'text-dark' }}">
                            {{ $invoice->due_date?->format('d M Y') ?? 'Aucune' }}
                        </div>
                    </div>
                    @if($invoice->quote)
                    <div class="py-3 d-flex justify-content-between">
                        <div class="text-muted small fw-bold text-uppercase">Devis source</div>
                        <div class="text-end"><a href="{{ route('quotes.show', $invoice->quote) }}" class="text-decoration-none fw-bold">{{ $invoice->quote->reference }}</a></div>
                    </div>
                    @endif
                </div>
            </x-card>

            {{-- Historique des paiements --}}
            <x-card title="Paiements reçus" icon="bi bi-cash-stack">
                <x-slot name="headerActions">
                    @if(in_array($invoice->status, ['envoye', 'partiel']))
                    <a href="{{ route('payments.create', ['invoice_id' => $invoice->id]) }}" class="btn btn-sm btn-light border shadow-sm-app">
                        <i class="bi bi-plus-lg"></i>
                    </a>
                    @endif
                </x-slot>
                <div class="table-responsive">
                    <table class="table table-sm align-middle mb-0">
                        <thead><tr><th>Date</th><th>Montant</th><th></th></tr></thead>
                        <tbody>
                            @forelse($invoice->payments as $pmt)
                            <tr>
                                <td class="small text-muted">{{ $pmt->payment_date?->format('d/m/y') }}</td>
                                <td class="fw-bold text-success small">{{ number_format($pmt->amount, 0, ',', ' ') }}</td>
                                <td class="text-end">
                                    @can('payments.delete')
                                    <form method="POST" action="{{ route('payments.destroy', $pmt) }}" onsubmit="return confirm('Annuler ce paiement ?')">
                                        @csrf @method('DELETE')
                                        <button class="btn btn-sm btn-link text-danger p-0"><i class="bi bi-x"></i></button>
                                    </form>
                                    @endcan
                                </td>
                            </tr>
                            @empty
                            <tr><td colspan="3" class="text-center py-3 text-muted small">Aucun paiement.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </x-card>
        </div>

        {{-- Lignes --}}
        <div class="col-lg-8">
            <x-card title="Détail de la facturation" icon="bi bi-list-check">
                <x-slot name="headerActions">
                    @if($invoice->status === 'brouillon')
                    <button class="btn btn-sm btn-primary rounded-pill px-3 shadow-sm-app" data-bs-toggle="collapse" data-bs-target="#addInvItem">
                        <i class="bi bi-plus-lg me-1"></i> Ajouter
                    </button>
                    @endif
                </x-slot>

                @if($invoice->status === 'brouillon')
                <div class="collapse mb-4" id="addInvItem">
                    <div class="p-3 bg-light rounded-4 border">
                        <form method="POST" action="{{ route('invoices.items.add', $invoice) }}">
                            @csrf
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold text-uppercase">Désignation</label>
                                    <input type="text" name="description" class="form-control" placeholder="Description de l'article..." required>
                                </div>
                                <div class="col-md-2 col-6">
                                    <label class="form-label small fw-bold text-uppercase">Qté</label>
                                    <input type="number" name="quantity" class="form-control text-center" step="0.001" min="0" value="1" required>
                                </div>
                                <div class="col-md-4 col-6">
                                    <label class="form-label small fw-bold text-uppercase">PU HT</label>
                                    <input type="number" name="unit_price" class="form-control" step="0.01" min="0" required>
                                </div>
                                <div class="col-12 d-flex justify-content-end">
                                    <button type="submit" class="btn btn-primary px-4 fw-bold">Ajouter la ligne</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                @endif

                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="border-0 small text-uppercase">Désignation</th>
                                <th class="border-0 small text-uppercase text-center">Qté</th>
                                <th class="border-0 small text-uppercase text-end">PU HT</th>
                                <th class="border-0 small text-uppercase text-end">Total HT</th>
                                @if($invoice->status === 'brouillon')<th class="border-0"></th>@endif
                            </tr>
                        </thead>
                        <tbody class="border-top-0">
                            @foreach($invoice->items as $item)
                            <tr>
                                <td class="fw-medium text-dark py-3">{{ $item->description }}</td>
                                <td class="text-center"><span class="badge bg-light text-dark">{{ $item->quantity }}</span></td>
                                <td class="text-end fw-medium text-muted">{{ number_format($item->unit_price, 0, ',', ' ') }}</td>
                                <td class="text-end fw-bold text-dark">{{ number_format($item->total_ht, 0, ',', ' ') }}</td>
                                @if($invoice->status === 'brouillon')
                                <td class="text-end">
                                    <form method="POST" action="{{ route('invoices.items.remove', [$invoice, $item]) }}" onsubmit="return confirm('Supprimer ?')">
                                        @csrf @method('DELETE')
                                        <button class="btn btn-sm btn-light text-danger rounded-circle shadow-sm-app"><i class="bi bi-x-lg"></i></button>
                                    </form>
                                </td>
                                @endif
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                {{-- Totals --}}
                <div class="p-4 bg-light rounded-bottom-4 mt-0 border-top">
                    <div class="row g-0 justify-content-end text-end">
                        <div class="col-md-5">
                            <div class="d-flex justify-content-between mb-2">
                                <span class="text-muted small">Sous-total HT:</span>
                                <span class="fw-bold text-dark">{{ number_format($invoice->subtotal_ht, 0, ',', ' ') }}</span>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span class="text-muted small">TVA ({{ $invoice->tva_rate }}%):</span>
                                <span class="fw-bold text-dark">{{ number_format($invoice->tva_amount, 0, ',', ' ') }}</span>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span class="text-muted small fw-bold">Total TTC:</span>
                                <span class="fw-bold text-dark">{{ number_format($invoice->total_ttc, 0, ',', ' ') }}</span>
                            </div>
                            @if($invoice->rg_rate > 0)
                            <div class="d-flex justify-content-between mb-2">
                                <span class="text-danger small">Retenue de garantie ({{ $invoice->rg_rate }}%):</span>
                                <span class="fw-bold text-danger">- {{ number_format($invoice->rg_amount, 0, ',', ' ') }}</span>
                            </div>
                            @endif
                            <hr class="my-3 border-secondary opacity-25">
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="fw-bold text-dark fs-5">NET À PAYER:</span>
                                <span class="fw-bold fs-4 text-primary">{{ number_format($invoice->net_to_pay, 0, ',', ' ') }} <small class="fs-6 fw-normal">MGA</small></span>
                            </div>
                        </div>
                    </div>
                </div>
            </x-card>
        </div>
    </div>
</x-layouts.app>
