<x-layouts.app>
    <x-slot name="breadcrumb">
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item active">Rapports</li>
        </ol>
    </x-slot>

    <div class="mb-4">
        <h3 class="fw-bold mb-1">Rapports & Exports</h3>
        <p class="text-secondary small">Générez des rapports détaillés et exportez vos données.</p>
    </div>

    <div class="row g-4 text-center">
        {{-- Rapport financier --}}
        <div class="col-md-6 col-lg-3">
            <x-card class="h-100 p-2">
                <div class="bg-label-success rounded-circle mx-auto p-4 mb-3" style="width:80px;height:80px;display:flex;align-items:center;justify-content:center">
                    <i class="bi bi-graph-up-arrow fs-3"></i>
                </div>
                <h5 class="fw-bold">Rapport Financier</h5>
                <p class="text-muted small mb-4">CA mensuel, dépenses, top projets, balance.</p>
                <div class="mt-auto">
                    <a href="{{ route('reports.financial') }}" class="btn btn-label-success w-100">
                        <i class="bi bi-eye me-1"></i>Afficher
                    </a>
                </div>
            </x-card>
        </div>

        {{-- Suivi chantiers --}}
        <div class="col-md-6 col-lg-3">
            <x-card class="h-100 p-2">
                <div class="bg-label-primary rounded-circle mx-auto p-4 mb-3" style="width:80px;height:80px;display:flex;align-items:center;justify-content:center">
                    <i class="bi bi-building fs-3"></i>
                </div>
                <h5 class="fw-bold">Suivi Chantiers</h5>
                <p class="text-muted small mb-4">État d'avancement, budget vs réel par projet.</p>
                <div class="mt-auto">
                    <a href="{{ route('reports.projects') }}" class="btn btn-label-primary w-100">
                        <i class="bi bi-eye me-1"></i>Afficher
                    </a>
                </div>
            </x-card>
        </div>

        {{-- Journal dépenses --}}
        <div class="col-md-6 col-lg-3">
            <x-card class="h-100 p-2">
                <div class="bg-label-warning rounded-circle mx-auto p-4 mb-3" style="width:80px;height:80px;display:flex;align-items:center;justify-content:center">
                    <i class="bi bi-receipt fs-3"></i>
                </div>
                <h5 class="fw-bold">Journal Dépenses</h5>
                <p class="text-muted small mb-4">Toutes les dépenses validées par catégorie.</p>
                <div class="mt-auto">
                    <a href="{{ route('reports.expenses') }}" class="btn btn-label-warning w-100">
                        <i class="bi bi-eye me-1"></i>Afficher
                    </a>
                </div>
            </x-card>
        </div>

        {{-- Récap pointage --}}
        <div class="col-md-6 col-lg-3">
            <x-card class="h-100 p-2">
                <div class="bg-label-info rounded-circle mx-auto p-4 mb-3" style="width:80px;height:80px;display:flex;align-items:center;justify-content:center">
                    <i class="bi bi-person-check fs-3"></i>
                </div>
                <h5 class="fw-bold">Récap Pointage</h5>
                <p class="text-muted small mb-4">Présences et heures par employé.</p>
                <div class="mt-auto">
                    <a href="{{ route('reports.attendance') }}" class="btn btn-label-info w-100">
                        <i class="bi bi-eye me-1"></i>Afficher
                    </a>
                </div>
            </x-card>
        </div>
    </div>

    {{-- Stats globales --}}
    <div class="row g-4 mt-2">
        <div class="col-lg-6">
            <x-card title="Chiffres clés">
                <div class="row g-3">
                    <div class="col-6">
                        <div class="bg-label-primary rounded-3 p-3 text-center">
                            <h4 class="fw-bold mb-0">{{ $stats['projects'] }}</h4>
                            <small class="text-muted">Chantiers totaux</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="bg-label-success rounded-3 p-3 text-center">
                            <h4 class="fw-bold mb-0">{{ number_format($stats['invoices_total'] / 1000000, 1) }}M</h4>
                            <small class="text-muted">CA total (Ar)</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="bg-label-info rounded-3 p-3 text-center">
                            <h4 class="fw-bold mb-0">{{ number_format($stats['paid_total'] / 1000000, 1) }}M</h4>
                            <small class="text-muted">Encaissé (Ar)</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="bg-label-warning rounded-3 p-3 text-center">
                            <h4 class="fw-bold mb-0">{{ number_format($stats['expenses_total'] / 1000000, 1) }}M</h4>
                            <small class="text-muted">Dépenses (Ar)</small>
                        </div>
                    </div>
                </div>
            </x-card>
        </div>
    </div>
</x-layouts.app>
