<x-layouts.app>
    <x-slot name="breadcrumb">
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="{{ route('reports.index') }}">Rapports</a></li>
            <li class="breadcrumb-item active">Journal dépenses</li>
        </ol>
    </x-slot>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold mb-0">Journal des dépenses — {{ $year }}</h3>
        <div class="d-flex gap-2">
            <form method="GET" class="d-flex gap-2">
                <select name="year" class="form-select form-select-sm" onchange="this.form.submit()">
                    @foreach($years as $y)
                        <option value="{{ $y }}" {{ $y == $year ? 'selected' : '' }}>{{ $y }}</option>
                    @endforeach
                </select>
            </form>
            <a href="{{ request()->fullUrlWithQuery(['export' => 'pdf']) }}" class="btn btn-outline-danger btn-sm">
                <i class="bi bi-file-pdf me-1"></i>PDF
            </a>
        </div>
    </div>

    <div class="row g-4 mb-4">
        @foreach($byCategory as $cat => $total)
        <div class="col-md-3">
            <div class="card border-0 shadow-sm-app rounded-4 p-3 text-center">
                <p class="text-muted small mb-1">{{ $cat }}</p>
                <h5 class="fw-bold text-danger mb-0">{{ number_format($total, 0, ',', ' ') }} Ar</h5>
            </div>
        </div>
        @endforeach
    </div>

    <x-card>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-light">
                    <tr>
                        <th>Date</th>
                        <th>Projet</th>
                        <th>Catégorie</th>
                        <th>Description</th>
                        <th class="text-end">Montant (Ar)</th>
                        <th>Statut</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($expenses as $e)
                    <tr>
                        <td class="text-muted small">{{ $e->expense_date?->format('d/m/Y') }}</td>
                        <td>{{ $e->project->name ?? '—' }}</td>
                        <td>{{ $e->category->name ?? '—' }}</td>
                        <td>{{ Str::limit($e->description, 40) }}</td>
                        <td class="text-end fw-semibold text-danger">{{ number_format($e->amount, 0, ',', ' ') }}</td>
                        <td>
                            @if($e->status === 'approuve')
                                <span class="badge bg-success">Approuvé</span>
                            @elseif($e->status === 'rejete')
                                <span class="badge bg-danger">Rejeté</span>
                            @else
                                <span class="badge bg-warning text-dark">En attente</span>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr><td colspan="6" class="text-center text-muted py-4">Aucune dépense.</td></tr>
                    @endforelse
                </tbody>
                <tfoot class="fw-bold bg-light">
                    <tr>
                        <td colspan="4" class="text-end">Total</td>
                        <td class="text-end text-danger">{{ number_format($expenses->sum('amount'), 0, ',', ' ') }}</td>
                        <td></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </x-card>
</x-layouts.app>
