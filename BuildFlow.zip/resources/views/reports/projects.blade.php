<x-layouts.app>
    <x-slot name="breadcrumb">
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="{{ route('reports.index') }}">Rapports</a></li>
            <li class="breadcrumb-item active">Suivi chantiers</li>
        </ol>
    </x-slot>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold mb-0">Suivi des chantiers</h3>
        <a href="{{ request()->fullUrlWithQuery(['export' => 'pdf']) }}" class="btn btn-outline-danger btn-sm">
            <i class="bi bi-file-pdf me-1"></i>Exporter PDF
        </a>
    </div>

    <x-card>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-light">
                    <tr>
                        <th>Chantier</th>
                        <th>Client</th>
                        <th>Région</th>
                        <th>Statut</th>
                        <th class="text-end">Dépenses (Ar)</th>
                        <th class="text-end">Facturé (Ar)</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($projects as $p)
                    <tr>
                        <td class="fw-semibold">
                            <a href="{{ route('projects.show', $p) }}" class="text-decoration-none">{{ $p->name }}</a>
                        </td>
                        <td class="text-muted">{{ $p->client->name ?? '—' }}</td>
                        <td class="text-muted">{{ $p->region->name ?? '—' }}</td>
                        <td>
                            @php $sc = ['planifie'=>'secondary','en_cours'=>'primary','termine'=>'success','suspendu'=>'warning text-dark','annule'=>'danger']; @endphp
                            <span class="badge bg-{{ $sc[$p->status] ?? 'secondary' }}">{{ str_replace('_',' ',ucfirst($p->status)) }}</span>
                        </td>
                        <td class="text-end text-danger">{{ number_format($p->expenses_total ?? 0, 0, ',', ' ') }}</td>
                        <td class="text-end text-primary">{{ number_format($p->invoiced_total ?? 0, 0, ',', ' ') }}</td>
                    </tr>
                    @empty
                    <tr><td colspan="6" class="text-center text-muted py-4">Aucun chantier trouvé.</td></tr>
                    @endforelse
                </tbody>
                <tfoot class="fw-bold bg-light">
                    <tr>
                        <td colspan="4" class="text-end">Totaux</td>
                        <td class="text-end text-danger">{{ number_format($projects->sum('expenses_total'), 0, ',', ' ') }}</td>
                        <td class="text-end text-primary">{{ number_format($projects->sum('invoiced_total'), 0, ',', ' ') }}</td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </x-card>
</x-layouts.app>
