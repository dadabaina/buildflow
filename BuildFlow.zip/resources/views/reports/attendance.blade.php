<x-layouts.app>
    <x-slot name="breadcrumb">
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="{{ route('reports.index') }}">Rapports</a></li>
            <li class="breadcrumb-item active">Récap pointage</li>
        </ol>
    </x-slot>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold mb-0">Récapitulatif pointage</h3>
        <div class="d-flex gap-2">
            <form method="GET" class="d-flex gap-2">
                <select name="month" class="form-select form-select-sm" onchange="this.form.submit()">
                    @foreach(range(1,12) as $m)
                        <option value="{{ $m }}" {{ $m == $month ? 'selected' : '' }}>
                            {{ \Carbon\Carbon::create()->month($m)->translatedFormat('F') }}
                        </option>
                    @endforeach
                </select>
                <select name="year" class="form-select form-select-sm" onchange="this.form.submit()">
                    @foreach($years as $y)
                        <option value="{{ $y }}" {{ $y == $year ? 'selected' : '' }}>{{ $y }}</option>
                    @endforeach
                </select>
            </form>
            <a href="{{ request()->fullUrlWithQuery(['export' => 'pdf']) }}" class="btn btn-outline-danger btn-sm">
                <i class="bi bi-file-pdf me-1"></i>PDF
            </a>
        </div>
    </div>

    <x-card>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-light">
                    <tr>
                        <th>Date</th>
                        <th>Employé</th>
                        <th>Projet</th>
                        <th>Heures</th>
                        <th>Statut</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($attendances as $a)
                    <tr>
                        <td class="text-muted small">{{ $a->date?->format('d/m/Y') }}</td>
                        <td class="fw-semibold">{{ $a->employee->full_name ?? '—' }}</td>
                        <td>{{ $a->project->name ?? '—' }}</td>
                        <td>{{ $a->hours ?? '—' }}</td>
                        <td>
                            <span class="badge bg-{{ $a->status === 'present' ? 'success' : ($a->status === 'absent' ? 'danger' : 'warning text-dark') }}">
                                {{ ucfirst($a->status) }}
                            </span>
                        </td>
                    </tr>
                    @empty
                    <tr><td colspan="5" class="text-center text-muted py-4">Aucun pointage ce mois.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        {{ $attendances->links() }}
    </x-card>
</x-layouts.app>
