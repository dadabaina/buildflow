<x-layouts.app title="Gestion des Fournisseurs">
    <x-slot name="breadcrumb">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="{{ route('dashboard') }}" class="text-decoration-none opacity-50 text-dark">Accueil</a></li>
                <li class="breadcrumb-item active fw-bold text-dark">Fournisseurs</li>
            </ol>
        </nav>
    </x-slot>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold text-dark mb-0">Fournisseurs & Sous-traitants</h3>
            <p class="text-secondary small mb-0">Gérez vos partenaires logistiques et vos prestataires de services.</p>
        </div>
        @can('suppliers.create')
        <a href="{{ route('suppliers.create') }}" class="btn btn-primary shadow-app d-flex align-items-center gap-2">
            <i class="bi bi-plus-lg fs-5"></i>
            <span>Nouveau fournisseur</span>
        </a>
        @endcan
    </div>

    {{-- Filtres --}}
    <div class="card border-0 shadow-sm-app mb-4 bg-white">
        <div class="card-body p-3">
            <form method="GET" class="row g-2 align-items-center">
                <div class="col-md-5">
                    <div class="input-group input-group-sm">
                        <span class="input-group-text bg-transparent border-end-0 text-muted"><i class="bi bi-search"></i></span>
                        <input type="text" name="search" class="form-control border-start-0 ps-0"
                               placeholder="Rechercher par nom, email, NIF..." value="{{ request('search') }}">
                    </div>
                </div>
                <div class="col-md-3">
                    <select name="type" class="form-select form-select-sm">
                        <option value="">Tous les types</option>
                        <option value="fournisseur" {{ request('type') === 'fournisseur' ? 'selected' : '' }}>Fournisseur uniquement</option>
                        <option value="sous_traitant" {{ request('type') === 'sous_traitant' ? 'selected' : '' }}>Sous-traitant uniquement</option>
                        <option value="les_deux" {{ request('type') === 'les_deux' ? 'selected' : '' }}>Hybride (Fournisseur + S/T)</option>
                    </select>
                </div>
                <div class="col-auto ms-auto d-flex gap-2">
                    <button type="submit" class="btn btn-sm btn-primary px-3">Filtrer</button>
                    @if(request()->hasAny(['search', 'type']))
                    <a href="{{ route('suppliers.index') }}" class="btn btn-sm btn-light border px-3">Réinitialiser</a>
                    @endif
                </div>
            </form>
        </div>
    </div>

    <div class="card border-0 shadow-sm-app overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th class="ps-4">Partenaire</th>
                        <th>Type d'activité</th>
                        <th>Contact</th>
                        <th>Identifiants</th>
                        <th class="text-end pe-4">Actions</th>
                    </tr>
                </thead>
                <tbody class="border-top-0">
                    @php
                    $typeLabels = ['fournisseur' => 'Fournisseur', 'sous_traitant' => 'Sous-traitant', 'les_deux' => 'Hybride'];
                    $typeBadges = ['fournisseur' => 'badge-soft-info', 'sous_traitant' => 'badge-soft-warning', 'les_deux' => 'badge-soft-primary'];
                    @endphp
                    @forelse($suppliers as $supplier)
                    <tr>
                        <td class="ps-4 py-3">
                            <div class="d-flex align-items-center">
                                <div class="bg-indigo-subtle text-indigo rounded-3 p-2 d-flex align-items-center justify-content-center me-3 shadow-sm-app" style="width: 42px; height: 42px;">
                                    <i class="bi bi-truck fs-5"></i>
                                </div>
                                <div>
                                    <a href="{{ route('suppliers.show', $supplier) }}" class="text-decoration-none fw-bold text-dark d-block mb-0 hov-primary">
                                        {{ $supplier->name }}
                                    </a>
                                    <small class="text-muted">ID: #{{ str_pad($supplier->id, 4, '0', STR_PAD_LEFT) }}</small>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="badge rounded-pill {{ $typeBadges[$supplier->type] ?? 'badge-soft-secondary' }} px-3 py-2">
                                {{ $typeLabels[$supplier->type] ?? $supplier->type }}
                            </span>
                        </td>
                        <td>
                            <div class="small fw-medium text-dark"><i class="bi bi-telephone me-2 text-muted"></i>{{ $supplier->phone ?? '—' }}</div>
                            <div class="small text-muted"><i class="bi bi-envelope me-2 text-muted"></i>{{ $supplier->email ?? '—' }}</div>
                        </td>
                        <td>
                            <div class="small"><span class="text-muted small fw-bold">NIF:</span> <span class="font-monospace">{{ $supplier->nif ?? '—' }}</span></div>
                            <div class="small"><span class="text-muted small fw-bold">STAT:</span> <span class="font-monospace">{{ $supplier->stat ?? '—' }}</span></div>
                        </td>
                        <td class="text-end pe-4">
                            <div class="d-flex justify-content-end gap-2">
                                <a href="{{ route('suppliers.show', $supplier) }}" class="btn btn-light btn-sm rounded-circle shadow-sm-app" title="Voir fiche">
                                    <i class="bi bi-eye text-primary"></i>
                                </a>
                                @can('suppliers.edit')
                                <a href="{{ route('suppliers.edit', $supplier) }}" class="btn btn-light btn-sm rounded-circle shadow-sm-app" title="Modifier">
                                    <i class="bi bi-pencil text-info"></i>
                                </a>
                                @endcan
                                @can('suppliers.delete')
                                <form method="POST" action="{{ route('suppliers.destroy', $supplier) }}"
                                      onsubmit="return confirm('Supprimer ce fournisseur ?')">
                                    @csrf @method('DELETE')
                                    <button class="btn btn-light btn-sm rounded-circle shadow-sm-app" title="Supprimer">
                                        <i class="bi bi-trash text-danger"></i>
                                    </button>
                                </form>
                                @endcan
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="5" class="text-center py-5">
                            <div class="py-5">
                                <i class="bi bi-truck fs-1 opacity-25 d-block mb-3"></i>
                                <h5 class="text-muted">Aucun partenaire trouvé</h5>
                                <p class="text-muted small">Vos fournisseurs apparaîtront ici.</p>
                            </div>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($suppliers->hasPages())
        <div class="card-footer bg-white py-3 border-top border-light">
            {{ $suppliers->links() }}
        </div>
        @endif
    </div>
</x-layouts.app>
