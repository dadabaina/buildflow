<x-layouts.app :title="$supplier->name">
    <x-slot name="breadcrumb">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="{{ route('dashboard') }}" class="text-decoration-none opacity-50 text-dark">Accueil</a></li>
                <li class="breadcrumb-item"><a href="{{ route('suppliers.index') }}" class="text-decoration-none opacity-50 text-dark">Fournisseurs</a></li>
                <li class="breadcrumb-item active fw-bold text-dark">{{ $supplier->name }}</li>
            </ol>
        </nav>
    </x-slot>

    @php
    $typeLabels = ['fournisseur' => 'Fournisseur', 'sous_traitant' => 'Sous-traitant', 'les_deux' => 'Fournisseur + S/T'];
    $typeBadges = ['fournisseur' => 'badge-soft-info', 'sous_traitant' => 'badge-soft-warning', 'les_deux' => 'badge-soft-primary'];
    @endphp

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div class="d-flex align-items-center gap-3">
            <div class="avatar bg-dark text-white rounded-4 d-flex align-items-center justify-content-center shadow-app" style="width: 56px; height: 56px; font-size: 1.5rem">
                <i class="bi bi-truck"></i>
            </div>
            <div>
                <h3 class="fw-bold text-dark mb-0">{{ $supplier->name }}</h3>
                <span class="badge rounded-pill {{ $typeBadges[$supplier->type] ?? 'badge-soft-secondary' }} px-3 py-1">
                    {{ $typeLabels[$supplier->type] ?? $supplier->type }}
                </span>
            </div>
        </div>
        <div class="d-flex gap-2">
            @can('suppliers.edit')
            <a href="{{ route('suppliers.edit', $supplier) }}" class="btn btn-light border shadow-sm-app fw-bold px-4">
                <i class="bi bi-pencil-square me-2"></i>Modifier
            </a>
            @endcan
            @can('suppliers.delete')
            <form method="POST" action="{{ route('suppliers.destroy', $supplier) }}" onsubmit="return confirm('Supprimer ce partenaire ?')">
                @csrf @method('DELETE')
                <button class="btn btn-outline-danger shadow-sm-app px-3"><i class="bi bi-trash"></i></button>
            </form>
            @endcan
        </div>
    </div>

    <div class="row g-4">
        {{-- Infos Administratives --}}
        <div class="col-lg-4">
            <x-card title="Fiche Partenaire" icon="bi bi-card-checklist">
                <div class="list-group list-group-flush border-0">
                    <div class="py-3 d-flex justify-content-between border-bottom border-light">
                        <span class="text-muted small fw-bold text-uppercase">Téléphone</span>
                        <span class="fw-bold text-dark">{{ $supplier->phone ?? '—' }}</span>
                    </div>
                    <div class="py-3 d-flex justify-content-between border-bottom border-light">
                        <span class="text-muted small fw-bold text-uppercase">Email</span>
                        <span class="text-dark">{{ $supplier->email ?? '—' }}</span>
                    </div>
                    <div class="py-3">
                        <span class="text-muted small fw-bold text-uppercase d-block mb-1">Adresse</span>
                        <span class="text-secondary small">{{ $supplier->address ?? 'Non renseignée' }}</span>
                    </div>
                </div>
            </x-card>

            <x-card title="Identifiants Fiscaux" icon="bi bi-shield-lock">
                <div class="list-group list-group-flush border-0">
                    <div class="py-3 d-flex justify-content-between border-bottom border-light">
                        <span class="text-muted small fw-bold text-uppercase">NIF</span>
                        <span class="font-monospace fw-bold">{{ $supplier->nif ?? '—' }}</span>
                    </div>
                    <div class="py-3 d-flex justify-content-between border-bottom border-light">
                        <span class="text-muted small fw-bold text-uppercase">STAT</span>
                        <span class="font-monospace fw-bold">{{ $supplier->stat ?? '—' }}</span>
                    </div>
                    <div class="py-3 d-flex justify-content-between">
                        <span class="text-muted small fw-bold text-uppercase">RCS</span>
                        <span class="font-monospace fw-bold">{{ $supplier->rcs ?? '—' }}</span>
                    </div>
                </div>
            </x-card>
        </div>

        {{-- Collaboration --}}
        <div class="col-lg-8">
            {{-- Employés rattachés --}}
            <x-card title="Effectif Intervenant" icon="bi bi-people-fill" bodyClass="p-0">
                <x-slot name="headerActions">
                    <span class="badge bg-indigo rounded-pill px-3">{{ $supplier->employees->count() }} agents</span>
                </x-slot>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="border-0 ps-4">Collaborateur</th>
                                <th class="border-0">Poste</th>
                                <th class="border-0 text-end pe-4">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($supplier->employees->take(10) as $emp)
                            <tr>
                                <td class="ps-4 py-3">
                                    <div class="d-flex align-items-center">
                                        <div class="avatar bg-primary-subtle text-primary rounded-circle p-2 me-3 d-flex align-items-center justify-content-center fw-bold" style="width: 32px; height: 32px; font-size: 0.75rem">
                                            {{ substr($emp->first_name, 0, 1) }}{{ substr($emp->last_name, 0, 1) }}
                                        </div>
                                        <a href="{{ route('employees.show', $emp) }}" class="text-decoration-none fw-bold text-dark">{{ $emp->full_name }}</a>
                                    </div>
                                </td>
                                <td><span class="badge-soft-info px-2 py-1 rounded small">{{ $emp->jobType?->name ?? '—' }}</span></td>
                                <td class="text-end pe-4">
                                    <a href="{{ route('employees.show', $emp) }}" class="btn btn-light btn-sm rounded-circle shadow-sm-app"><i class="bi bi-arrow-right"></i></a>
                                </td>
                            </tr>
                            @empty
                            <tr><td colspan="3" class="text-center py-4 text-muted small">Aucun employé rattaché.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </x-card>

            {{-- Dépenses récentes --}}
            <x-card title="Dernières facturations" icon="bi bi-receipt" bodyClass="p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="border-0 ps-4">Description</th>
                                <th class="border-0">Montant</th>
                                <th class="border-0 text-end pe-4">Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($supplier->expenses->take(5) as $expense)
                            <tr>
                                <td class="ps-4 py-3"><span class="fw-medium text-dark">{{ Str::limit($expense->description, 50) }}</span></td>
                                <td class="fw-bold text-danger">{{ number_format($expense->total_amount, 0, ',', ' ') }} MGA</td>
                                <td class="text-end pe-4 text-muted small">{{ $expense->expense_date?->format('d/m/Y') }}</td>
                            </tr>
                            @empty
                            <tr><td colspan="3" class="text-center py-4 text-muted small">Aucune dépense enregistrée.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </x-card>
        </div>
    </div>
</x-layouts.app>
