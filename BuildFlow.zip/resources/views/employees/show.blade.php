<x-layouts.app :title="$employee->full_name">
    <x-slot name="breadcrumb">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="{{ route('dashboard') }}" class="text-decoration-none opacity-50 text-dark">Accueil</a></li>
                <li class="breadcrumb-item"><a href="{{ route('employees.index') }}" class="text-decoration-none opacity-50 text-dark">Employés</a></li>
                <li class="breadcrumb-item active fw-bold text-dark">{{ $employee->full_name }}</li>
            </ol>
        </nav>
    </x-slot>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div class="d-flex align-items-center gap-3">
            <div class="avatar bg-indigo text-white rounded-circle d-flex align-items-center justify-content-center fw-bold shadow-app" style="width: 56px; height: 56px; font-size: 1.25rem">
                {{ substr($employee->first_name, 0, 1) }}{{ substr($employee->last_name, 0, 1) }}
            </div>
            <div>
                <h3 class="fw-bold text-dark mb-0">{{ $employee->full_name }}</h3>
                <span class="badge rounded-pill badge-soft-info px-3 py-1">
                    {{ $employee->jobType?->name ?? 'Poste non défini' }}
                </span>
            </div>
        </div>
        <div class="d-flex gap-2">
            @can('employees.edit')
            <button type="button" class="btn btn-light border shadow-sm-app fw-bold px-4" 
                    onclick='window.parent.empModalEdit({{ json_encode(["id"=>$employee->id,"first_name"=>$employee->first_name,"last_name"=>$employee->last_name,"matricule"=>$employee->matricule,"phone"=>$employee->phone,"email"=>$employee->email,"job_type_id"=>$employee->job_type_id,"supplier_id"=>$employee->supplier_id,"region_id"=>$employee->region_id,"contract_type"=>$employee->contract_type,"hire_date"=>$employee->hire_date?->format('Y-m-d'),"daily_rate"=>$employee->daily_rate,"monthly_salary"=>$employee->monthly_salary,"notes"=>$employee->notes]) }})'>
                <i class="bi bi-pencil-square me-2"></i>Modifier
            </button>
            @endcan
            @can('employees.delete')
            <form method="POST" action="{{ route('employees.destroy', $employee) }}" onsubmit="return confirm('Archiver cet employé ?')">
                @csrf @method('DELETE')
                <button class="btn btn-outline-danger shadow-sm-app px-3"><i class="bi bi-archive"></i></button>
            </form>
            @endcan
        </div>
    </div>

    <div class="row g-4">
        {{-- Profil & Info --}}
        <div class="col-lg-4">
            <x-card title="Détails du Profil" icon="bi bi-person-lines-fill">
                <div class="list-group list-group-flush border-0">
                    <div class="py-3 d-flex justify-content-between border-bottom border-light">
                        <span class="text-muted small fw-bold text-uppercase">Matricule</span>
                        <span class="fw-bold text-dark">{{ $employee->matricule ?? '—' }}</span>
                    </div>
                    <div class="py-3 d-flex justify-content-between border-bottom border-light">
                        <span class="text-muted small fw-bold text-uppercase">Téléphone</span>
                        <span class="fw-bold text-dark">{{ $employee->phone ?? '—' }}</span>
                    </div>
                    <div class="py-3 d-flex justify-content-between border-bottom border-light">
                        <span class="text-muted small fw-bold text-uppercase">Email</span>
                        <span class="text-dark">{{ $employee->email ?? '—' }}</span>
                    </div>
                    <div class="py-3 d-flex justify-content-between border-bottom border-light">
                        <span class="text-muted small fw-bold text-uppercase">Région</span>
                        <span class="fw-bold text-dark">{{ $employee->region?->name ?? '—' }}</span>
                    </div>
                    <div class="py-3 d-flex justify-content-between">
                        <span class="text-muted small fw-bold text-uppercase">Employeur</span>
                        <span class="fw-bold text-primary">
                            @if($employee->supplier)
                                <a href="{{ route('suppliers.show', $employee->supplier) }}" class="text-decoration-none">{{ $employee->supplier->name }}</a>
                            @else
                                <i class="bi bi-shield-check me-1"></i> Effectif Interne
                            @endif
                        </span>
                    </div>
                </div>
            </x-card>

            <x-card title="Conditions Contractuelles" icon="bi bi-file-earmark-medical">
                <div class="list-group list-group-flush border-0">
                    <div class="py-3 d-flex justify-content-between border-bottom border-light">
                        <span class="text-muted small fw-bold text-uppercase">Contrat</span>
                        <span class="badge bg-light text-dark border-0">{{ ucfirst($employee->contract_type) ?? '—' }}</span>
                    </div>
                    <div class="py-3 d-flex justify-content-between border-bottom border-light">
                        <span class="text-muted small fw-bold text-uppercase">Embauche</span>
                        <span class="fw-bold text-dark">{{ $employee->hire_date?->format('d M Y') ?? '—' }}</span>
                    </div>
                    <div class="py-3 d-flex justify-content-between">
                        <span class="text-muted small fw-bold text-uppercase">Taux journalier</span>
                        <span class="fw-bold text-success">{{ $employee->daily_rate ? number_format($employee->daily_rate, 0, ',', ' ').' MGA' : '—' }}</span>
                    </div>
                </div>
            </x-card>
        </div>

        {{-- Activité --}}
        <div class="col-lg-8">
            <x-card title="Chantiers Affectés" icon="bi bi-stack" bodyClass="p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="border-0 ps-4">Chantier</th>
                                <th class="border-0">Statut</th>
                                <th class="border-0 text-end pe-4">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($employee->projects->take(15) as $project)
                            <tr>
                                <td class="ps-4 py-3">
                                    <div class="d-flex align-items-center">
                                        <div class="bg-primary-subtle text-primary rounded-3 p-2 me-3" style="width: 32px; height: 32px; display: flex; align-items: center; justify-content: center;">
                                            <i class="bi bi-building small"></i>
                                        </div>
                                        <a href="{{ route('projects.show', $project) }}" class="text-decoration-none fw-bold text-dark">{{ $project->name }}</a>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge rounded-pill {{ $project->status_badge_class }} px-3 py-1 small">
                                        {{ $project->status_libelle }}
                                    </span>
                                </td>
                                <td class="text-end pe-4">
                                    <a href="{{ route('projects.show', $project) }}" class="btn btn-light btn-sm rounded-circle shadow-sm-app"><i class="bi bi-arrow-right"></i></a>
                                </td>
                            </tr>
                            @empty
                            <tr><td colspan="3" class="text-center py-5 text-muted small">Aucun chantier affecté pour le moment.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </x-card>

            @if($employee->notes)
            <x-card title="Observations Internes" icon="bi bi-chat-square-dots">
                <div class="p-3 bg-light rounded-3 text-secondary" style="white-space: pre-line;">{{ $employee->notes }}</div>
            </x-card>
            @endif
        </div>
    </div>
</x-layouts.app>
