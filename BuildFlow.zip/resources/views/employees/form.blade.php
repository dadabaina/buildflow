<x-layouts.app :title="isset($employee) ? 'Modifier employé' : 'Nouvel employé'">
    <x-slot name="breadcrumb">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Accueil</a></li>
                <li class="breadcrumb-item"><a href="{{ route('employees.index') }}">Employés</a></li>
                <li class="breadcrumb-item active">{{ isset($employee) ? 'Modifier' : 'Nouveau' }}</li>
            </ol>
        </nav>
    </x-slot>

    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <h6 class="mb-0 fw-bold">
                        <i class="bi bi-person-plus me-2"></i>
                        {{ isset($employee) ? 'Modifier l\'employé' : 'Nouvel employé' }}
                    </h6>
                </div>
                <div class="card-body">
                    <form method="POST"
                          action="{{ isset($employee) ? route('employees.update', $employee) : route('employees.store') }}">
                        @csrf
                        @isset($employee) @method('PATCH') @endisset

                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Prénom <span class="text-danger">*</span></label>
                                <input type="text" name="first_name"
                                       class="form-control @error('first_name') is-invalid @enderror"
                                       value="{{ old('first_name', $employee->first_name ?? '') }}" required>
                                @error('first_name') <div class="invalid-feedback">{{ $message }}</div> @enderror
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Nom <span class="text-danger">*</span></label>
                                <input type="text" name="last_name"
                                       class="form-control @error('last_name') is-invalid @enderror"
                                       value="{{ old('last_name', $employee->last_name ?? '') }}" required>
                                @error('last_name') <div class="invalid-feedback">{{ $message }}</div> @enderror
                            </div>

                            <div class="col-md-4">
                                <label class="form-label">Matricule</label>
                                <input type="text" name="matricule" class="form-control"
                                       value="{{ old('matricule', $employee->matricule ?? '') }}">
                            </div>

                            <div class="col-md-4">
                                <label class="form-label">Téléphone</label>
                                <input type="text" name="phone" class="form-control"
                                       value="{{ old('phone', $employee->phone ?? '') }}">
                            </div>

                            <div class="col-md-4">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-control"
                                       value="{{ old('email', $employee->email ?? '') }}">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Poste / Fonction</label>
                                <select name="job_type_id" class="form-select">
                                    <option value="">—</option>
                                    @foreach($jobTypes as $jt)
                                    <option value="{{ $jt->id }}"
                                        {{ old('job_type_id', $employee->job_type_id ?? '') == $jt->id ? 'selected' : '' }}>
                                        {{ $jt->name }}
                                    </option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Fournisseur / Sous-traitant</label>
                                <select name="supplier_id" class="form-select">
                                    <option value="">— Interne —</option>
                                    @foreach($suppliers as $sup)
                                    <option value="{{ $sup->id }}"
                                        {{ old('supplier_id', $employee->supplier_id ?? '') == $sup->id ? 'selected' : '' }}>
                                        {{ $sup->name }}
                                    </option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Région</label>
                                <select name="region_id" class="form-select">
                                    <option value="">—</option>
                                    @foreach($regions as $region)
                                    <option value="{{ $region->id }}"
                                        {{ old('region_id', $employee->region_id ?? '') == $region->id ? 'selected' : '' }}>
                                        {{ $region->name }}
                                    </option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Date d'entrée</label>
                                <input type="date" name="hire_date" class="form-control"
                                       value="{{ old('hire_date', isset($employee) ? $employee->hire_date?->format('Y-m-d') : '') }}">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Salaire journalier (MGA)</label>
                                <input type="number" name="daily_rate" class="form-control" step="0.01"
                                       value="{{ old('daily_rate', $employee->daily_rate ?? '') }}">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">CIN</label>
                                <input type="text" name="cin" class="form-control"
                                       value="{{ old('cin', $employee->cin ?? '') }}">
                            </div>

                            <div class="col-12">
                                <label class="form-label">Notes</label>
                                <textarea name="notes" class="form-control" rows="3">{{ old('notes', $employee->notes ?? '') }}</textarea>
                            </div>
                        </div>

                        <hr>
                        <div class="d-flex justify-content-end gap-2">
                            <a href="{{ route('employees.index') }}" class="btn btn-outline-secondary">Annuler</a>
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-check-lg me-1"></i>
                                {{ isset($employee) ? 'Enregistrer' : 'Créer l\'employé' }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-layouts.app>
