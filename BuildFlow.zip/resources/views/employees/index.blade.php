<x-layouts.app title="Gestion des Employés">
    <x-slot name="breadcrumb">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="{{ route('dashboard') }}" class="text-decoration-none opacity-50 text-dark">Accueil</a></li>
                <li class="breadcrumb-item active fw-bold text-dark">Employés</li>
            </ol>
        </nav>
    </x-slot>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold text-dark mb-0">Employés</h3>
            <p class="text-secondary small mb-0">Gérez votre effectif interne et vos intervenants externes.</p>
        </div>
        @can('employees.create')
        <button type="button" class="btn btn-primary shadow-app d-flex align-items-center gap-2" onclick="empModalCreate()">
            <i class="bi bi-person-plus-fill fs-5"></i>
            <span>Nouvel employé</span>
        </button>
        @endcan
    </div>

    {{-- Filtres --}}
    <div class="card border-0 shadow-sm-app mb-4 bg-white">
        <div class="card-body p-3">
            <form method="GET" class="row g-2 align-items-center">
                <div class="col-md-3">
                    <div class="input-group input-group-sm">
                        <span class="input-group-text bg-transparent border-end-0 text-muted"><i class="bi bi-search"></i></span>
                        <input type="text" name="search" class="form-control border-start-0 ps-0"
                               placeholder="Nom, matricule..." value="{{ request('search') }}">
                    </div>
                </div>
                <div class="col-md-2">
                    <select name="job_type_id" class="form-select form-select-sm">
                        <option value="">Tous les postes</option>
                        @foreach($jobTypes as $jt)
                        <option value="{{ $jt->id }}" {{ request('job_type_id') == $jt->id ? 'selected' : '' }}>
                            {{ $jt->name }}
                        </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="region_id" class="form-select form-select-sm">
                        <option value="">Toutes les régions</option>
                        @foreach($regions as $region)
                        <option value="{{ $region->id }}" {{ request('region_id') == $region->id ? 'selected' : '' }}>
                            {{ $region->name }}
                        </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="archived" class="form-select form-select-sm">
                        <option value="">Employés actifs</option>
                        <option value="1" {{ request('archived') ? 'selected' : '' }}>Archivés</option>
                    </select>
                </div>
                <div class="col-auto ms-auto d-flex gap-2">
                    <button type="submit" class="btn btn-sm btn-primary px-3">Filtrer</button>
                    @if(request()->hasAny(['search', 'job_type_id', 'region_id', 'archived']))
                    <a href="{{ route('employees.index') }}" class="btn btn-sm btn-light border px-3">Réinitialiser</a>
                    @endif
                </div>
            </form>
        </div>
    </div>

    <div class="card border-0 shadow-sm-app overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th class="ps-4">Collaborateur</th>
                        <th>Poste</th>
                        <th>Origine</th>
                        <th>Contact</th>
                        <th>Région</th>
                        <th class="text-end pe-4">Actions</th>
                    </tr>
                </thead>
                <tbody class="border-top-0">
                    @forelse($employees as $employee)
                    <tr class="{{ $employee->trashed() ? 'bg-light text-muted opacity-75' : '' }}">
                        <td class="ps-4 py-3">
                            <div class="d-flex align-items-center">
                                <div class="avatar bg-indigo-subtle text-indigo rounded-circle p-2 d-flex align-items-center justify-content-center me-3 fw-bold" style="width: 40px; height: 40px; font-size: 0.85rem">
                                    {{ substr($employee->first_name, 0, 1) }}{{ substr($employee->last_name, 0, 1) }}
                                </div>
                                <div>
                                    @if($employee->trashed())
                                    <span class="fw-bold text-dark d-block mb-0">{{ $employee->full_name }}</span>
                                    <small class="badge bg-secondary rounded-pill" style="font-size: 0.6rem">Archivé</small>
                                    @else
                                    <a href="{{ route('employees.show', $employee) }}" class="text-decoration-none fw-bold text-dark d-block mb-0 hov-primary">
                                        {{ $employee->full_name }}
                                    </a>
                                    <span class="text-muted font-monospace small" style="font-size: 0.7rem">MAT: {{ $employee->matricule ?? 'N/A' }}</span>
                                    @endif
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="badge rounded-pill badge-soft-info px-3 py-2">
                                {{ $employee->jobType?->name ?? 'Non défini' }}
                            </span>
                        </td>
                        <td>
                            @if($employee->supplier)
                                <div class="fw-medium text-dark small"><i class="bi bi-truck me-1 text-muted"></i> {{ $employee->supplier->name }}</div>
                            @else
                                <div class="fw-medium text-primary small"><i class="bi bi-shield-check me-1"></i> Interne</div>
                            @endif
                        </td>
                        <td>
                            <div class="small fw-medium text-dark">{{ $employee->phone ?? '—' }}</div>
                            <div class="small text-muted">{{ $employee->email ?? '—' }}</div>
                        </td>
                        <td>
                            <span class="text-secondary small fw-medium"><i class="bi bi-geo-alt me-1"></i>{{ $employee->region?->name ?? '—' }}</span>
                        </td>
                        <td class="text-end pe-4">
                            <div class="d-flex justify-content-end gap-2">
                                @if($employee->trashed())
                                    <form method="POST" action="{{ route('employees.restore', $employee->id) }}">
                                        @csrf @method('PATCH')
                                        <button type="submit" class="btn btn-outline-success btn-sm rounded-pill" title="Restaurer">
                                            <i class="bi bi-arrow-counterclockwise me-1"></i> Restaurer
                                        </button>
                                    </form>
                                @else
                                    <a href="{{ route('employees.show', $employee) }}" class="btn btn-light btn-sm rounded-circle shadow-sm-app" title="Voir fiche">
                                        <i class="bi bi-eye text-primary"></i>
                                    </a>
                                    @can('employees.edit')
                                    <button type="button" class="btn btn-light btn-sm rounded-circle shadow-sm-app" title="Modifier"
                                        onclick='empModalEdit({{ json_encode(["id"=>$employee->id,"first_name"=>$employee->first_name,"last_name"=>$employee->last_name,"matricule"=>$employee->matricule,"phone"=>$employee->phone,"email"=>$employee->email,"job_type_id"=>$employee->job_type_id,"supplier_id"=>$employee->supplier_id,"region_id"=>$employee->region_id,"contract_type"=>$employee->contract_type,"hire_date"=>$employee->hire_date?->format('Y-m-d'),"daily_rate"=>$employee->daily_rate,"monthly_salary"=>$employee->monthly_salary,"notes"=>$employee->notes]) }})'>
                                        <i class="bi bi-pencil text-info"></i>
                                    </button>
                                    @endcan
                                    @can('employees.delete')
                                    <form method="POST" action="{{ route('employees.destroy', $employee) }}"
                                          onsubmit="return confirm('Archiver cet employé ?')">
                                        @csrf @method('DELETE')
                                        <button type="submit" class="btn btn-light btn-sm rounded-circle shadow-sm-app" title="Archiver">
                                            <i class="bi bi-archive text-warning"></i>
                                        </button>
                                    </form>
                                    @endcan
                                @endif
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" class="text-center py-5">
                            <div class="py-5">
                                <i class="bi bi-person-badge fs-1 opacity-25 d-block mb-3"></i>
                                <h5 class="text-muted">Aucun employé trouvé</h5>
                                <p class="text-muted small">Vos collaborateurs et sous-traitants apparaîtront ici.</p>
                            </div>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($employees->hasPages())
        <div class="card-footer bg-white py-3 border-top border-light">
            {{ $employees->links() }}
        </div>
        @endif
    </div>

    {{-- Modal Employé --}}
    <div class="modal fade" id="empModal" tabindex="-1">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content border-0 shadow-app">
                <form id="empForm" method="POST">
                    @csrf
                    <input type="hidden" name="_method" id="empMethod" value="">
                    <div class="modal-header border-bottom-0 p-4">
                        <h5 class="modal-title fw-bold" id="empModalTitle">Nouvel employé</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body p-4 pt-0">
                        <div class="row g-4">
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Prénom <span class="text-danger">*</span></label>
                                <input type="text" name="first_name" id="eFirstName" class="form-control" required placeholder="Ex: Jean">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Nom <span class="text-danger">*</span></label>
                                <input type="text" name="last_name" id="eLastName" class="form-control" required placeholder="Ex: DUPONT">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Matricule</label>
                                <input type="text" name="matricule" id="eMatricule" class="form-control" placeholder="ID Interne">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Téléphone</label>
                                <input type="text" name="phone" id="ePhone" class="form-control" placeholder="+261 ...">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Email</label>
                                <input type="email" name="email" id="eEmail" class="form-control" placeholder="email@entreprise.mg">
                            </div>
                            
                            <div class="col-12">
                                <hr class="my-2 border-light">
                                <h6 class="text-primary fw-bold mb-3 small text-uppercase">Affectation & Contrat</h6>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Poste / Fonction</label>
                                <select name="job_type_id" id="eJobType" class="form-select">
                                    <option value="">Sélectionner un poste...</option>
                                    @foreach($jobTypes as $jt)
                                    <option value="{{ $jt->id }}">{{ $jt->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Région principale</label>
                                <select name="region_id" id="eRegion" class="form-select">
                                    <option value="">Sélectionner une région...</option>
                                    @foreach($regions as $region)
                                    <option value="{{ $region->id }}">{{ $region->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Type de contrat</label>
                                <select name="contract_type" id="eContractType" class="form-select">
                                    <option value="">—</option>
                                    <option value="journalier">Journalier</option>
                                    <option value="mensuel">Mensuel</option>
                                    <option value="sous_traitant">Sous-traitant</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Taux journalier</label>
                                <div class="input-group">
                                    <input type="number" name="daily_rate" id="eDailyRate" class="form-control" step="0.01" min="0">
                                    <span class="input-group-text bg-light small">MGA</span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Date d'embauche</label>
                                <input type="date" name="hire_date" id="eHireDate" class="form-control">
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-semibold">Notes / Observations</label>
                                <textarea name="notes" id="eNotes" class="form-control" rows="2" placeholder="Informations complémentaires..."></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer border-top-0 p-4 pt-0">
                        <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary px-4 shadow-sm-app">
                            <i class="bi bi-check2-circle me-2"></i>Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
    function empModalCreate() {
        document.getElementById('empModalTitle').textContent = 'Créer une fiche employé';
        document.getElementById('empForm').action = '{{ route('employees.store') }}';
        document.getElementById('empMethod').value = '';
        ['eFirstName','eLastName','eMatricule','ePhone','eEmail','eDailyRate','eHireDate','eNotes'].forEach(function(id) {
            var el = document.getElementById(id); if (el) el.value = '';
        });
        document.getElementById('eJobType').value = '';
        document.getElementById('eRegion').value = '';
        document.getElementById('eContractType').value = '';
        new bootstrap.Modal(document.getElementById('empModal')).show();
    }
    function empModalEdit(data) {
        document.getElementById('empModalTitle').textContent = 'Modifier la fiche employé';
        document.getElementById('empForm').action = '/employees/' + data.id;
        document.getElementById('empMethod').value = 'PATCH';
        document.getElementById('eFirstName').value    = data.first_name    || '';
        document.getElementById('eLastName').value     = data.last_name     || '';
        document.getElementById('eMatricule').value    = data.matricule     || '';
        document.getElementById('ePhone').value        = data.phone         || '';
        document.getElementById('eEmail').value        = data.email         || '';
        document.getElementById('eJobType').value      = data.job_type_id   || '';
        document.getElementById('eRegion').value       = data.region_id     || '';
        document.getElementById('eContractType').value = data.contract_type || '';
        document.getElementById('eDailyRate').value    = data.daily_rate    || '';
        document.getElementById('eHireDate').value     = data.hire_date     || '';
        document.getElementById('eNotes').value        = data.notes         || '';
        new bootstrap.Modal(document.getElementById('empModal')).show();
    }
    </script>
</x-layouts.app>
