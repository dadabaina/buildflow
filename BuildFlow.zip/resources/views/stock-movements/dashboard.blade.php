<x-layouts.app>
    <x-slot name="breadcrumb">
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item active">Dashboard stock</li>
        </ol>
    </x-slot>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-0">Dashboard Stock</h3>
            <p class="text-secondary small mt-1">Vue d'ensemble des dépôts et niveaux de stock.</p>
        </div>
        <div class="d-flex gap-2">
            <a href="{{ route('stock-movements.index') }}" class="btn btn-outline-secondary btn-sm">
                <i class="bi bi-list me-1"></i>Tous les mouvements
            </a>
            @can('stock.create')
            <a href="{{ route('stock-movements.create') }}" class="btn btn-primary btn-sm">
                <i class="bi bi-plus-lg me-1"></i>Nouveau mouvement
            </a>
            @endcan
        </div>
    </div>

    {{-- Cards dépôts --}}
    <div class="row g-3 mb-4">
        @foreach($warehouses as $wh)
        <div class="col-md-4">
            <div class="card border-0 shadow-sm-app rounded-4 p-3">
                <div class="d-flex align-items-center gap-3">
                    <div class="bg-primary-subtle rounded-3 p-2"><i class="bi bi-building text-primary fs-4"></i></div>
                    <div>
                        <p class="fw-bold mb-0">{{ $wh->name }}</p>
                        <small class="text-muted">{{ $wh->location ?? 'Pas d\'adresse' }}</small>
                    </div>
                </div>
            </div>
        </div>
        @endforeach
    </div>

    <div class="row g-4">
        {{-- Soldes par article --}}
        <div class="col-lg-7">
            <x-card title="Soldes de stock par article">
                <div class="table-responsive">
                    <table class="table table-sm align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th>Article</th>
                                <th>Dépôt</th>
                                <th>Unité</th>
                                <th class="text-end">Solde</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($stockByItem as $item)
                            <tr class="{{ $item->balance <= 0 ? 'table-warning' : '' }}">
                                <td class="fw-semibold">{{ $item->item_name }}</td>
                                <td class="text-muted small">{{ $item->warehouse->name ?? '—' }}</td>
                                <td class="text-muted">{{ $item->unit }}</td>
                                <td class="text-end fw-bold {{ $item->balance < 0 ? 'text-danger' : ($item->balance == 0 ? 'text-warning' : 'text-success') }}">
                                    {{ number_format($item->balance, 3, ',', ' ') }}
                                </td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="4" class="text-center text-muted py-3">Aucun stock disponible.</td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </x-card>
        </div>

        {{-- Mouvements récents --}}
        <div class="col-lg-5">
            <x-card title="Derniers mouvements">
                <div class="list-group list-group-flush">
                    @forelse($recent as $m)
                    <div class="list-group-item px-0 py-2">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="mb-0 fw-semibold small">{{ $m->item_name }}</p>
                                <p class="mb-0 text-muted" style="font-size: .75rem;">
                                    {{ $m->movement_date->format('d/m/Y') }} · {{ $m->warehouse->name ?? '—' }}
                                </p>
                            </div>
                            <span class="badge bg-{{ $m->typeColor() }}">{{ $m->typeLabel() }} {{ number_format($m->quantity, 2, ',', ' ') }}</span>
                        </div>
                    </div>
                    @empty
                    <p class="text-center text-muted py-3">Aucun mouvement récent.</p>
                    @endforelse
                </div>
            </x-card>
        </div>
    </div>
</x-layouts.app>
