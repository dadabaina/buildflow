<x-layouts.app>
    <x-slot name="breadcrumb">
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="{{ route('stock-movements.index') }}">Stocks</a></li>
            <li class="breadcrumb-item active">Nouveau mouvement</li>
        </ol>
    </x-slot>

    <div class="row justify-content-center">
        <div class="col-lg-9">
            <x-card title="Nouveau mouvement de stock">
                <form method="POST" action="{{ route('stock-movements.store') }}">
                    @csrf
                    <div class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label fw-semibold small">Type <span class="text-danger">*</span></label>
                            <select name="type" class="form-select" required>
                                <option value="entree" {{ old('type') === 'entree' ? 'selected' : '' }}>Entrée</option>
                                <option value="sortie" {{ old('type') === 'sortie' ? 'selected' : '' }}>Sortie</option>
                                <option value="transfert" {{ old('type') === 'transfert' ? 'selected' : '' }}>Transfert</option>
                                <option value="ajustement" {{ old('type') === 'ajustement' ? 'selected' : '' }}>Ajustement</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold small">Date <span class="text-danger">*</span></label>
                            <input type="date" name="movement_date" class="form-control"
                                   value="{{ old('movement_date', now()->format('Y-m-d')) }}" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Dépôt <span class="text-danger">*</span></label>
                            <select name="warehouse_id" class="form-select" required>
                                <option value="">— Sélectionner un dépôt —</option>
                                @foreach($warehouses as $wh)
                                    <option value="{{ $wh->id }}" {{ old('warehouse_id') == $wh->id ? 'selected' : '' }}>{{ $wh->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Article / Désignation <span class="text-danger">*</span></label>
                            <input type="text" name="item_name" class="form-control"
                                   value="{{ old('item_name') }}" required list="materials-list" placeholder="Nom de l'article">
                            <datalist id="materials-list">
                                @foreach($materials as $mat)
                                <option value="{{ $mat->name }}">
                                @endforeach
                            </datalist>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold small">Unité <span class="text-danger">*</span></label>
                            <input type="text" name="unit" class="form-control" value="{{ old('unit', 'u') }}" required placeholder="Ex: m³, kg, u">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold small">Quantité <span class="text-danger">*</span></label>
                            <input type="number" name="quantity" class="form-control" step="0.001" min="0.001"
                                   value="{{ old('quantity') }}" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold small">Prix unitaire (Ar)</label>
                            <input type="number" name="unit_cost" class="form-control" step="0.01" min="0"
                                   value="{{ old('unit_cost', 0) }}">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold small">Référence</label>
                            <input type="text" name="reference" class="form-control"
                                   value="{{ old('reference') }}" placeholder="N° BL, BM...">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Chantier associé</label>
                            <select name="project_id" class="form-select">
                                <option value="">— Aucun —</option>
                                @foreach($projects as $p)
                                    <option value="{{ $p->id }}" {{ old('project_id') == $p->id ? 'selected' : '' }}>{{ $p->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Matériau du catalogue</label>
                            <select name="material_id" class="form-select">
                                <option value="">— Optionnel —</option>
                                @foreach($materials as $mat)
                                    <option value="{{ $mat->id }}" {{ old('material_id') == $mat->id ? 'selected' : '' }}>{{ $mat->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold small">Notes</label>
                            <textarea name="notes" class="form-control" rows="2">{{ old('notes') }}</textarea>
                        </div>
                    </div>
                    <div class="mt-4 pt-3 border-top d-flex gap-2 justify-content-end">
                        <a href="{{ route('stock-movements.index') }}" class="btn btn-light">Annuler</a>
                        <button type="submit" class="btn btn-primary px-4">
                            <i class="bi bi-check2 me-1"></i>Enregistrer le mouvement
                        </button>
                    </div>
                </form>
            </x-card>
        </div>
    </div>
</x-layouts.app>
