<x-layouts.app>
    <x-slot name="breadcrumb">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Tableau de bord</a></li>
                <li class="breadcrumb-item active">Compte-rendus de chantier</li>
            </ol>
        </nav>
    </x-slot>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-0">Compte-rendus de chantier</h3>
            <p class="text-secondary small mt-1">Historique des réunions et comptes-rendus de chantier.</p>
        </div>
        @can('site_reports.create')
        <a href="{{ route('site-reports.create') }}" class="btn btn-primary shadow-app">
            <i class="bi bi-plus-lg me-1"></i>Nouveau CR
        </a>
        @endcan
    </div>

    {{-- Filtres --}}
    <form method="GET" class="row g-2 mb-4">
        <div class="col-md-4">
            <select name="project_id" class="form-select" onchange="this.form.submit()">
                <option value="">Tous les chantiers</option>
                @foreach($projects as $p)
                    <option value="{{ $p->id }}" {{ request('project_id') == $p->id ? 'selected' : '' }}>{{ $p->name }}</option>
                @endforeach
            </select>
        </div>
        <div class="col-md-3">
            <select name="status" class="form-select" onchange="this.form.submit()">
                <option value="">Tous statuts</option>
                <option value="brouillon" {{ request('status') === 'brouillon' ? 'selected' : '' }}>Brouillon</option>
                <option value="finalise" {{ request('status') === 'finalise' ? 'selected' : '' }}>Finalisé</option>
            </select>
        </div>
    </form>

    <x-card>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-light">
                    <tr>
                        <th>Référence</th>
                        <th>Titre</th>
                        <th>Chantier</th>
                        <th>Date</th>
                        <th>Rédacteur</th>
                        <th>Statut</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($siteReports as $cr)
                    <tr>
                        <td class="fw-mono text-primary">{{ $cr->reference ?? '—' }}</td>
                        <td class="fw-semibold">{{ $cr->title }}</td>
                        <td class="text-muted">{{ $cr->project->name ?? '—' }}</td>
                        <td>{{ $cr->report_date->format('d/m/Y') }}</td>
                        <td>{{ $cr->author->name ?? '—' }}</td>
                        <td>
                            <span class="badge bg-{{ $cr->status === 'finalise' ? 'success' : 'warning text-dark' }}-subtle text-{{ $cr->status === 'finalise' ? 'success' : 'warning' }} border">
                                {{ $cr->status === 'finalise' ? 'Finalisé' : 'Brouillon' }}
                            </span>
                        </td>
                        <td class="text-end">
                            <a href="{{ route('site-reports.show', $cr) }}" class="btn btn-sm btn-light"><i class="bi bi-eye"></i></a>
                            @if($cr->status !== 'finalise')
                            <a href="{{ route('site-reports.edit', $cr) }}" class="btn btn-sm btn-light"><i class="bi bi-pencil"></i></a>
                            @endif
                            <a href="{{ route('site-reports.export', $cr) }}" class="btn btn-sm btn-light" title="Exporter PDF"><i class="bi bi-file-pdf text-danger"></i></a>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" class="text-center text-muted py-5">
                            <i class="bi bi-file-earmark-text display-6 d-block mb-2 opacity-25"></i>
                            Aucun compte-rendu trouvé.
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($siteReports->hasPages())
        <div class="mt-3">{{ $siteReports->links() }}</div>
        @endif
    </x-card>
</x-layouts.app>
