<x-layouts.app :title="$material->name">
    <x-slot name="breadcrumb">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Accueil</a></li>
                <li class="breadcrumb-item"><a href="{{ route('materials.index') }}">Matériaux</a></li>
                <li class="breadcrumb-item active">{{ $material->name }}</li>
            </ol>
        </nav>
    </x-slot>

    <div class="d-flex justify-content-between align-items-start mb-4">
        <div>
            <h5 class="mb-1 fw-bold">{{ $material->name }}</h5>
            <div class="d-flex gap-2 flex-wrap">
                <span class="badge bg-light text-dark border">{{ $material->unit }}</span>
                @if($material->category)
                <span class="badge bg-secondary">{{ $material->category->name }}</span>
                @endif
                @if($material->reference)
                <span class="badge bg-light text-muted border font-monospace small">{{ $material->reference }}</span>
                @endif
                <span class="badge {{ $material->is_active ? 'bg-success' : 'bg-secondary' }}">
                    {{ $material->is_active ? 'Actif' : 'Inactif' }}
                </span>
            </div>
        </div>
        <div class="d-flex gap-2">
            @can('materials.edit')
            <a href="{{ route('materials.edit', $material) }}" class="btn btn-outline-primary btn-sm">
                <i class="bi bi-pencil me-1"></i>Modifier
            </a>
            @endcan
            @can('materials.delete')
            <form method="POST" action="{{ route('materials.destroy', $material) }}"
                  onsubmit="return confirm('Supprimer ce matériau ?')">
                @csrf @method('DELETE')
                <button class="btn btn-outline-danger btn-sm"><i class="bi bi-trash"></i></button>
            </form>
            @endcan
        </div>
    </div>

    @if($material->description)
    <p class="text-muted small mb-4">{{ $material->description }}</p>
    @endif

    <div class="row g-4">
        {{-- Historique des prix --}}
        <div class="col-lg-7">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h6 class="mb-0 fw-semibold">Historique des prix</h6>
                    <button class="btn btn-sm btn-outline-primary" data-bs-toggle="collapse" data-bs-target="#addPrice">
                        <i class="bi bi-plus"></i> Ajouter un prix
                    </button>
                </div>

                <div class="collapse" id="addPrice">
                    <div class="card-body border-bottom bg-light">
                        <form method="POST" action="{{ route('materials.prices.store', $material) }}">
                            @csrf
                            <div class="row g-2">
                                <div class="col-md-3">
                                    <label class="form-label form-label-sm">Prix (MGA) *</label>
                                    <input type="number" name="unit_price" class="form-control form-control-sm"
                                           step="1" min="0" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label form-label-sm">Date effective *</label>
                                    <input type="date" name="effective_date" class="form-control form-control-sm"
                                           value="{{ now()->format('Y-m-d') }}" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label form-label-sm">Région</label>
                                    <select name="region_id" class="form-select form-select-sm">
                                        <option value="">Général</option>
                                        @foreach($regions as $region)
                                        <option value="{{ $region->id }}">{{ $region->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label form-label-sm">Fournisseur</label>
                                    <input type="text" name="supplier_name" class="form-control form-control-sm"
                                           placeholder="Optionnel">
                                </div>
                                <div class="col-12 text-end">
                                    <button class="btn btn-sm btn-primary"><i class="bi bi-check me-1"></i>Enregistrer</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-sm mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Date</th>
                                <th>Région</th>
                                <th>Fournisseur</th>
                                <th class="text-end">Prix unitaire</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($material->prices as $price)
                            <tr>
                                <td class="small">{{ $price->effective_date->format('d/m/Y') }}</td>
                                <td class="small">{{ $price->region?->name ?? '<span class="text-muted">Général</span>' }}</td>
                                <td class="small text-muted">{{ $price->supplier_name ?? '—' }}</td>
                                <td class="text-end fw-medium">{{ number_format($price->unit_price, 0, ',', ' ') }}</td>
                                <td>
                                    @can('materials.edit')
                                    <form method="POST" action="{{ route('materials.prices.destroy', [$material, $price]) }}"
                                          onsubmit="return confirm('Supprimer ce prix ?')">
                                        @csrf @method('DELETE')
                                        <button class="btn btn-sm btn-link text-danger p-0"><i class="bi bi-x"></i></button>
                                    </form>
                                    @endcan
                                </td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="5" class="text-center text-muted py-3 small">
                                    Aucun prix enregistré
                                </td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        {{-- Utilisé dans les dosages --}}
        <div class="col-lg-5">
            <div class="card">
                <div class="card-header">
                    <h6 class="mb-0 fw-semibold">Utilisé dans les dosages</h6>
                </div>
                <ul class="list-group list-group-flush">
                    @forelse($material->dosageItems->groupBy('dosage_model_id') as $modelId => $items)
                    @php $dm = $items->first()->dosageModel; @endphp
                    <li class="list-group-item py-2">
                        <a href="{{ route('dosage.show', $dm) }}" class="text-decoration-none fw-medium small">
                            {{ $dm->name }}
                        </a>
                        <span class="text-muted small ms-1">
                            — {{ $items->first()->quantity_per_unit }} {{ $items->first()->unit }} / {{ $dm->output_unit }}
                        </span>
                    </li>
                    @empty
                    <li class="list-group-item text-muted small py-3 text-center">
                        Non utilisé dans un dosage
                    </li>
                    @endforelse
                </ul>
            </div>
        </div>
    </div>
</x-layouts.app>
