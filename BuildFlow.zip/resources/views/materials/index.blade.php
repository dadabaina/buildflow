<x-layouts.app title="Matériaux">
    <x-slot name="breadcrumb">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Accueil</a></li>
                <li class="breadcrumb-item active">Matériaux</li>
            </ol>
        </nav>
    </x-slot>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h5 class="mb-0 fw-bold">
            <i class="bi bi-boxes me-2 text-primary"></i>Catalogue matériaux
            <span class="badge bg-secondary ms-2">{{ $materials->total() }}</span>
        </h5>
        @can('materials.create')
        <div class="d-flex gap-2">
            <a href="{{ route('materials.export') }}" class="btn btn-outline-secondary btn-sm">
                <i class="bi bi-download me-1"></i>Exporter CSV
            </a>
            <a href="{{ route('materials.create') }}" class="btn btn-primary">
                <i class="bi bi-plus-lg me-1"></i>Nouveau matériau
            </a>
        </div>
        @endcan
    </div>

    {{-- Filtres --}}
    <form method="GET" class="row g-2 mb-3">
        <div class="col-md-5">
            <input type="text" name="search" class="form-control" placeholder="Rechercher..."
                   value="{{ request('search') }}">
        </div>
        <div class="col-md-4">
            <select name="category_id" class="form-select">
                <option value="">Toutes les catégories</option>
                @foreach($categories as $cat)
                <option value="{{ $cat->id }}" {{ request('category_id') == $cat->id ? 'selected' : '' }}>
                    {{ $cat->name }}
                </option>
                @endforeach
            </select>
        </div>
        <div class="col-md-3 d-flex gap-2">
            <button class="btn btn-outline-secondary w-100">Filtrer</button>
            <a href="{{ route('materials.index') }}" class="btn btn-outline-secondary">✕</a>
        </div>
    </form>

    <div class="card">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Nom</th>
                        <th>Référence</th>
                        <th>Catégorie</th>
                        <th>Unité</th>
                        <th class="text-end">Prix actuel</th>
                        <th class="text-center">Statut</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($materials as $mat)
                    <tr>
                        <td class="fw-medium">
                            <a href="{{ route('materials.show', $mat) }}" class="text-decoration-none">
                                {{ $mat->name }}
                            </a>
                        </td>
                        <td class="small text-muted font-monospace">{{ $mat->reference ?? '—' }}</td>
                        <td class="small">{{ $mat->category?->name ?? '—' }}</td>
                        <td><span class="badge bg-light text-dark border">{{ $mat->unit }}</span></td>
                        <td class="text-end small">
                            @php $price = $mat->currentPrice(); @endphp
                            @if($price !== null)
                                {{ number_format($price, 0, ',', ' ') }}
                            @else
                                <span class="text-danger small">Non défini</span>
                            @endif
                        </td>
                        <td class="text-center">
                            @if($mat->is_active)
                                <span class="badge bg-success">Actif</span>
                            @else
                                <span class="badge bg-secondary">Inactif</span>
                            @endif
                        </td>
                        <td class="text-end">
                            <div class="btn-group btn-group-sm">
                                <a href="{{ route('materials.show', $mat) }}" class="btn btn-outline-secondary"><i class="bi bi-eye"></i></a>
                                @can('materials.edit')
                                <a href="{{ route('materials.edit', $mat) }}" class="btn btn-outline-primary"><i class="bi bi-pencil"></i></a>
                                @endcan
                                @can('materials.delete')
                                <form method="POST" action="{{ route('materials.destroy', $mat) }}"
                                      onsubmit="return confirm('Supprimer ce matériau ?')">
                                    @csrf @method('DELETE')
                                    <button class="btn btn-outline-danger"><i class="bi bi-trash"></i></button>
                                </form>
                                @endcan
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" class="text-center text-muted py-4">
                            <i class="bi bi-boxes fs-2 d-block mb-2"></i>
                            Aucun matériau trouvé
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($materials->hasPages())
        <div class="card-footer">{{ $materials->links() }}</div>
        @endif
    </div>
</x-layouts.app>
