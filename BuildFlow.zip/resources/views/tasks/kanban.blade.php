<x-layouts.app title="Kanban — Tâches">
    <x-slot name="breadcrumb">
        <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Accueil</a></li>
        <li class="breadcrumb-item"><a href="{{ route('tasks.index') }}">Tâches</a></li>
        <li class="breadcrumb-item active">Kanban</li>
    </x-slot>

    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="mb-0"><i class="bi bi-grid-3x3-gap me-2"></i>Kanban</h4>
        <div class="d-flex gap-2 align-items-center">
            <form method="GET" class="d-flex gap-2">
                <select name="project_id" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">Tous les chantiers</option>
                    @foreach($projects as $p)
                        <option value="{{ $p->id }}" @selected($projectId == $p->id)>{{ $p->name }}</option>
                    @endforeach
                </select>
            </form>
            <a href="{{ route('tasks.index') }}" class="btn btn-outline-secondary btn-sm">
                <i class="bi bi-list-ul me-1"></i>Liste
            </a>
            @can('tasks.create')
                <a href="{{ route('tasks.create', ['project_id' => $projectId]) }}" class="btn btn-primary btn-sm">
                    <i class="bi bi-plus-lg"></i>
                </a>
            @endcan
        </div>
    </div>

    @php
    $colConfig = [
        'a_faire'  => ['label' => 'À faire',   'icon' => 'bi-circle',       'hdr' => 'bg-secondary text-white'],
        'en_cours' => ['label' => 'En cours',   'icon' => 'bi-arrow-repeat', 'hdr' => 'bg-primary text-white'],
        'en_pause' => ['label' => 'En pause',   'icon' => 'bi-pause-circle', 'hdr' => 'bg-warning text-dark'],
        'termine'  => ['label' => 'Terminées',  'icon' => 'bi-check-circle', 'hdr' => 'bg-success text-white'],
    ];
    @endphp

    <div class="row g-3">
        @foreach($colConfig as $status => $cfg)
            <div class="col-md-3">
                <div class="card h-100">
                    <div class="card-header {{ $cfg['hdr'] }} py-2">
                        <strong><i class="bi {{ $cfg['icon'] }} me-1"></i>{{ $cfg['label'] }}</strong>
                        <span class="badge bg-white text-dark ms-1">{{ $columns[$status]->count() }}</span>
                    </div>
                    <div class="card-body p-2" style="min-height:200px">
                        @forelse($columns[$status] as $task)
                            <div class="card card-body p-2 mb-2 shadow-sm">
                                <div class="d-flex justify-content-between align-items-start mb-1">
                                    <a href="{{ route('tasks.show', $task) }}" class="fw-semibold text-dark text-decoration-none small">
                                        {{ $task->title }}
                                    </a>
                                    <span class="badge {{ $task->priority_badge_class }} ms-1">{{ substr($task->priority,0,1) }}</span>
                                </div>
                                @if($task->due_date)
                                    <div class="small {{ $task->isOverdue() ? 'text-danger fw-semibold' : 'text-muted' }}">
                                        <i class="bi bi-calendar3 me-1"></i>{{ $task->due_date->format('d/m/Y') }}
                                    </div>
                                @endif
                                @if($task->employees->count())
                                    <div class="mt-1">
                                        @foreach($task->employees->take(3) as $emp)
                                            <span class="badge bg-light text-dark border" style="font-size:.65rem">{{ $emp->first_name }}</span>
                                        @endforeach
                                    </div>
                                @endif
                            </div>
                        @empty
                            <p class="text-muted text-center small mt-3">Aucune tâche</p>
                        @endforelse
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</x-layouts.app>
