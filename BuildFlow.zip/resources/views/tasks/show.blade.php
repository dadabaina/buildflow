<x-layouts.app :title="$task->title">
    <x-slot name="breadcrumb">
        <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Accueil</a></li>
        <li class="breadcrumb-item"><a href="{{ route('tasks.index') }}">Tâches</a></li>
        <li class="breadcrumb-item active">{{ Str::limit($task->title, 40) }}</li>
    </x-slot>

    <div class="row">
        <div class="col-xl-8">
            {{-- Tâche --}}
            <div class="card mb-3">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        {{ $task->title }}
                        <span class="badge {{ $task->status_badge_class }} ms-2">{{ $task->status_libelle }}</span>
                        <span class="badge {{ $task->priority_badge_class }} ms-1">{{ ucfirst($task->priority) }}</span>
                        @if($task->isOverdue())
                            <span class="badge bg-danger ms-1">En retard</span>
                        @endif
                    </h5>
                    <a href="{{ route('tasks.edit', $task) }}" class="btn btn-outline-secondary btn-sm">
                        <i class="bi bi-pencil me-1"></i>Modifier
                    </a>
                </div>
                <div class="card-body">
                    <div class="row g-3 mb-3">
                        <div class="col-md-4">
                            <small class="text-muted d-block">Chantier</small>
                            <strong>{{ $task->project->name ?? '-' }}</strong>
                        </div>
                        <div class="col-md-4">
                            <small class="text-muted d-block">Échéance</small>
                            {{ $task->due_date ? $task->due_date->format('d/m/Y') : 'Non définie' }}
                        </div>
                        <div class="col-md-4">
                            <small class="text-muted d-block">Créé par</small>
                            {{ $task->createdBy->name ?? '-' }}
                        </div>
                    </div>

                    @if($task->description)
                        <p class="mb-3">{{ $task->description }}</p>
                    @endif

                    {{-- Assignés --}}
                    @if($task->employees->count())
                        <div class="mb-3">
                            <small class="text-muted d-block mb-1">Assigné(e)s</small>
                            @foreach($task->employees as $emp)
                                <span class="badge bg-light text-dark border me-1">
                                    {{ $emp->first_name }} {{ $emp->last_name }}
                                </span>
                            @endforeach
                        </div>
                    @endif

                    {{-- Checklist --}}
                    @if($task->checklist && count($task->checklist))
                        <div class="mb-3">
                            <small class="text-muted d-block mb-1">Checklist</small>
                            @foreach($task->checklist as $item)
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox"
                                           @if(!empty($item['done'])) checked @endif disabled>
                                    <label class="form-check-label {{ !empty($item['done']) ? 'text-decoration-line-through text-muted' : '' }}">
                                        {{ $item['label'] ?? '' }}
                                    </label>
                                </div>
                            @endforeach
                        </div>
                    @endif
                </div>
            </div>

            {{-- Commentaires --}}
            <div class="card">
                <div class="card-header"><h6 class="mb-0">Commentaires</h6></div>
                <div class="card-body">
                    @foreach($task->comments as $comment)
                        <div class="d-flex mb-3">
                            <div class="me-2 flex-shrink-0">
                                <span class="avatar-sm bg-primary text-white rounded-circle d-flex align-items-center justify-content-center"
                                      style="width:36px;height:36px;font-size:.85rem">
                                    {{ strtoupper(substr($comment->user->name ?? '?', 0, 1)) }}
                                </span>
                            </div>
                            <div class="flex-grow-1">
                                <div class="d-flex align-items-center gap-2 mb-1">
                                    <strong>{{ $comment->user->name ?? 'Inconnu' }}</strong>
                                    <small class="text-muted">{{ $comment->created_at->diffForHumans() }}</small>
                                </div>
                                <p class="mb-0">{{ $comment->body }}</p>
                            </div>
                        </div>
                    @endforeach

                    @auth
                        <form method="POST" action="{{ route('tasks.comments.store', $task) }}" class="mt-3">
                            @csrf
                            <div class="mb-2">
                                <textarea name="body" class="form-control @error('body') is-invalid @enderror"
                                          rows="2" placeholder="Ajouter un commentaire…" required></textarea>
                                @error('body')<div class="invalid-feedback">{{ $message }}</div>@enderror
                            </div>
                            <button type="submit" class="btn btn-primary btn-sm">
                                <i class="bi bi-chat-dots me-1"></i>Commenter
                            </button>
                        </form>
                    @endauth
                </div>
            </div>
        </div>

        {{-- Sidebar statut --}}
        <div class="col-xl-4">
            <div class="card mb-3">
                <div class="card-header"><h6 class="mb-0">Changer le statut</h6></div>
                <div class="card-body">
                    @foreach(['a_faire'=>'À faire','en_cours'=>'En cours','en_pause'=>'En pause','termine'=>'Terminée','annule'=>'Annulée'] as $val=>$lbl)
                        @if($val !== $task->status)
                            <form method="POST" action="{{ route('tasks.status', $task) }}" class="mb-1">
                                @csrf @method('PATCH')
                                <input type="hidden" name="status" value="{{ $val }}">
                                <button class="btn btn-outline-secondary btn-sm w-100">→ {{ $lbl }}</button>
                            </form>
                        @endif
                    @endforeach
                </div>
            </div>

            @can('delete', $task)
                <div class="card border-danger">
                    <div class="card-header bg-danger text-white"><h6 class="mb-0">Zone danger</h6></div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('tasks.destroy', $task) }}"
                              onsubmit="return confirm('Supprimer cette tâche ?')">
                            @csrf @method('DELETE')
                            <button class="btn btn-danger btn-sm w-100">
                                <i class="bi bi-trash me-1"></i>Supprimer
                            </button>
                        </form>
                    </div>
                </div>
            @endcan
        </div>
    </div>
</x-layouts.app>
