<x-layouts.app>
    <x-slot name="breadcrumb">
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Tableau de bord</a></li>
            <li class="breadcrumb-item active">PV de réception</li>
        </ol>
    </x-slot>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-0">PV de réception</h3>
            <p class="text-secondary small mt-1">Procès-verbaux de réception de chantiers terminés.</p>
        </div>
        @can('reception_reports.create')
        <a href="{{ route('reception-reports.create') }}" class="btn btn-primary shadow-app">
            <i class="bi bi-plus-lg me-1"></i>Nouveau PV
        </a>
        @endcan
    </div>

    <form method="GET" class="row g-2 mb-4">
        <div class="col-md-4">
            <select name="project_id" class="form-select" onchange="this.form.submit()">
                <option value="">Tous les chantiers</option>
                @foreach($projects as $p)
                    <option value="{{ $p->id }}" {{ request('project_id') == $p->id ? 'selected' : '' }}>{{ $p->name }}</option>
                @endforeach
            </select>
        </div>
        <div class="col-md-3">
            <select name="status" class="form-select" onchange="this.form.submit()">
                <option value="">Tous statuts</option>
                <option value="brouillon" {{ request('status') === 'brouillon' ? 'selected' : '' }}>Brouillon</option>
                <option value="signe" {{ request('status') === 'signe' ? 'selected' : '' }}>Signé</option>
                <option value="rg_libere" {{ request('status') === 'rg_libere' ? 'selected' : '' }}>RG libérée</option>
            </select>
        </div>
    </form>

    <x-card>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-light">
                    <tr>
                        <th>Référence</th>
                        <th>Chantier</th>
                        <th>Date réception</th>
                        <th>Client</th>
                        <th class="text-end">RG (Ar)</th>
                        <th>Statut</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($receptionReports as $pv)
                    <tr>
                        <td class="fw-mono text-primary">{{ $pv->reference ?? '—' }}</td>
                        <td class="fw-semibold">{{ $pv->project->name ?? '—' }}</td>
                        <td>{{ $pv->reception_date->format('d/m/Y') }}</td>
                        <td class="text-muted">{{ $pv->client_name ?? '—' }}</td>
                        <td class="text-end">{{ $pv->rg_amount > 0 ? number_format($pv->rg_amount, 0, ',', ' ') : '—' }}</td>
                        <td>
                            @php
                                $colors = ['brouillon' => 'warning text-dark', 'signe' => 'primary', 'rg_libere' => 'success'];
                                $labels = ['brouillon' => 'Brouillon', 'signe' => 'Signé', 'rg_libere' => 'RG libérée'];
                            @endphp
                            <span class="badge bg-{{ $colors[$pv->status] ?? 'secondary' }}">{{ $labels[$pv->status] ?? $pv->status }}</span>
                        </td>
                        <td class="text-end">
                            <a href="{{ route('reception-reports.show', $pv) }}" class="btn btn-sm btn-light"><i class="bi bi-eye"></i></a>
                            <a href="{{ route('reception-reports.export', $pv) }}" class="btn btn-sm btn-light" title="PDF"><i class="bi bi-file-pdf text-danger"></i></a>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" class="text-center text-muted py-5">
                            <i class="bi bi-clipboard-check display-6 d-block mb-2 opacity-25"></i>
                            Aucun PV de réception trouvé.
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($receptionReports->hasPages())
        <div class="mt-3">{{ $receptionReports->links() }}</div>
        @endif
    </x-card>
</x-layouts.app>
