<x-layouts.app :title="'BC ' . $purchaseOrder->reference">
    <x-slot name="breadcrumb">
        <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Accueil</a></li>
        <li class="breadcrumb-item"><a href="{{ route('purchase-orders.index') }}">Bons de commande</a></li>
        <li class="breadcrumb-item active">{{ $purchaseOrder->reference }}</li>
    </x-slot>

    <div class="row">
        <div class="col-xl-8">
            <div class="card mb-3">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        <i class="bi bi-file-earmark-check me-2"></i>{{ $purchaseOrder->reference }}
                        <span class="badge {{ $purchaseOrder->status_badge_class }} ms-2">{{ $purchaseOrder->status_libelle }}</span>
                    </h5>
                    <div>
                        @if(in_array($purchaseOrder->status, ['brouillon','envoye']))
                            <a href="{{ route('purchase-orders.edit', $purchaseOrder) }}" class="btn btn-outline-secondary btn-sm">
                                <i class="bi bi-pencil me-1"></i>Modifier
                            </a>
                        @endif
                    </div>
                </div>
                <div class="card-body">
                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <small class="text-muted d-block">Chantier</small>
                            <strong>{{ $purchaseOrder->project->name ?? '-' }}</strong>
                        </div>
                        <div class="col-md-6">
                            <small class="text-muted d-block">Fournisseur</small>
                            <strong>{{ $purchaseOrder->supplier->name ?? '-' }}</strong>
                        </div>
                        <div class="col-md-4">
                            <small class="text-muted d-block">Date commande</small>
                            {{ $purchaseOrder->order_date->format('d/m/Y') }}
                        </div>
                        <div class="col-md-4">
                            <small class="text-muted d-block">Date livraison prévue</small>
                            {{ $purchaseOrder->delivery_date ? $purchaseOrder->delivery_date->format('d/m/Y') : 'Non définie' }}
                        </div>
                        <div class="col-md-4">
                            <small class="text-muted d-block">Créé par</small>
                            {{ $purchaseOrder->createdBy->name ?? '-' }}
                        </div>
                    </div>

                    {{-- Items --}}
                    <h6 class="mb-2">Lignes de commande</h6>
                    <div class="table-responsive mb-3">
                        <table class="table table-bordered table-sm">
                            <thead class="table-light">
                                <tr>
                                    <th>Description</th>
                                    <th class="text-end">Quantité</th>
                                    <th>Unité</th>
                                    <th class="text-end">Prix unitaire</th>
                                    <th class="text-end">Total HT</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($purchaseOrder->items as $item)
                                    <tr>
                                        <td>{{ $item->description }}</td>
                                        <td class="text-end">{{ number_format($item->quantity, 3, ',', ' ') }}</td>
                                        <td>{{ $item->unit ?? '-' }}</td>
                                        <td class="text-end">{{ number_format($item->unit_price, 2, ',', ' ') }} Ar</td>
                                        <td class="text-end fw-semibold">{{ number_format($item->total, 2, ',', ' ') }} Ar</td>
                                    </tr>
                                @endforeach
                            </tbody>
                            <tfoot class="table-light">
                                <tr>
                                    <td colspan="4" class="text-end fw-semibold">Total HT</td>
                                    <td class="text-end fw-bold">{{ number_format($purchaseOrder->total_ht, 2, ',', ' ') }} Ar</td>
                                </tr>
                                <tr>
                                    <td colspan="4" class="text-end">TVA ({{ $purchaseOrder->tva_rate }}%)</td>
                                    <td class="text-end">{{ number_format($purchaseOrder->total_ttc - $purchaseOrder->total_ht, 2, ',', ' ') }} Ar</td>
                                </tr>
                                <tr>
                                    <td colspan="4" class="text-end fw-bold">Total TTC</td>
                                    <td class="text-end fw-bold text-primary">{{ number_format($purchaseOrder->total_ttc, 2, ',', ' ') }} Ar</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>

                    @if($purchaseOrder->delivery_conditions)
                        <p><strong>Conditions de livraison :</strong> {{ $purchaseOrder->delivery_conditions }}</p>
                    @endif
                    @if($purchaseOrder->notes)
                        <p><strong>Notes :</strong> {{ $purchaseOrder->notes }}</p>
                    @endif
                </div>
            </div>
        </div>

        {{-- Actions sidebar --}}
        <div class="col-xl-4">
            {{-- Conversion BC → dépenses --}}
            @if(in_array($purchaseOrder->status, ['livre', 'partiellement_livre']))
                <div class="card mb-3">
                    <div class="card-header"><h6 class="mb-0"><i class="bi bi-arrow-right-circle me-2"></i>Conversion</h6></div>
                    <div class="card-body">
                        <p class="text-muted small mb-2">Convertir les lignes de ce BC en dépenses.</p>
                        <form method="POST" action="{{ route('purchase-orders.convert-expense', $purchaseOrder) }}"
                              onsubmit="return confirm('Convertir ce BC en dépenses ?')">
                            @csrf
                            <button class="btn btn-success btn-sm w-100">
                                <i class="bi bi-arrow-down-circle me-1"></i>Convertir en dépenses
                            </button>
                        </form>
                    </div>
                </div>
            @endif

            {{-- Changer statut --}}
            @php $transitions = \App\Models\PurchaseOrder::$statusTransitions[$purchaseOrder->status] ?? []; @endphp
            @if(count($transitions))
                <div class="card mb-3">
                    <div class="card-header"><h6 class="mb-0">Changer le statut</h6></div>
                    <div class="card-body">
                        @foreach($transitions as $s)
                            <form method="POST" action="{{ route('purchase-orders.status', $purchaseOrder) }}" class="mb-1">
                                @csrf @method('PATCH')
                                <input type="hidden" name="status" value="{{ $s }}">
                                <button class="btn btn-outline-secondary btn-sm w-100">
                                    → {{ match($s) {
                                        'envoye' => 'Marquer Envoyé',
                                        'partiellement_livre' => 'Partiellement livré',
                                        'livre' => 'Marquer Livré',
                                        'annule' => 'Annuler',
                                        default => $s
                                    } }}
                                </button>
                            </form>
                        @endforeach
                    </div>
                </div>
            @endif

            {{-- Danger zone --}}
            @can('purchase_orders.delete')
                <div class="card border-danger">
                    <div class="card-header bg-danger text-white"><h6 class="mb-0">Zone danger</h6></div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('purchase-orders.destroy', $purchaseOrder) }}"
                              onsubmit="return confirm('Supprimer définitivement ce BC ?')">
                            @csrf @method('DELETE')
                            <button class="btn btn-danger btn-sm w-100">
                                <i class="bi bi-trash me-1"></i>Supprimer
                            </button>
                        </form>
                    </div>
                </div>
            @endcan
        </div>
    </div>
</x-layouts.app>
