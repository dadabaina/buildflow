<x-layouts.app :title="$expense->reference">
    <x-slot name="breadcrumb">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Accueil</a></li>
                <li class="breadcrumb-item"><a href="{{ route('expenses.index') }}">Dépenses</a></li>
                <li class="breadcrumb-item active">{{ $expense->reference }}</li>
            </ol>
        </nav>
    </x-slot>

    @php
    $statusConfig = [
        'pending'   => ['label' => 'En attente', 'class' => 'bg-warning text-dark'],
        'validated' => ['label' => 'Validée',    'class' => 'bg-success'],
        'rejected'  => ['label' => 'Rejetée',    'class' => 'bg-danger'],
    ];
    $sc = $statusConfig[$expense->status] ?? ['label' => $expense->status, 'class' => 'bg-secondary'];
    @endphp

    <div class="d-flex justify-content-between align-items-start mb-4">
        <div>
            <h5 class="mb-1 fw-bold">{{ $expense->description }}</h5>
            <div class="d-flex gap-2 align-items-center">
                <span class="badge bg-light text-dark border font-monospace">{{ $expense->reference }}</span>
                <span class="badge {{ $sc['class'] }}">{{ $sc['label'] }}</span>
            </div>
        </div>
        <div class="d-flex gap-2 flex-wrap">
            @if($expense->status === 'pending')
                @can('expenses.validate')
                <form method="POST" action="{{ route('expenses.validate', $expense) }}">
                    @csrf
                    <button class="btn btn-success btn-sm"><i class="bi bi-check-lg me-1"></i>Valider</button>
                </form>
                <form method="POST" action="{{ route('expenses.reject', $expense) }}">
                    @csrf
                    <button class="btn btn-outline-danger btn-sm"><i class="bi bi-x-lg me-1"></i>Rejeter</button>
                </form>
                @endcan
                @can('expenses.edit')
                <a href="{{ route('expenses.edit', $expense) }}" class="btn btn-primary btn-sm">
                    <i class="bi bi-pencil me-1"></i>Modifier
                </a>
                @endcan
            @endif
            @can('expenses.delete')
            <form method="POST" action="{{ route('expenses.destroy', $expense) }}"
                  onsubmit="return confirm('Supprimer cette dépense ?')">
                @csrf @method('DELETE')
                <button class="btn btn-outline-danger btn-sm"><i class="bi bi-trash me-1"></i>Supprimer</button>
            </form>
            @endcan
        </div>
    </div>

    <div class="row g-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header"><h6 class="mb-0 fw-semibold">Détails</h6></div>
                <div class="card-body">
                    <dl class="row mb-0">
                        <dt class="col-sm-5 text-muted small">Chantier</dt>
                        <dd class="col-sm-7">
                            @if($expense->project)
                            <a href="{{ route('projects.show', $expense->project) }}" class="text-decoration-none">
                                {{ $expense->project->name }}
                            </a>
                            @else —
                            @endif
                        </dd>

                        <dt class="col-sm-5 text-muted small">Catégorie</dt>
                        <dd class="col-sm-7">{{ $expense->expenseCategory?->name ?? '—' }}</dd>

                        <dt class="col-sm-5 text-muted small">Fournisseur</dt>
                        <dd class="col-sm-7">
                            @if($expense->supplier)
                            <a href="{{ route('suppliers.show', $expense->supplier) }}" class="text-decoration-none">
                                {{ $expense->supplier->name }}
                            </a>
                            @else —
                            @endif
                        </dd>

                        <dt class="col-sm-5 text-muted small">Date</dt>
                        <dd class="col-sm-7">{{ $expense->expense_date?->format('d/m/Y') ?? '—' }}</dd>

                        <dt class="col-sm-5 text-muted small">Créé par</dt>
                        <dd class="col-sm-7">{{ $expense->creator?->name ?? '—' }}</dd>

                        @if($expense->notes)
                        <dt class="col-sm-5 text-muted small">Notes</dt>
                        <dd class="col-sm-7">{{ $expense->notes }}</dd>
                        @endif
                    </dl>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card">
                <div class="card-header"><h6 class="mb-0 fw-semibold">Montants</h6></div>
                <div class="card-body">
                    <dl class="row mb-0">
                        <dt class="col-sm-5 text-muted small">Quantité</dt>
                        <dd class="col-sm-7">{{ $expense->quantity }}</dd>

                        <dt class="col-sm-5 text-muted small">Montant HT</dt>
                        <dd class="col-sm-7">{{ number_format($expense->amount, 0, ',', ' ') }} MGA</dd>

                        <dt class="col-sm-5 text-muted small">TVA</dt>
                        <dd class="col-sm-7">{{ $expense->tax_rate }}%</dd>

                        <dt class="col-sm-5 text-muted small fw-semibold">Total TTC</dt>
                        <dd class="col-sm-7 fw-bold fs-5">{{ number_format($expense->total_amount, 0, ',', ' ') }} MGA</dd>
                    </dl>
                </div>
            </div>

            @if($expense->attachment_path)
            <div class="card mt-3">
                <div class="card-header"><h6 class="mb-0 fw-semibold">Pièce jointe</h6></div>
                <div class="card-body">
                    <a href="{{ Storage::url($expense->attachment_path) }}" target="_blank" class="btn btn-outline-secondary btn-sm">
                        <i class="bi bi-paperclip me-1"></i>Voir le justificatif
                    </a>
                </div>
            </div>
            @endif
        </div>
    </div>
</x-layouts.app>
