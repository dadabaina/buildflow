<x-layouts.app title="Gestion des Chantiers">
    <x-slot name="breadcrumb">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="{{ route('dashboard') }}" class="text-decoration-none opacity-50 text-dark">Accueil</a></li>
                <li class="breadcrumb-item active fw-bold text-dark">Chantiers</li>
            </ol>
        </nav>
    </x-slot>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold text-dark mb-0">Chantiers</h3>
            <p class="text-secondary small mb-0">Suivez l'avancement de vos chantiers et la rentabilité associée.</p>
        </div>
        @can('projects.create')
        <a href="{{ route('projects.create') }}" class="btn btn-primary shadow-app d-flex align-items-center gap-2">
            <i class="bi bi-plus-circle-fill fs-5"></i>
            <span>Nouveau chantier</span>
        </a>
        @endcan
    </div>

    {{-- Filtres --}}
    <x-card class="mb-4">
        <form method="GET" class="row g-3 align-items-center">
            <div class="col-md-4">
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="bi bi-search"></i></span>
                    <input type="text" name="search" class="form-control"
                           placeholder="Rechercher..." value="{{ request('search') }}">
                </div>
            </div>
            <div class="col-md-3">
                <select name="status" class="form-select">
                    <option value="">Tous les statuts</option>
                    @foreach(['active' => 'En cours', 'completed' => 'Terminé', 'draft' => 'Brouillon'] as $val => $lbl)
                    <option value="{{ $val }}" {{ request('status') === $val ? 'selected' : '' }}>{{ $lbl }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-auto ms-auto d-flex gap-2">
                <button type="submit" class="btn btn-primary">Filtrer</button>
                @if(request()->anyFilled(['search', 'status']))
                <a href="{{ route('projects.index') }}" class="btn btn-label-secondary">Réinitialiser</a>
                @endif
            </div>
        </form>
    </x-card>

    @php
    $statusConfig = [
        'draft'     => ['label' => 'Brouillon',  'class' => 'bg-label-secondary'],
        'active'    => ['label' => 'En cours',   'class' => 'bg-label-success'],
        'on_hold'   => ['label' => 'En pause',    'class' => 'bg-label-warning'],
        'completed' => ['label' => 'Terminé',     'class' => 'bg-label-primary'],
        'cancelled' => ['label' => 'Annulé',      'class' => 'bg-label-danger'],
    ];
    @endphp

    <x-card class="p-0 overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4 text-uppercase text-xxs">Chantier & Référence</th>
                        <th class="text-uppercase text-xxs">Client</th>
                        <th class="text-uppercase text-xxs">Statut</th>
                        <th class="text-uppercase text-xxs">Budget</th>
                        <th class="text-uppercase text-xxs">Date Début</th>
                        <th class="text-end pe-4 text-uppercase text-xxs">Actions</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    @forelse($projects as $project)
                    @php $sc = $statusConfig[$project->status] ?? ['label' => $project->status, 'class' => 'bg-label-secondary']; @endphp
                    <tr>
                        <td class="ps-4">
                            <div class="d-flex align-items-center">
                                <div class="bg-label-primary rounded p-2 me-3">
                                    <i class="bi bi-building fs-5"></i>
                                </div>
                                <div>
                                    <a href="{{ route('projects.show', $project) }}" class="text-body fw-bold d-block">
                                        {{ $project->name }}
                                    </a>
                                    <small class="text-muted text-uppercase">{{ $project->reference }}</small>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="d-flex align-items-center">
                                <span class="fw-medium text-dark">{{ $project->client?->name ?? '—' }}</span>
                            </div>
                        </td>
                        <td>
                            <span class="badge {{ $sc['class'] }}">
                                {{ $sc['label'] }}
                            </span>
                        </td>
                        <td>
                            <span class="fw-bold text-dark">
                                {{ $project->budget ? number_format($project->budget, 0, ',', ' ') : '—' }}
                                @if($project->budget) <small class="text-muted fw-normal">MGA</small> @endif
                            </span>
                        </td>
                        <td>
                            <div class="small text-muted">
                                <i class="bi bi-calendar3 me-1"></i>
                                {{ $project->start_date?->format('d M Y') ?? '—' }}
                            </div>
                        </td>
                        <td class="text-end pe-4">
                            <div class="d-flex justify-content-end gap-2">
                                <a href="{{ route('projects.show', $project) }}" class="btn-action-view" title="Voir détails">
                                    <i class="bi bi-eye"></i>
                                </a>
                                @can('projects.edit')
                                <a href="{{ route('projects.edit', $project) }}" class="btn-action-edit" title="Modifier">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                @endcan
                                @can('projects.delete')
                                <form method="POST" action="{{ route('projects.destroy', $project) }}"
                                      onsubmit="return confirm('Voulez-vous vraiment supprimer ce chantier ?')">
                                    @csrf @method('DELETE')
                                    <button class="btn-action-delete" title="Supprimer">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                                @endcan
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" class="text-center py-5">
                            <div class="py-5">
                                <i class="bi bi-building fs-1 opacity-25 d-block mb-3"></i>
                                <h5 class="text-muted">Aucun chantier trouvé</h5>
                                <p class="text-muted small mb-0">Commencez par créer votre premier chantier pour le suivre ici.</p>
                            </div>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($projects->hasPages())
        <div class="card-footer bg-white py-3 border-top border-light">
            {{ $projects->links() }}
        </div>
        @endif
    </x-card>
</x-layouts.app>
