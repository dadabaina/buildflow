<x-layouts.app :title="$project->name">
    <x-slot name="breadcrumb">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="{{ route('dashboard') }}" class="text-decoration-none opacity-50 text-dark">Accueil</a></li>
                <li class="breadcrumb-item"><a href="{{ route('projects.index') }}" class="text-decoration-none opacity-50 text-dark">Chantiers</a></li>
                <li class="breadcrumb-item active fw-bold text-dark">{{ $project->name }}</li>
            </ol>
        </nav>
    </x-slot>

    @php
    $statusConfig = [
        'prospection'    => ['label' => 'Prospection',    'class' => 'badge-soft-info',      'icon' => 'bi-search'],
        'devis_en_cours' => ['label' => 'Devis en cours', 'class' => 'badge-soft-warning',   'icon' => 'bi-file-earmark-pencil'],
        'devis_envoye'   => ['label' => 'Devis envoyé',   'class' => 'badge-soft-primary',   'icon' => 'bi-send'],
        'en_cours'       => ['label' => 'En cours',       'class' => 'badge-soft-success',   'icon' => 'bi-play-fill'],
        'en_pause'       => ['label' => 'En pause',       'class' => 'badge-soft-warning',   'icon' => 'bi-pause-fill'],
        'termine'        => ['label' => 'Terminé',        'class' => 'badge-soft-primary',   'icon' => 'bi-check-all'],
        'cloture'        => ['label' => 'Clôturé',        'class' => 'badge-soft-secondary', 'icon' => 'bi-lock'],
        'annule'         => ['label' => 'Annulé',         'class' => 'badge-soft-danger',    'icon' => 'bi-x'],
    ];
    $statusLabels = array_map(fn($s) => $s['label'], $statusConfig);
    $sc = $statusConfig[$project->status] ?? ['label' => $project->status, 'class' => 'badge-soft-secondary', 'icon' => 'bi-info-circle'];
    $nextStatuses = App\Models\Project::$statusTransitions[$project->status] ?? [];
    @endphp

    {{-- Hero Section --}}
    <div class="card border-0 shadow-sm-app rounded-4 mb-4 overflow-hidden">
        <div class="card-body p-0">
            <div class="p-4 p-md-5 bg-dark text-white position-relative">
                <div class="position-relative z-index-1">
                    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
                        <div>
                            <span class="badge rounded-pill {{ $sc['class'] }} bg-opacity-25 text-white border-0 px-3 py-2 mb-3">
                                <i class="{{ $sc['icon'] }} me-1"></i> {{ $sc['label'] }}
                            </span>
                            <h2 class="fw-bold mb-1">{{ $project->name }}</h2>
                            <p class="text-white-50 mb-0">
                                <i class="bi bi-hash me-1"></i>{{ $project->reference }} 
                                <span class="mx-2">·</span> 
                                <i class="bi bi-geo-alt me-1"></i>{{ $project->region?->name ?? 'Région non définie' }}
                            </p>
                        </div>
                        <div class="d-flex gap-2">
                            @can('projects.change_status')
                            @if(count($nextStatuses) > 0)
                            <div class="dropdown">
                                <button class="btn btn-warning fw-bold px-4 dropdown-toggle" data-bs-toggle="dropdown">
                                    <i class="bi bi-arrow-right-circle me-2"></i>Changer le statut
                                </button>
                                <ul class="dropdown-menu shadow-app border-0">
                                    @foreach($nextStatuses as $ns)
                                    <li>
                                        <form method="POST" action="{{ route('projects.status', $project) }}">
                                            @csrf @method('PATCH')
                                            <input type="hidden" name="status" value="{{ $ns }}">
                                            <button type="submit" class="dropdown-item py-2">
                                                <i class="bi bi-arrow-right me-2 text-muted"></i>{{ $statusLabels[$ns] ?? $ns }}
                                            </button>
                                        </form>
                                    </li>
                                    @endforeach
                                </ul>
                            </div>
                            @endif
                            @endcan
                            @can('projects.edit')
                            <a href="{{ route('projects.edit', $project) }}" class="btn btn-light fw-bold px-4">
                                <i class="bi bi-pencil-square me-2"></i>Modifier
                            </a>
                            @endcan
                            <div class="dropdown">
                                <button class="btn btn-outline-light px-3" data-bs-toggle="dropdown">
                                    <i class="bi bi-three-dots-vertical"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end shadow-app border-0">
                                    <li><a class="dropdown-item py-2" href="#"><i class="bi bi-printer me-2 text-muted"></i> Imprimer fiche</a></li>
                                    <li><a class="dropdown-item py-2" href="#"><i class="bi bi-share me-2 text-muted"></i> Partager</a></li>
                                    @can('projects.delete')
                                    <li><hr class="dropdown-divider"></li>
                                    <li>
                                        <form method="POST" action="{{ route('projects.destroy', $project) }}" onsubmit="return confirm('Supprimer ce chantier ?')">
                                            @csrf @method('DELETE')
                                            <button type="submit" class="dropdown-item py-2 text-danger"><i class="bi bi-trash me-2"></i> Supprimer</button>
                                        </form>
                                    </li>
                                    @endcan
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                {{-- Background decorative element --}}
                <div class="position-absolute top-0 end-0 p-5 opacity-10 d-none d-lg-block">
                    <i class="bi bi-building" style="font-size: 10rem;"></i>
                </div>
            </div>
            
            {{-- Quick Stats Summary --}}
            <div class="bg-white p-4 border-top border-light">
                <div class="row g-4 text-center">
                    <div class="col-6 col-md-3 border-end border-light">
                        <div class="text-muted small fw-medium mb-1 text-uppercase">Budget Global</div>
                        <div class="fw-bold text-dark fs-5">{{ number_format($project->budget, 0, ',', ' ') }} <small class="text-muted">MGA</small></div>
                    </div>
                    <div class="col-6 col-md-3 border-end border-light">
                        <div class="text-muted small fw-medium mb-1 text-uppercase">Total Dépenses</div>
                        @php $totalExpenses = $project->expenses->sum('total_amount'); @endphp
                        <div class="fw-bold text-danger fs-5">{{ number_format($totalExpenses, 0, ',', ' ') }} <small class="opacity-50">MGA</small></div>
                    </div>
                    <div class="col-6 col-md-3 border-end border-light">
                        <div class="text-muted small fw-medium mb-1 text-uppercase">Avancement tâches</div>
                        @php
                            $tTotal = $project->tasks->count();
                            $tDone  = $project->tasks->where('status', 'termine')->count();
                            $tPct   = $tTotal > 0 ? round($tDone / $tTotal * 100) : 0;
                        @endphp
                        <div class="fw-bold text-primary fs-5">{{ $tPct }}<small class="text-muted">%</small></div>
                        <div class="progress mt-1" style="height:4px;"><div class="progress-bar bg-primary" style="width:{{ $tPct }}%"></div></div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="text-muted small fw-medium mb-1 text-uppercase">Rentabilité</div>
                        @php $marginPercent = $project->budget > 0 ? (($project->budget - $totalExpenses) / $project->budget) * 100 : 0; @endphp
                        <div class="fw-bold text-primary fs-5">{{ number_format($marginPercent, 1) }}%</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- Main Content & Tabs --}}
    <div x-data="{ activeTab: 'infos' }">
        <div class="card border-0 shadow-sm-app rounded-4 mb-4 bg-white">
            <div class="card-body p-2">
                <ul class="nav nav-pills nav-fill gap-1 flex-wrap">
                    <li class="nav-item">
                        <button class="nav-link rounded-3 py-2 px-3 d-flex align-items-center justify-content-center gap-2" :class="{ 'active shadow-sm': activeTab === 'infos' }" @click="activeTab = 'infos'">
                            <i class="bi bi-info-circle"></i> <span>Vue d'ensemble</span>
                        </button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link rounded-3 py-2 px-3 d-flex align-items-center justify-content-center gap-2" :class="{ 'active shadow-sm': activeTab === 'team' }" @click="activeTab = 'team'">
                            <i class="bi bi-people"></i> <span>Équipe</span>
                            <span class="badge rounded-pill bg-light text-primary ms-1">{{ $project->employees->count() }}</span>
                        </button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link rounded-3 py-2 px-3 d-flex align-items-center justify-content-center gap-2" :class="{ 'active shadow-sm': activeTab === 'expenses' }" @click="activeTab = 'expenses'">
                            <i class="bi bi-receipt"></i> <span>Dépenses</span>
                            <span class="badge rounded-pill bg-light text-primary ms-1">{{ $project->expenses->count() }}</span>
                        </button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link rounded-3 py-2 px-3 d-flex align-items-center justify-content-center gap-2" :class="{ 'active shadow-sm': activeTab === 'bc' }" @click="activeTab = 'bc'">
                            <i class="bi bi-cart3"></i> <span>BCs</span>
                            <span class="badge rounded-pill bg-light text-primary ms-1">{{ $project->purchaseOrders->count() }}</span>
                        </button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link rounded-3 py-2 px-3 d-flex align-items-center justify-content-center gap-2" :class="{ 'active shadow-sm': activeTab === 'tasks' }" @click="activeTab = 'tasks'">
                            <i class="bi bi-check2-square"></i> <span>Tâches</span>
                            <span class="badge rounded-pill bg-light text-primary ms-1">{{ $project->tasks->count() }}</span>
                        </button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link rounded-3 py-2 px-3 d-flex align-items-center justify-content-center gap-2" :class="{ 'active shadow-sm': activeTab === 'pointage' }" @click="activeTab = 'pointage'">
                            <i class="bi bi-clock-history"></i> <span>Pointage</span>
                            <span class="badge rounded-pill bg-light text-primary ms-1">{{ $project->attendances->count() }}</span>
                        </button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link rounded-3 py-2 px-3 d-flex align-items-center justify-content-center gap-2" :class="{ 'active shadow-sm': activeTab === 'quotes' }" @click="activeTab = 'quotes'">
                            <i class="bi bi-file-earmark-text"></i> <span>Devis & Factures</span>
                        </button>
                    </li>
                </ul>
            </div>
        </div>

        {{-- Tab Panes --}}
        <div class="tab-content">
            {{-- Vue d'ensemble --}}
            <div x-show="activeTab === 'infos'" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform translate-y-2">
                <div class="row g-4">
                    <div class="col-lg-7">
                        <x-card title="Détails du chantier" icon="bi bi-card-text">
                            <div class="row g-4">
                                <div class="col-sm-6">
                                    <label class="text-muted small text-uppercase fw-bold mb-1 d-block">Client</label>
                                    @if($project->client)
                                        <div class="d-flex align-items-center">
                                            <div class="avatar bg-light rounded-circle p-2 me-2 d-flex align-items-center justify-content-center" style="width: 32px; height: 32px;">
                                                <i class="bi bi-person text-primary"></i>
                                            </div>
                                            <a href="{{ route('clients.show', $project->client) }}" class="text-decoration-none fw-bold text-dark">
                                                {{ $project->client->name }}
                                            </a>
                                        </div>
                                    @else
                                        <span class="text-muted">—</span>
                                    @endif
                                </div>
                                <div class="col-sm-6">
                                    <label class="text-muted small text-uppercase fw-bold mb-1 d-block">Période du chantier</label>
                                    <div class="fw-bold text-dark">
                                        <i class="bi bi-calendar-event me-2 text-primary"></i>
                                        {{ $project->start_date?->format('d M Y') ?? '—' }} 
                                        <i class="bi bi-arrow-right mx-2 text-muted"></i>
                                        {{ $project->end_date?->format('d M Y') ?? '—' }}
                                    </div>
                                </div>
                                @if($project->description)
                                <div class="col-12 mt-4">
                                    <label class="text-muted small text-uppercase fw-bold mb-2 d-block">Description / Objectifs</label>
                                    <div class="p-3 bg-light rounded-3 text-secondary border-0" style="white-space: pre-line;">{{ $project->description }}</div>
                                </div>
                                @endif
                            </div>
                        </x-card>
                    </div>
                    <div class="col-lg-5">
                        <x-card title="Récapitulatif Financier" icon="bi bi-pie-chart">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item d-flex justify-content-between align-items-center px-0 py-3">
                                    <span class="text-muted">Budget initial</span>
                                    <span class="fw-bold text-dark">{{ number_format($project->budget, 0, ',', ' ') }} MGA</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center px-0 py-3">
                                    <span class="text-muted">Montant du marché (TTC)</span>
                                    <span class="fw-bold text-primary">{{ number_format($project->contract_amount, 0, ',', ' ') }} MGA</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center px-0 py-3">
                                    <span class="text-muted">Avance perçue</span>
                                    <span class="fw-bold text-success">{{ number_format($project->advance_received, 0, ',', ' ') }} MGA</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center px-0 py-3">
                                    <span class="text-muted">Reste à facturer</span>
                                    <span class="fw-bold text-warning">{{ number_format($project->contract_amount - $project->advance_received, 0, ',', ' ') }} MGA</span>
                                </li>
                            </ul>
                        </x-card>
                    </div>
                </div>
            </div>

            {{-- Équipe --}}
            <div x-show="activeTab === 'team'" x-cloak x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform translate-y-2">
                <x-card title="Membres assignés" icon="bi bi-people-fill">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="border-0">Collaborateur</th>
                                    <th class="border-0">Poste / Fonction</th>
                                    <th class="border-0">Fournisseur</th>
                                    <th class="border-0">Contact</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($project->employees as $emp)
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar bg-primary-subtle text-primary rounded-circle p-2 me-3 d-flex align-items-center justify-content-center fw-bold" style="width: 36px; height: 36px;">
                                                {{ substr($emp->full_name, 0, 1) }}
                                            </div>
                                            <a href="{{ route('employees.show', $emp) }}" class="text-decoration-none fw-bold text-dark">
                                                {{ $emp->full_name }}
                                            </a>
                                        </div>
                                    </td>
                                    <td><span class="badge-soft-info px-3 py-1 rounded-pill small">{{ $emp->jobType?->name ?? '—' }}</span></td>
                                    <td><span class="text-muted small">{{ $emp->supplier?->name ?? 'Effectif Interne' }}</span></td>
                                    <td><div class="small fw-medium"><i class="bi bi-telephone me-2 text-muted"></i>{{ $emp->phone ?? '—' }}</div></td>
                                </tr>
                                @empty
                                <tr><td colspan="4" class="text-center py-5 text-muted">Aucun membre assigné à ce chantier.</td></tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </x-card>
            </div>

            {{-- Dépenses --}}
            <div x-show="activeTab === 'expenses'" x-cloak x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform translate-y-2">
                <x-card title="Journal des dépenses" icon="bi bi-receipt">
                    <x-slot name="headerActions">
                        @can('expenses.create')
                        <a href="{{ route('expenses.create', ['project_id' => $project->id]) }}" class="btn btn-sm btn-primary px-3 shadow-sm-app">
                            <i class="bi bi-plus-lg me-1"></i> Ajouter une dépense
                        </a>
                        @endcan
                    </x-slot>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="border-0">Description</th>
                                    <th class="border-0">Catégorie</th>
                                    <th class="border-0">Montant</th>
                                    <th class="border-0">Date</th>
                                    <th class="border-0">Statut</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($project->expenses as $exp)
                                <tr>
                                    <td><a href="{{ route('expenses.show', $exp) }}" class="text-decoration-none fw-bold text-dark">{{ Str::limit($exp->description, 50) }}</a></td>
                                    <td><span class="text-muted small"><i class="bi bi-tag me-1"></i>{{ $exp->expenseCategory?->name ?? '—' }}</span></td>
                                    <td class="fw-bold text-danger">{{ number_format($exp->total_amount, 0, ',', ' ') }} <small>MGA</small></td>
                                    <td><span class="small text-muted">{{ $exp->expense_date?->format('d/m/Y') }}</span></td>
                                    <td>
                                        @php 
                                            $esc = [
                                                'pending' => 'badge-soft-warning', 
                                                'validated' => 'badge-soft-success', 
                                                'rejected' => 'badge-soft-danger',
                                                'saisie' => 'badge-soft-secondary'
                                            ]; 
                                        @endphp
                                        <span class="badge rounded-pill {{ $esc[$exp->status] ?? 'badge-soft-secondary' }} px-3 py-1">{{ ucfirst($exp->status) }}</span>
                                    </td>
                                </tr>
                                @empty
                                <tr><td colspan="5" class="text-center py-5 text-muted">Aucune dépense enregistrée.</td></tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </x-card>
            </div>

            {{-- Bons de commande --}}
            <div x-show="activeTab === 'bc'" x-cloak x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform translate-y-2">
                @php
                    $pendingBC = $project->purchaseOrders->whereIn('status', ['brouillon','envoye','partiellement_livre'])->sum('total_ttc');
                @endphp
                @if($pendingBC > 0)
                <div class="alert alert-warning d-flex align-items-center mb-3">
                    <i class="bi bi-clock me-2"></i>
                    Total commandes en attente : <strong class="ms-2">{{ number_format($pendingBC, 0, ',', ' ') }} MGA</strong>
                </div>
                @endif
                <x-card title="Bons de commande" icon="bi bi-cart3">
                    <x-slot name="headerActions">
                        @can('purchase_orders.create')
                        <a href="{{ route('purchase-orders.create', ['project_id' => $project->id]) }}" class="btn btn-sm btn-primary px-3 shadow-sm-app">
                            <i class="bi bi-plus-lg me-1"></i>Nouveau BC
                        </a>
                        @endcan
                    </x-slot>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="border-0">Référence</th>
                                    <th class="border-0">Fournisseur</th>
                                    <th class="border-0">Date</th>
                                    <th class="border-0">Total TTC</th>
                                    <th class="border-0">Statut</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($project->purchaseOrders as $po)
                                <tr>
                                    <td><a href="{{ route('purchase-orders.show', $po) }}" class="font-monospace small text-decoration-none fw-bold text-primary">{{ $po->reference }}</a></td>
                                    <td class="text-muted small">{{ $po->supplier->name ?? '—' }}</td>
                                    <td class="text-muted small">{{ $po->order_date->format('d/m/Y') }}</td>
                                    <td class="fw-bold small">{{ number_format($po->total_ttc, 0, ',', ' ') }} <small>MGA</small></td>
                                    <td><span class="badge {{ $po->status_badge_class }} px-2 py-1 rounded-pill" style="font-size:0.7rem">{{ $po->status_libelle }}</span></td>
                                </tr>
                                @empty
                                <tr><td colspan="5" class="text-center py-5 text-muted">Aucun bon de commande.</td></tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </x-card>
            </div>

            {{-- Tâches --}}
            <div x-show="activeTab === 'tasks'" x-cloak x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform translate-y-2">
                @php
                    $tasksDone  = $project->tasks->where('status', 'termine')->count();
                    $tasksTotal = $project->tasks->count();
                    $tasksPct   = $tasksTotal > 0 ? round($tasksDone / $tasksTotal * 100) : 0;
                @endphp
                @if($tasksTotal > 0)
                <div class="card border-0 shadow-sm-app rounded-4 mb-3 p-3">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="fw-bold text-dark">Avancement : {{ $tasksDone }}/{{ $tasksTotal }} tâches terminées</span>
                        <span class="fw-bold text-primary">{{ $tasksPct }}%</span>
                    </div>
                    <div class="progress" style="height: 10px;">
                        <div class="progress-bar bg-success" style="width: {{ $tasksPct }}%"></div>
                    </div>
                </div>
                @endif
                <x-card title="Tâches du chantier" icon="bi bi-check2-square">
                    <x-slot name="headerActions">
                        @can('tasks.create')
                        <a href="{{ route('tasks.create', ['project_id' => $project->id]) }}" class="btn btn-sm btn-primary px-3 shadow-sm-app">
                            <i class="bi bi-plus-lg me-1"></i>Nouvelle tâche
                        </a>
                        @endcan
                        <a href="{{ route('tasks.kanban', ['project_id' => $project->id]) }}" class="btn btn-sm btn-light border ms-2">
                            <i class="bi bi-kanban me-1"></i>Kanban
                        </a>
                    </x-slot>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="border-0">Tâche</th>
                                    <th class="border-0">Priorité</th>
                                    <th class="border-0">Échéance</th>
                                    <th class="border-0">Statut</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($project->tasks as $task)
                                <tr>
                                    <td>
                                        <a href="{{ route('tasks.show', $task) }}" class="text-decoration-none fw-bold text-dark">{{ Str::limit($task->title, 50) }}</a>
                                        @if($task->isOverdue())
                                            <span class="badge bg-danger ms-2 small">En retard</span>
                                        @endif
                                    </td>
                                    <td><span class="badge {{ $task->priority_badge_class }} px-2 rounded-pill small">{{ ucfirst($task->priority) }}</span></td>
                                    <td class="text-muted small {{ $task->isOverdue() ? 'text-danger fw-bold' : '' }}">{{ $task->due_date?->format('d/m/Y') ?? '—' }}</td>
                                    <td><span class="badge {{ $task->status_badge_class }} px-2 py-1 rounded-pill" style="font-size:0.7rem">{{ $task->status_libelle }}</span></td>
                                </tr>
                                @empty
                                <tr><td colspan="4" class="text-center py-5 text-muted">Aucune tâche.</td></tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </x-card>
            </div>

            {{-- Pointage --}}
            <div x-show="activeTab === 'pointage'" x-cloak x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform translate-y-2">
                <x-card title="Pointages récents" icon="bi bi-clock-history">
                    <x-slot name="headerActions">
                        @can('attendances.create')
                        <a href="{{ route('attendances.create', ['project_id' => $project->id]) }}" class="btn btn-sm btn-primary px-3 shadow-sm-app">
                            <i class="bi bi-plus-lg me-1"></i>Saisir pointage
                        </a>
                        @endcan
                        <a href="{{ route('attendances.index', ['project_id' => $project->id]) }}" class="btn btn-sm btn-light border ms-2">
                            <i class="bi bi-list me-1"></i>Voir tout
                        </a>
                    </x-slot>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="border-0">Salarié</th>
                                    <th class="border-0">Date</th>
                                    <th class="border-0">Entrée</th>
                                    <th class="border-0">Sortie</th>
                                    <th class="border-0">Heures</th>
                                    <th class="border-0">Statut</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($project->attendances as $att)
                                <tr>
                                    <td class="fw-bold small">{{ $att->employee->full_name ?? '—' }}</td>
                                    <td class="text-muted small">{{ $att->work_date->format('d/m/Y') }}</td>
                                    <td class="text-muted small">{{ $att->check_in ?? '—' }}</td>
                                    <td class="text-muted small">{{ $att->check_out ?? '—' }}</td>
                                    <td class="fw-bold small">{{ $att->hours_worked ? number_format($att->hours_worked, 1).'h' : '—' }}</td>
                                    <td><span class="badge {{ $att->status_badge_class }} px-2 py-1 rounded-pill" style="font-size:0.7rem">{{ $att->status_libelle }}</span></td>
                                </tr>
                                @empty
                                <tr><td colspan="6" class="text-center py-5 text-muted">Aucun pointage.</td></tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </x-card>
            </div>

            {{-- Devis & Factures --}}
            <div x-show="activeTab === 'quotes'" x-cloak x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform translate-y-2">
                <div class="row g-4">
                    <div class="col-md-6">
                        <x-card title="Devis associés" icon="bi bi-file-earmark-text">
                            <x-slot name="headerActions">
                                @can('quotes.create')
                                <a href="{{ route('quotes.create', ['project_id' => $project->id]) }}" class="btn btn-sm btn-light border shadow-sm-app">
                                    <i class="bi bi-plus-lg"></i>
                                </a>
                                @endcan
                            </x-slot>
                            <div class="table-responsive">
                                <table class="table table-hover table-sm align-middle mb-0">
                                    <thead><tr><th>Réf</th><th>Total TTC</th><th>Statut</th></tr></thead>
                                    <tbody>
                                        @forelse($project->quotes as $quote)
                                        <tr>
                                            <td><a href="{{ route('quotes.show', $quote) }}" class="font-monospace small text-decoration-none fw-bold text-primary">{{ $quote->reference }}</a></td>
                                            <td class="fw-bold small">{{ number_format($quote->total_ttc, 0, ',', ' ') }}</td>
                                            <td><span class="badge-soft-secondary px-2 py-1 rounded-pill" style="font-size: 0.7rem">{{ $quote->status }}</span></td>
                                        </tr>
                                        @empty
                                        <tr><td colspan="3" class="text-center py-3 text-muted small">Aucun devis.</td></tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </x-card>
                    </div>
                    <div class="col-md-6">
                        <x-card title="Factures émises" icon="bi bi-file-earmark-check">
                            <div class="table-responsive">
                                <table class="table table-hover table-sm align-middle mb-0">
                                    <thead><tr><th>Réf</th><th>Total TTC</th><th>Statut</th></tr></thead>
                                    <tbody>
                                        @forelse($project->invoices as $invoice)
                                        <tr>
                                            <td><a href="{{ route('invoices.show', $invoice) }}" class="font-monospace small text-decoration-none fw-bold text-info">{{ $invoice->reference }}</a></td>
                                            <td class="fw-bold small">{{ number_format($invoice->total_ttc, 0, ',', ' ') }}</td>
                                            <td><span class="badge-soft-info px-2 py-1 rounded-pill" style="font-size: 0.7rem">{{ $invoice->status }}</span></td>
                                        </tr>
                                        @empty
                                        <tr><td colspan="3" class="text-center py-3 text-muted small">Aucune facture.</td></tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </x-card>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-layouts.app>
