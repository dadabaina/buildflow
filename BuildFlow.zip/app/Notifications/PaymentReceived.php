<?php

namespace App\Notifications;

use App\Models\Payment;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;

class PaymentReceived extends Notification
{
    use Queueable;

    public function __construct(public Payment $payment) {}

    public function via(object $notifiable): array
    {
        return ['database'];
    }

    public function toArray(object $notifiable): array
    {
        return [
            'title'   => 'Paiement reçu',
            'message' => 'Paiement de ' . number_format($this->payment->amount, 0, ',', ' ') . ' Ar enregistré.',
            'url'     => route('invoices.show', $this->payment->invoice_id),
            'icon'    => 'bi-cash-stack',
            'color'   => 'success',
        ];
    }
}
