<?php

namespace App\Models;

use App\Traits\BelongsToCompany;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Project extends Model
{
    use HasFactory, SoftDeletes, BelongsToCompany;

    protected $fillable = [
        'company_id', 'client_id', 'region_id', 'reference', 'name',
        'description', 'address', 'latitude', 'longitude',
        'start_date', 'planned_end_date', 'actual_end_date',
        'status', 'budget_total', 'contract_amount', 'tva_rate', 'rg_rate', 'notes',
    ];

    protected $casts = [
        'start_date' => 'date',
        'planned_end_date' => 'date',
        'actual_end_date' => 'date',
        'budget_total' => 'decimal:2',
        'contract_amount' => 'decimal:2',
        'tva_rate' => 'decimal:2',
        'rg_rate' => 'decimal:2',
        'latitude' => 'decimal:7',
        'longitude' => 'decimal:7',
    ];

    public static array $statusTransitions = [
        'prospection' => ['devis_en_cours'],
        'devis_en_cours' => ['devis_envoye', 'prospection'],
        'devis_envoye' => ['en_cours', 'devis_en_cours', 'annule'],
        'en_cours' => ['en_pause', 'termine'],
        'en_pause' => ['en_cours', 'annule'],
        'termine' => ['cloture'],
        'cloture' => [],
        'annule' => [],
    ];

    protected static function booted(): void
    {
        static::creating(function (Project $project) {
            if (empty($project->reference)) {
                $year = now()->format('Y');
                $seq = static::withoutGlobalScopes()
                    ->whereYear('created_at', $year)
                    ->count() + 1;
                $project->reference = sprintf('BF-%s-%03d', $year, $seq);
            }
        });
    }

    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function client()
    {
        return $this->belongsTo(Client::class);
    }

    public function region()
    {
        return $this->belongsTo(Region::class);
    }

    public function employees()
    {
        return $this->belongsToMany(Employee::class, 'project_employees')
            ->withPivot(['role', 'start_date', 'end_date', 'is_active'])
            ->withTimestamps();
    }

    public function expenses()
    {
        return $this->hasMany(Expense::class);
    }

    public function quotes()
    {
        return $this->hasMany(Quote::class);
    }

    public function invoices()
    {
        return $this->hasMany(Invoice::class);
    }

    public function payments()
    {
        return $this->hasMany(Payment::class);
    }

    public function purchaseOrders()
    {
        return $this->hasMany(PurchaseOrder::class);
    }

    public function tasks()
    {
        return $this->hasMany(Task::class);
    }

    public function attendances()
    {
        return $this->hasMany(Attendance::class);
    }

    public function getStatusLibelleAttribute(): string
    {
        return match ($this->status) {
            'prospection' => 'Prospection',
            'devis_en_cours' => 'Devis en cours',
            'devis_envoye' => 'Devis envoyé',
            'en_cours' => 'En cours',
            'en_pause' => 'En pause',
            'termine' => 'Terminé',
            'cloture' => 'Clôturé',
            'annule' => 'Annulé',
            default => $this->status,
        };
    }

    public function getStatusBadgeClassAttribute(): string
    {
        return match ($this->status) {
            'en_cours' => 'bg-success',
            'termine' => 'bg-primary',
            'cloture' => 'bg-secondary',
            'annule' => 'bg-danger',
            'en_pause' => 'bg-warning text-dark',
            default => 'bg-info text-dark',
        };
    }

    public function getTotalExpensesAttribute(): float
    {
        return (float) $this->expenses()
            ->where('status', 'validee')
            ->sum('total_amount');
    }

    public function getTotalInvoicedAttribute(): float
    {
        return (float) $this->invoices()
            ->whereNotIn('status', ['brouillon', 'annulee'])
            ->sum('total_ttc');
    }

    public function getTotalPaidAttribute(): float
    {
        return (float) $this->payments()->sum('amount');
    }

    public function canTransitionTo(string $newStatus): bool
    {
        return in_array($newStatus, static::$statusTransitions[$this->status] ?? []);
    }
}
