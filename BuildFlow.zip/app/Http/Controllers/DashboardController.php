<?php

namespace App\Http\Controllers;

use App\Models\Client;
use App\Models\Expense;
use App\Models\Invoice;
use App\Models\Payment;
use App\Models\Project;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        // Projets par statut
        $projectStats = Project::selectRaw('status, COUNT(*) as total')
            ->groupBy('status')
            ->pluck('total', 'status');

        // KPIs financiers du mois en cours
        $month = now()->month;
        $year  = now()->year;

        $monthlyExpenses = Expense::where('status', 'validee')
            ->whereMonth('expense_date', $month)
            ->whereYear('expense_date', $year)
            ->selectRaw('SUM(quantity * unit_price) as total')
            ->value('total') ?? 0;

        $monthlyPayments = Payment::whereMonth('payment_date', $month)
            ->whereYear('payment_date', $year)
            ->sum('amount');

        // Factures en retard
        $overdueInvoices = Invoice::whereNotIn('status', ['soldee', 'annulee', 'brouillon'])
            ->where('due_date', '<', now())
            ->count();

        // 5 projets récents
        $recentProjects = Project::with('client')
            ->latest()
            ->take(5)
            ->get();

        // 5 dépenses en attente de validation
        $pendingExpenses = Expense::with(['project', 'category'])
            ->where('status', 'saisie')
            ->latest()
            ->take(5)
            ->get();

        // Totaux globaux
        $totalClients  = Client::count();
        $totalProjects = Project::count();
        $activeProjects = Project::where('status', 'en_cours')->count();

        return view('dashboard', compact(
            'projectStats',
            'monthlyExpenses',
            'monthlyPayments',
            'overdueInvoices',
            'recentProjects',
            'pendingExpenses',
            'totalClients',
            'totalProjects',
            'activeProjects'
        ));
    }
}
