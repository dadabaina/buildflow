<?php

namespace App\Http\Controllers;

use App\Models\Client;
use App\Models\Employee;
use App\Models\Project;
use App\Models\Region;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProjectController extends Controller
{
    public function index(Request $request)
    {
        $query = Project::with(['client', 'region'])->latest();

        if ($search = $request->input('search')) {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('reference', 'like', "%{$search}%");
            });
        }
        if ($status = $request->input('status')) {
            $query->where('status', $status);
        }
        if ($clientId = $request->input('client_id')) {
            $query->where('client_id', $clientId);
        }

        $projects = $query->paginate(20)->withQueryString();
        $statuses = array_keys(Project::$statusTransitions);
        $clients  = Client::orderBy('name')->get();

        return view('projects.index', compact('projects', 'statuses', 'clients'));
    }

    public function create()
    {
        $clients   = Client::orderBy('name')->get();
        $regions   = Region::orderBy('name')->get();
        $employees = Employee::orderBy('last_name')->get();
        return view('projects.form', compact('clients', 'regions', 'employees'));
    }

    public function store(Request $request)
    {
        $validated = $this->validateProject($request);
        $employees = $validated['employee_ids'] ?? [];
        unset($validated['employee_ids']);

        $project = Project::create($validated);

        if ($employees) {
            $project->employees()->sync($employees);
        }

        return redirect()->route('projects.show', $project)
            ->with('success', 'Chantier créé.');
    }

    public function show(Project $project)
    {
        abort_if($project->company_id !== Auth::user()->company_id, 403);
        $project->load([
            'client', 'region', 'employees.jobType',
            'expenses'       => fn($q) => $q->with('category')->latest()->take(10),
            'quotes'         => fn($q) => $q->latest()->take(5),
            'invoices'       => fn($q) => $q->latest()->take(5),
            'purchaseOrders' => fn($q) => $q->with('supplier')->latest()->take(10),
            'tasks'          => fn($q) => $q->with('employees')->latest()->take(20),
            'attendances'    => fn($q) => $q->with('employee')->orderBy('work_date', 'desc')->take(30),
        ]);
        return view('projects.show', compact('project'));
    }

    public function edit(Project $project)
    {
        abort_if($project->company_id !== Auth::user()->company_id, 403);
        $clients   = Client::orderBy('name')->get();
        $regions   = Region::orderBy('name')->get();
        $employees = Employee::orderBy('last_name')->get();
        return view('projects.form', compact('project', 'clients', 'regions', 'employees'));
    }

    public function update(Request $request, Project $project)
    {
        abort_if($project->company_id !== Auth::user()->company_id, 403);
        $validated = $this->validateProject($request);
        $employees = $validated['employee_ids'] ?? [];
        unset($validated['employee_ids']);

        $project->update($validated);
        $project->employees()->sync($employees);

        return redirect()->route('projects.show', $project)
            ->with('success', 'Chantier mis à jour.');
    }

    public function destroy(Project $project)
    {
        abort_if($project->company_id !== Auth::user()->company_id, 403);
        $project->delete();
        return redirect()->route('projects.index')
            ->with('success', 'Chantier supprimé.');
    }

    public function updateStatus(Request $request, Project $project)
    {
        abort_if($project->company_id !== Auth::user()->company_id, 403);
        $request->validate(['status' => ['required', 'string']]);

        if (!$project->canTransitionTo($request->status)) {
            return back()->with('error', 'Transition de statut non autorisée.');
        }

        $project->update(['status' => $request->status]);
        return back()->with('success', 'Statut mis à jour.');
    }

    private function validateProject(Request $request): array
    {
        return $request->validate([
            'name'             => ['required', 'string', 'max:191'],
            'reference'        => ['nullable', 'string', 'max:50'],
            'client_id'        => ['required', 'exists:clients,id'],
            'region_id'        => ['nullable', 'exists:regions,id'],
            'address'          => ['nullable', 'string', 'max:500'],
            'latitude'         => ['nullable', 'numeric'],
            'longitude'        => ['nullable', 'numeric'],
            'description'      => ['nullable', 'string'],
            'start_date'       => ['nullable', 'date'],
            'planned_end_date' => ['nullable', 'date', 'after_or_equal:start_date'],
            'contract_amount'  => ['nullable', 'numeric', 'min:0'],
            'budget_total'     => ['nullable', 'numeric', 'min:0'],
            'tva_rate'         => ['nullable', 'numeric', 'min:0', 'max:100'],
            'rg_rate'          => ['nullable', 'numeric', 'min:0', 'max:100'],
            'notes'            => ['nullable', 'string'],
            'status'           => ['sometimes', 'string'],
            'employee_ids'     => ['nullable', 'array'],
            'employee_ids.*'   => ['exists:employees,id'],
        ]);
    }
}
