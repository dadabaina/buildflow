<?php

namespace App\Http\Controllers;

use App\Models\Attendance;
use App\Models\Expense;
use App\Models\Invoice;
use App\Models\Payment;
use App\Models\Project;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    public function index()
    {
        $company = currentCompany();
        $stats   = [
            'projects'       => $company->projects()->count(),
            'invoices_total' => $company->invoices()->sum('total_ttc'),
            'paid_total'     => $company->payments()->sum('amount'),
            'expenses_total' => $company->expenses()->where('status', 'validee')->sum('total_amount'),
        ];
        return view('reports.index', compact('stats'));
    }

    public function financial(Request $request)
    {
        $company = currentCompany();
        $year    = $request->get('year', now()->year);

        // CA mensuel (factures soldées)
        $monthly = $company->invoices()
            ->selectRaw('MONTH(invoice_date) as month, SUM(total_ttc) as total')
            ->where('status', 'soldee')
            ->whereYear('invoice_date', $year)
            ->groupBy('month')
            ->pluck('total', 'month');

        // Dépenses mensuelles validées
        $expenses = $company->expenses()
            ->selectRaw('MONTH(expense_date) as month, SUM(total_amount) as total')
            ->where('status', 'validee')
            ->whereYear('expense_date', $year)
            ->groupBy('month')
            ->pluck('total', 'month');

        // Top projets par CA
        $topProjects = $company->projects()
            ->withSum(['invoices as total_invoiced' => fn($q) => $q->whereIn('status', ['envoyee', 'soldee', 'en_retard'])], 'total_ttc')
            ->withSum(['invoices as total_paid' => fn($q) => $q->where('status', 'soldee')], 'total_ttc')
            ->orderByDesc('total_invoiced')
            ->take(10)
            ->get();

        $years = range(now()->year, now()->year - 4);

        if ($request->get('export') === 'pdf') {
            $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('pdf.report-financial', compact('monthly', 'expenses', 'topProjects', 'year'));
            return $pdf->download('rapport-financier-' . $year . '.pdf');
        }

        return view('reports.financial', compact('monthly', 'expenses', 'topProjects', 'year', 'years'));
    }

    public function projects(Request $request)
    {
        $company = currentCompany();
        $status  = $request->get('status');

        $projects = $company->projects()
            ->with(['client', 'region'])
            ->withSum(['expenses as expenses_total' => fn($q) => $q->where('status', 'validee')], 'total_amount')
            ->withSum(['invoices as invoiced_total' => fn($q) => $q->whereNotIn('status', ['brouillon', 'annulee'])], 'total_ttc')
            ->when($status, fn($q) => $q->where('status', $status))
            ->orderBy('name')
            ->get();

        if ($request->get('export') === 'pdf') {
            $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('pdf.report-projects', compact('projects'));
            return $pdf->download('rapport-chantiers-' . now()->format('Y-m-d') . '.pdf');
        }

        return view('reports.projects', compact('projects', 'status'));
    }

    public function expenses(Request $request)
    {
        $company   = currentCompany();
        $year      = $request->get('year', now()->year);
        $projectId = $request->get('project_id');

        $expenses = $company->expenses()
            ->with(['category', 'project'])
            ->where('status', 'validee')
            ->whereYear('expense_date', $year)
            ->when($projectId, fn($q) => $q->where('project_id', $projectId))
            ->orderBy('expense_date')
            ->get();

        $byCategory = $expenses->groupBy(fn($e) => $e->category->name ?? 'Autres')
                               ->map(fn($g) => $g->sum('total_amount'));

        $projects = $company->projects()->orderBy('name')->get();
        $years    = range(now()->year, now()->year - 4);

        if ($request->get('export') === 'pdf') {
            $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('pdf.report-expenses', compact('expenses', 'byCategory', 'year'));
            return $pdf->download('journal-depenses-' . $year . '.pdf');
        }

        return view('reports.expenses', compact('expenses', 'byCategory', 'year', 'years', 'projects', 'projectId'));
    }

    public function attendance(Request $request)
    {
        $company   = currentCompany();
        $month     = $request->get('month', now()->month);
        $year      = $request->get('year', now()->year);
        $projectId = $request->get('project_id');

        $attendances = $company->attendances()
            ->with(['employee', 'project'])
            ->whereMonth('work_date', $month)
            ->whereYear('work_date', $year)
            ->when($projectId, fn($q) => $q->where('project_id', $projectId))
            ->orderBy('work_date')
            ->get();

        $projects = $company->projects()->orderBy('name')->get();
        $months   = collect(range(1, 12))->mapWithKeys(fn($m) => [$m => \Carbon\Carbon::create()->month($m)->locale('fr')->monthName]);

        if ($request->get('export') === 'pdf') {
            $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('pdf.report-attendance', compact('attendances', 'month', 'year'));
            return $pdf->download('pointage-' . $year . '-' . $month . '.pdf');
        }

        return view('reports.attendance', compact('attendances', 'projects', 'month', 'year', 'months', 'projectId'));
    }
}
