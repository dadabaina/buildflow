<?php

namespace App\Http\Controllers;

use App\Models\Client;
use App\Models\Region;
use Illuminate\Http\Request;

class ClientController extends Controller
{
    public function index(Request $request)
    {
        $query = Client::with('region')->latest();

        if ($search = $request->input('search')) {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%")
                  ->orWhere('phone', 'like', "%{$search}%");
            });
        }
        if ($type = $request->input('type')) {
            $query->where('type', $type);
        }
        if ($regionId = $request->input('region_id')) {
            $query->where('region_id', $regionId);
        }
        if ($request->input('archived')) {
            $query->onlyTrashed();
        }

        $clients = $query->paginate(20)->withQueryString();
        $regions = Region::orderBy('name')->get();

        return view('clients.index', compact('clients', 'regions'));
    }

    public function create()
    {
        $regions = Region::orderBy('name')->get();
        return view('clients.form', compact('regions'));
    }

    public function store(Request $request)
    {
        $validated = $this->validateClient($request);
        Client::create($validated);
        return redirect()->route('clients.index')
            ->with('success', 'Client créé avec succès.');
    }

    public function show(Client $client)
    {
        $client->load(['region', 'projects' => fn($q) => $q->latest()->take(10)]);
        return view('clients.show', compact('client'));
    }

    public function edit(Client $client)
    {
        $regions = Region::orderBy('name')->get();
        return view('clients.form', compact('client', 'regions'));
    }

    public function update(Request $request, Client $client)
    {
        $validated = $this->validateClient($request, $client->id);
        $client->update($validated);
        return redirect()->route('clients.show', $client)
            ->with('success', 'Client mis à jour.');
    }

    public function destroy(Client $client)
    {
        $client->delete();
        return redirect()->route('clients.index')
            ->with('success', 'Client archivé.');
    }

    public function restore(int $id)
    {
        $client = Client::withTrashed()->findOrFail($id);
        $client->restore();
        return redirect()->route('clients.index')
            ->with('success', 'Client restauré.');
    }

    private function validateClient(Request $request, ?int $ignoreId = null): array
    {
        return $request->validate([
            'name'       => ['required', 'string', 'max:191'],
            'type'       => ['required', 'in:particulier,entreprise,administration'],
            'email'      => ['nullable', 'email', 'max:191'],
            'phone'      => ['nullable', 'string', 'max:30'],
            'address'    => ['nullable', 'string', 'max:500'],
            'city'       => ['nullable', 'string', 'max:100'],
            'region_id'  => ['nullable', 'exists:regions,id'],
            'nif'        => ['nullable', 'string', 'max:30'],
            'stat'       => ['nullable', 'string', 'max:30'],
            'rcs'        => ['nullable', 'string', 'max:30'],
            'notes'      => ['nullable', 'string'],
        ]);
    }
}
