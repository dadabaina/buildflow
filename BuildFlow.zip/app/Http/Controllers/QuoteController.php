<?php

namespace App\Http\Controllers;

use App\Models\Client;
use App\Models\Invoice;
use App\Models\Project;
use App\Models\Quote;
use App\Models\QuoteItem;
use App\Models\QuoteSection;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class QuoteController extends Controller
{
    public function index(Request $request)
    {
        $company = Auth::user()->company;
        $query = $company->quotes()->with(['project', 'client']);

        if ($search = $request->search) {
            $query->where(function ($q) use ($search) {
                $q->where('reference', 'like', "%{$search}%")
                  ->orWhere('title', 'like', "%{$search}%");
            });
        }
        if ($status = $request->status) {
            $query->where('status', $status);
        }
        if ($projectId = $request->project_id) {
            $query->where('project_id', $projectId);
        }

        $quotes = $query->orderByDesc('quote_date')->paginate(20)->withQueryString();
        $projects = $company->projects()->orderBy('name')->get();

        return view('quotes.index', compact('quotes', 'projects'));
    }

    public function create(Request $request)
    {
        $company = Auth::user()->company;
        $projects = $company->projects()->orderBy('name')->get();
        $clients = $company->clients()->orderBy('name')->get();

        $selectedProject = $request->project_id
            ? $company->projects()->find($request->project_id)
            : null;

        return view('quotes.form', compact('projects', 'clients', 'selectedProject'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'project_id' => 'required|exists:projects,id',
            'client_id'  => 'required|exists:clients,id',
            'title'      => 'required|string|max:255',
            'quote_date' => 'required|date',
            'valid_until'=> 'nullable|date|after_or_equal:quote_date',
            'tva_rate'   => 'nullable|numeric|min:0|max:100',
            'discount_global' => 'nullable|numeric|min:0',
            'discount_type'   => 'nullable|in:percent,fixed',
        ]);

        $company = Auth::user()->company;
        $prefix  = $company->quote_prefix ?? 'DEV';
        $lastNum = $company->quotes()->max(DB::raw("CAST(SUBSTRING(reference, LENGTH('{$prefix}')+2) AS UNSIGNED)")) ?? 0;
        $reference = $prefix . '-' . str_pad($lastNum + 1, 4, '0', STR_PAD_LEFT);

        $quote = $company->quotes()->create([
            'project_id'      => $request->project_id,
            'client_id'       => $request->client_id,
            'created_by'      => Auth::id(),
            'reference'       => $reference,
            'title'           => $request->title,
            'quote_date'      => $request->quote_date,
            'valid_until'     => $request->valid_until,
            'tva_rate'        => $request->tva_rate ?? 20,
            'discount_global' => $request->discount_global ?? 0,
            'discount_type'   => $request->discount_type ?? 'percent',
            'status'          => 'brouillon',
            'notes'           => $request->notes,
            'terms'           => $request->terms,
            'subtotal_ht'     => 0,
            'discount_amount' => 0,
            'taxable_ht'      => 0,
            'tva_amount'      => 0,
            'total_ttc'       => 0,
        ]);

        return redirect()->route('quotes.show', $quote)
            ->with('success', 'Devis créé. Ajoutez maintenant les lignes.');
    }

    public function show(Quote $quote)
    {
        $this->authorizeQuote($quote);
        $quote->load(['project', 'client', 'sections.items', 'items', 'createdBy']);
        $company      = Auth::user()->company;
        $unitTypes    = $company->unitTypes()->where('is_active', true)->orderBy('name')->get();
        $dosageModels = $company->dosageModels()->where('is_active', true)->orderBy('name')->get();

        return view('quotes.show', compact('quote', 'unitTypes', 'dosageModels', 'company'));
    }

    public function edit(Quote $quote)
    {
        $this->authorizeQuote($quote);
        $company = Auth::user()->company;
        $projects = $company->projects()->orderBy('name')->get();
        $clients  = $company->clients()->orderBy('name')->get();

        return view('quotes.form', compact('quote', 'projects', 'clients'));
    }

    public function update(Request $request, Quote $quote)
    {
        $this->authorizeQuote($quote);
        $request->validate([
            'project_id' => 'required|exists:projects,id',
            'client_id'  => 'required|exists:clients,id',
            'title'      => 'required|string|max:255',
            'quote_date' => 'required|date',
        ]);

        $quote->update($request->only([
            'project_id', 'client_id', 'title', 'quote_date', 'valid_until',
            'tva_rate', 'discount_global', 'discount_type', 'notes', 'terms',
        ]));

        $quote->recalculateTotals();

        return redirect()->route('quotes.show', $quote)->with('success', 'Devis mis à jour.');
    }

    public function destroy(Quote $quote)
    {
        $this->authorizeQuote($quote);
        $quote->delete();

        return redirect()->route('quotes.index')->with('success', 'Devis supprimé.');
    }

    public function send(Quote $quote)
    {
        $this->authorizeQuote($quote);
        if ($quote->status === 'brouillon') {
            $quote->generateClientToken();
            $quote->update(['status' => 'envoye']);
        }

        return redirect()->route('quotes.show', $quote)->with('success', 'Devis marqué comme envoyé.');
    }

    public function accept(Quote $quote)
    {
        $this->authorizeQuote($quote);
        if ($quote->status === 'envoye') {
            $quote->update(['status' => 'accepte']);
        }

        return redirect()->route('quotes.show', $quote)->with('success', 'Devis accepté.');
    }

    public function convertToInvoice(Quote $quote)
    {
        $this->authorizeQuote($quote);

        if ($quote->status !== 'accepte') {
            return back()->with('error', 'Seul un devis accepté peut être converti en facture.');
        }

        $company = Auth::user()->company;
        $prefix  = $company->invoice_prefix ?? 'FAC';
        $lastNum = $company->invoices()->max(DB::raw("CAST(SUBSTRING(reference, LENGTH('{$prefix}')+2) AS UNSIGNED)")) ?? 0;
        $reference = $prefix . '-' . str_pad($lastNum + 1, 4, '0', STR_PAD_LEFT);

        $invoice = $company->invoices()->create([
            'project_id'   => $quote->project_id,
            'client_id'    => $quote->client_id,
            'quote_id'     => $quote->id,
            'created_by'   => Auth::id(),
            'reference'    => $reference,
            'title'        => $quote->title,
            'type'         => 'standard',
            'invoice_date' => now()->toDateString(),
            'due_date'     => now()->addDays(30)->toDateString(),
            'tva_rate'     => $quote->tva_rate,
            'rg_rate'      => 0,
            'subtotal_ht'  => $quote->subtotal_ht,
            'tva_amount'   => $quote->tva_amount,
            'total_ttc'    => $quote->total_ttc,
            'rg_amount'    => 0,
            'net_to_pay'   => $quote->total_ttc,
            'amount_paid'  => 0,
            'amount_remaining' => $quote->total_ttc,
            'status'       => 'brouillon',
            'notes'        => $quote->notes,
        ]);

        // Copy items
        foreach ($quote->items as $item) {
            $invoice->items()->create([
                'quote_section_id' => null,
                'description'      => $item->description,
                'quantity'         => $item->quantity,
                'unit'             => $item->unit,
                'unit_price'       => $item->unit_price,
                'total_ht'         => $item->total_ht,
                'sort_order'       => $item->sort_order,
            ]);
        }

        return redirect()->route('invoices.show', $invoice)
            ->with('success', 'Facture créée depuis le devis.');
    }

    public function addItem(Request $request, Quote $quote)
    {
        $this->authorizeQuote($quote);
        $request->validate([
            'description' => 'required|string',
            'quantity'    => 'required|numeric|min:0',
            'unit_price'  => 'required|numeric|min:0',
        ]);

        $lastOrder = $quote->items()->max('sort_order') ?? 0;
        $totalHt = round($request->quantity * $request->unit_price, 2);

        $quote->items()->create([
            'description'    => $request->description,
            'quantity'       => $request->quantity,
            'unit'           => $request->unit,
            'unit_price'     => $request->unit_price,
            'total_ht'       => $totalHt,
            'quote_section_id' => $request->quote_section_id,
            'sort_order'     => $lastOrder + 1,
        ]);

        $quote->recalculateTotals();

        return back()->with('success', 'Ligne ajoutée.');
    }

    public function removeItem(Quote $quote, QuoteItem $item)
    {
        $this->authorizeQuote($quote);
        abort_if($item->quote_id !== $quote->id, 403);
        $item->delete();
        $quote->recalculateTotals();

        return back()->with('success', 'Ligne supprimée.');
    }

    private function authorizeQuote(Quote $quote): void
    {
        abort_if($quote->company_id !== Auth::user()->company_id, 403);
    }
}
