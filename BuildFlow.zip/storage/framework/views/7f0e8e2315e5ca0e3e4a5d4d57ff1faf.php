<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Gestion des Clients']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Gestion des Clients']); ?>
     <?php $__env->slot('breadcrumb', null, []); ?> 
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>" class="text-decoration-none opacity-50 text-dark">Accueil</a></li>
                <li class="breadcrumb-item active fw-bold text-dark">Clients</li>
            </ol>
        </nav>
     <?php $__env->endSlot(); ?>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold text-dark mb-0">Clients</h3>
            <p class="text-secondary small mb-0">Gérez votre base de clients et leurs informations.</p>
        </div>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clients.create')): ?>
        <button type="button" class="btn btn-primary shadow-app d-flex align-items-center gap-2" onclick="clientModalCreate()">
            <i class="bi bi-person-plus-fill fs-5"></i>
            <span>Nouveau client</span>
        </button>
        <?php endif; ?>
    </div>

    
    <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['class' => 'mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
        <form method="GET" class="row g-2 align-items-center">
            <div class="col-md-3">
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="bi bi-search"></i></span>
                    <input type="text" name="search" class="form-control"
                           placeholder="Nom, email, téléphone..." value="<?php echo e(request('search')); ?>">
                </div>
            </div>
            <div class="col-md-2">
                <select name="type" class="form-select form-select-sm">
                    <option value="">Tous les types</option>
                    <option value="particulier" <?php echo e(request('type') === 'particulier' ? 'selected' : ''); ?>>Particulier</option>
                    <option value="entreprise" <?php echo e(request('type') === 'entreprise' ? 'selected' : ''); ?>>Entreprise</option>
                    <option value="administration" <?php echo e(request('type') === 'administration' ? 'selected' : ''); ?>>Administration</option>
                </select>
            </div>
            <div class="col-md-2">
                <select name="region_id" class="form-select form-select-sm">
                    <option value="">Toutes les régions</option>
                    <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($region->id); ?>" <?php echo e(request('region_id') == $region->id ? 'selected' : ''); ?>>
                        <?php echo e($region->name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-2">
                <select name="archived" class="form-select form-select-sm">
                    <option value="">Clients actifs</option>
                    <option value="1" <?php echo e(request('archived') ? 'selected' : ''); ?>>Clients archivés</option>
                </select>
            </div>
            <div class="col-auto ms-auto d-flex gap-2">
                <button type="submit" class="btn btn-sm btn-primary px-3">Filtrer</button>
                <?php if(request()->hasAny(['search', 'type', 'region_id', 'archived'])): ?>
                <a href="<?php echo e(route('clients.index')); ?>" class="btn btn-sm btn-label-secondary border px-3">Réinitialiser</a>
                <?php endif; ?>
            </div>
        </form>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>

    
    <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['class' => 'overflow-hidden p-0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'overflow-hidden p-0']); ?>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th class="ps-4">Client</th>
                        <th>Type</th>
                        <th>Contact</th>
                        <th>Région</th>
                        <th class="text-end pe-4">Actions</th>
                    </tr>
                </thead>
                <tbody class="border-top-0">
                    <?php 
                    $types = [
                        'particulier' => ['label' => 'Particulier', 'class' => 'bg-label-info'],
                        'entreprise' => ['label' => 'Entreprise', 'class' => 'bg-label-primary'],
                        'administration' => ['label' => 'Administration', 'class' => 'bg-label-warning']
                    ];
                    ?>
                    <?php $__empty_1 = true; $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="<?php echo e($client->trashed() ? 'bg-label-secondary opacity-75' : ''); ?>">
                        <td class="ps-4 py-3">
                            <div class="d-flex align-items-center">
                                <div class="bg-label-primary rounded-circle p-2 d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                                    <i class="bi bi-person-fill"></i>
                                </div>
                                <div>
                                    <?php if($client->trashed()): ?>
                                    <span class="fw-bold text-dark d-block mb-0"><?php echo e($client->name); ?></span>
                                    <small class="badge bg-secondary rounded-pill" style="font-size: 0.65rem">Archivé</small>
                                    <?php else: ?>
                                    <a href="<?php echo e(route('clients.show', $client)); ?>" class="text-decoration-none fw-bold text-dark d-block mb-0 hov-primary"><?php echo e($client->name); ?></a>
                                    <small class="text-muted text-sm">#<?php echo e(str_pad($client->id, 4, '0', STR_PAD_LEFT)); ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                        <td>
                            <?php $typeMeta = $types[$client->type] ?? ['label' => $client->type, 'class' => 'badge-soft-secondary']; ?>
                            <span class="badge rounded-pill <?php echo e($typeMeta['class']); ?> px-3 py-2">
                                <?php echo e($typeMeta['label']); ?>

                            </span>
                        </td>
                        <td>
                            <div class="small fw-medium text-dark"><i class="bi bi-telephone me-2 text-muted"></i><?php echo e($client->phone ?? '—'); ?></div>
                            <div class="small text-muted"><i class="bi bi-envelope me-2 text-muted"></i><?php echo e($client->email ?? '—'); ?></div>
                        </td>
                        <td>
                            <span class="text-secondary small fw-medium"><i class="bi bi-geo-alt me-1"></i><?php echo e($client->region?->name ?? '—'); ?></span>
                        </td>
                        <td class="text-end pe-4">
                            <div class="d-flex justify-content-end gap-2">
                                <?php if($client->trashed()): ?>
                                    <form method="POST" action="<?php echo e(route('clients.restore', $client->id)); ?>">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                        <button type="submit" class="btn btn-sm btn-label-success" title="Restaurer">
                                            <i class="bi bi-arrow-counterclockwise me-1"></i> Restaurer
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <a href="<?php echo e(route('clients.show', $client)); ?>" class="btn-action-view" title="Voir">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clients.edit')): ?>
                                    <button type="button" class="btn-action-edit" title="Modifier"
                                        onclick='clientModalEdit(<?php echo e(json_encode(["id"=>$client->id,"name"=>$client->name,"type"=>$client->type,"phone"=>$client->phone,"email"=>$client->email,"address"=>$client->address,"city"=>$client->city,"region_id"=>$client->region_id,"nif"=>$client->nif,"stat"=>$client->stat,"rcs"=>$client->rcs,"notes"=>$client->notes])); ?>)'>
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clients.delete')): ?>
                                    <form method="POST" action="<?php echo e(route('clients.destroy', $client)); ?>"
                                          onsubmit="return confirm('Archiver ce client ?')">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn-action-delete" title="Archiver">
                                            <i class="bi bi-archive text-warning"></i>
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center py-5">
                            <div class="py-4">
                                <i class="bi bi-people fs-1 opacity-25 d-block mb-3"></i>
                                <h5 class="text-muted">Aucun client trouvé</h5>
                                <p class="text-muted small">Essayez d'ajuster vos filtres de recherche.</p>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($clients->hasPages()): ?>
        <div class="card-footer bg-white py-3 border-top border-light">
            <?php echo e($clients->links()); ?>

        </div>
        <?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>

    
    <div class="modal fade" id="clientModal" tabindex="-1">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content border-0 shadow-app">
                <form id="clientForm" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="_method" id="clientMethod" value="">
                    <div class="modal-header border-bottom-0 p-4">
                        <h5 class="modal-title fw-bold" id="clientModalTitle">Nouveau client</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body p-4 pt-0">
                        <div class="row g-4">
                            <div class="col-md-8">
                                <label class="form-label fw-semibold">Nom complet / Raison sociale <span class="text-danger">*</span></label>
                                <input type="text" name="name" id="cName" class="form-control" required maxlength="191" placeholder="Ex: Jean Dupont ou Acme Corp">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold">Type de client <span class="text-danger">*</span></label>
                                <select name="type" id="cType" class="form-select" required>
                                    <option value="">Sélectionner...</option>
                                    <option value="particulier">Particulier</option>
                                    <option value="entreprise">Entreprise</option>
                                    <option value="administration">Administration</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Téléphone</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-end-0"><i class="bi bi-telephone text-muted"></i></span>
                                    <input type="text" name="phone" id="cPhone" class="form-control border-start-0" placeholder="Ex: +261 34 00 000 00">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Email professionnel</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-end-0"><i class="bi bi-envelope text-muted"></i></span>
                                    <input type="email" name="email" id="cEmail" class="form-control border-start-0" placeholder="client@exemple.com">
                                </div>
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-semibold">Adresse physique</label>
                                <input type="text" name="address" id="cAddress" class="form-control" placeholder="Numéro, rue, quartier...">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Ville</label>
                                <input type="text" name="city" id="cCity" class="form-control" placeholder="Ex: Antananarivo">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Région</label>
                                <select name="region_id" id="cRegion" class="form-select">
                                    <option value="">— Sélectionner —</option>
                                    <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($region->id); ?>"><?php echo e($region->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            
                            <div class="col-12">
                                <hr class="my-2 border-light">
                                <h6 class="fw-bold mb-3 text-secondary" style="font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.05em;">Informations Fiscales (Optionnel)</h6>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-semibold small">NIF</label>
                                <input type="text" name="nif" id="cNif" class="form-control form-control-sm" maxlength="30">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold small">STAT</label>
                                <input type="text" name="stat" id="cStat" class="form-control form-control-sm" maxlength="30">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-semibold small">RCS</label>
                                <input type="text" name="rcs" id="cRcs" class="form-control form-control-sm" maxlength="30">
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-semibold">Notes internes</label>
                                <textarea name="notes" id="cNotes" class="form-control" rows="2" placeholder="Informations complémentaires sur le client..."></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer border-top-0 p-4 pt-0">
                        <button type="button" class="btn btn-light px-4" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary px-4 shadow-sm-app">
                            <i class="bi bi-check2-circle me-2"></i>Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
    function clientModalCreate() {
        document.getElementById('clientModalTitle').textContent = 'Créer un nouveau client';
        document.getElementById('clientForm').action = '<?php echo e(route('clients.store')); ?>';
        document.getElementById('clientMethod').value = '';
        ['cName','cPhone','cEmail','cAddress','cCity','cNif','cStat','cRcs','cNotes'].forEach(function(id) {
            var el = document.getElementById(id); if (el) el.value = '';
        });
        document.getElementById('cType').value = '';
        document.getElementById('cRegion').value = '';
        new bootstrap.Modal(document.getElementById('clientModal')).show();
    }
    function clientModalEdit(data) {
        document.getElementById('clientModalTitle').textContent = 'Modifier les informations';
        document.getElementById('clientForm').action = '/clients/' + data.id;
        document.getElementById('clientMethod').value = 'PATCH';
        document.getElementById('cName').value    = data.name    || '';
        document.getElementById('cType').value    = data.type    || '';
        document.getElementById('cPhone').value   = data.phone   || '';
        document.getElementById('cEmail').value   = data.email   || '';
        document.getElementById('cAddress').value = data.address || '';
        document.getElementById('cCity').value    = data.city    || '';
        document.getElementById('cRegion').value  = data.region_id || '';
        document.getElementById('cNif').value     = data.nif     || '';
        document.getElementById('cStat').value    = data.stat    || '';
        document.getElementById('cRcs').value     = data.rcs     || '';
        document.getElementById('cNotes').value   = data.notes   || '';
        new bootstrap.Modal(document.getElementById('clientModal')).show();
    }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH /media/rado/New Volume/BuildFlow/resources/views/clients/index.blade.php ENDPATH**/ ?>