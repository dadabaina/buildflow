<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Gestion des Fournisseurs']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Gestion des Fournisseurs']); ?>
     <?php $__env->slot('breadcrumb', null, []); ?> 
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>" class="text-decoration-none opacity-50 text-dark">Accueil</a></li>
                <li class="breadcrumb-item active fw-bold text-dark">Fournisseurs</li>
            </ol>
        </nav>
     <?php $__env->endSlot(); ?>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold text-dark mb-0">Fournisseurs & Sous-traitants</h3>
            <p class="text-secondary small mb-0">Gérez vos partenaires logistiques et vos prestataires de services.</p>
        </div>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('suppliers.create')): ?>
        <a href="<?php echo e(route('suppliers.create')); ?>" class="btn btn-primary shadow-app d-flex align-items-center gap-2">
            <i class="bi bi-plus-lg fs-5"></i>
            <span>Nouveau fournisseur</span>
        </a>
        <?php endif; ?>
    </div>

    
    <div class="card border-0 shadow-sm-app mb-4 bg-white">
        <div class="card-body p-3">
            <form method="GET" class="row g-2 align-items-center">
                <div class="col-md-5">
                    <div class="input-group input-group-sm">
                        <span class="input-group-text bg-transparent border-end-0 text-muted"><i class="bi bi-search"></i></span>
                        <input type="text" name="search" class="form-control border-start-0 ps-0"
                               placeholder="Rechercher par nom, email, NIF..." value="<?php echo e(request('search')); ?>">
                    </div>
                </div>
                <div class="col-md-3">
                    <select name="type" class="form-select form-select-sm">
                        <option value="">Tous les types</option>
                        <option value="fournisseur" <?php echo e(request('type') === 'fournisseur' ? 'selected' : ''); ?>>Fournisseur uniquement</option>
                        <option value="sous_traitant" <?php echo e(request('type') === 'sous_traitant' ? 'selected' : ''); ?>>Sous-traitant uniquement</option>
                        <option value="les_deux" <?php echo e(request('type') === 'les_deux' ? 'selected' : ''); ?>>Hybride (Fournisseur + S/T)</option>
                    </select>
                </div>
                <div class="col-auto ms-auto d-flex gap-2">
                    <button type="submit" class="btn btn-sm btn-primary px-3">Filtrer</button>
                    <?php if(request()->hasAny(['search', 'type'])): ?>
                    <a href="<?php echo e(route('suppliers.index')); ?>" class="btn btn-sm btn-light border px-3">Réinitialiser</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <div class="card border-0 shadow-sm-app overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th class="ps-4">Partenaire</th>
                        <th>Type d'activité</th>
                        <th>Contact</th>
                        <th>Identifiants</th>
                        <th class="text-end pe-4">Actions</th>
                    </tr>
                </thead>
                <tbody class="border-top-0">
                    <?php
                    $typeLabels = ['fournisseur' => 'Fournisseur', 'sous_traitant' => 'Sous-traitant', 'les_deux' => 'Hybride'];
                    $typeBadges = ['fournisseur' => 'badge-soft-info', 'sous_traitant' => 'badge-soft-warning', 'les_deux' => 'badge-soft-primary'];
                    ?>
                    <?php $__empty_1 = true; $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="ps-4 py-3">
                            <div class="d-flex align-items-center">
                                <div class="bg-indigo-subtle text-indigo rounded-3 p-2 d-flex align-items-center justify-content-center me-3 shadow-sm-app" style="width: 42px; height: 42px;">
                                    <i class="bi bi-truck fs-5"></i>
                                </div>
                                <div>
                                    <a href="<?php echo e(route('suppliers.show', $supplier)); ?>" class="text-decoration-none fw-bold text-dark d-block mb-0 hov-primary">
                                        <?php echo e($supplier->name); ?>

                                    </a>
                                    <small class="text-muted">ID: #<?php echo e(str_pad($supplier->id, 4, '0', STR_PAD_LEFT)); ?></small>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="badge rounded-pill <?php echo e($typeBadges[$supplier->type] ?? 'badge-soft-secondary'); ?> px-3 py-2">
                                <?php echo e($typeLabels[$supplier->type] ?? $supplier->type); ?>

                            </span>
                        </td>
                        <td>
                            <div class="small fw-medium text-dark"><i class="bi bi-telephone me-2 text-muted"></i><?php echo e($supplier->phone ?? '—'); ?></div>
                            <div class="small text-muted"><i class="bi bi-envelope me-2 text-muted"></i><?php echo e($supplier->email ?? '—'); ?></div>
                        </td>
                        <td>
                            <div class="small"><span class="text-muted small fw-bold">NIF:</span> <span class="font-monospace"><?php echo e($supplier->nif ?? '—'); ?></span></div>
                            <div class="small"><span class="text-muted small fw-bold">STAT:</span> <span class="font-monospace"><?php echo e($supplier->stat ?? '—'); ?></span></div>
                        </td>
                        <td class="text-end pe-4">
                            <div class="d-flex justify-content-end gap-2">
                                <a href="<?php echo e(route('suppliers.show', $supplier)); ?>" class="btn btn-light btn-sm rounded-circle shadow-sm-app" title="Voir fiche">
                                    <i class="bi bi-eye text-primary"></i>
                                </a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('suppliers.edit')): ?>
                                <a href="<?php echo e(route('suppliers.edit', $supplier)); ?>" class="btn btn-light btn-sm rounded-circle shadow-sm-app" title="Modifier">
                                    <i class="bi bi-pencil text-info"></i>
                                </a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('suppliers.delete')): ?>
                                <form method="POST" action="<?php echo e(route('suppliers.destroy', $supplier)); ?>"
                                      onsubmit="return confirm('Supprimer ce fournisseur ?')">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-light btn-sm rounded-circle shadow-sm-app" title="Supprimer">
                                        <i class="bi bi-trash text-danger"></i>
                                    </button>
                                </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center py-5">
                            <div class="py-5">
                                <i class="bi bi-truck fs-1 opacity-25 d-block mb-3"></i>
                                <h5 class="text-muted">Aucun partenaire trouvé</h5>
                                <p class="text-muted small">Vos fournisseurs apparaîtront ici.</p>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($suppliers->hasPages()): ?>
        <div class="card-footer bg-white py-3 border-top border-light">
            <?php echo e($suppliers->links()); ?>

        </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH /media/rado/New Volume/BuildFlow/resources/views/suppliers/index.blade.php ENDPATH**/ ?>