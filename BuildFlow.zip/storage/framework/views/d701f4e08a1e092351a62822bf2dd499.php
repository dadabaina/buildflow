<!DOCTYPE html>
<html
    lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>"
    class="layout-menu-fixed layout-compact"
    dir="ltr"
    data-skin="default"
    data-assets-path="<?php echo e(asset('assets') . '/'); ?>"
    data-base-url="<?php echo e(url('/')); ?>"
    data-framework="laravel"
    data-bs-theme="light"
    data-template="vertical-menu-template">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($title ?? config('app.name', 'BuildFlow')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet" />

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/assets/vendor/fonts/iconify/iconify.css',
        'resources/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.scss',
        'resources/assets/vendor/scss/core.scss',
        'resources/css/app.scss'
    ]); ?>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>

<!-- Layout wrapper -->
<div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">

        <!-- Sidebar / Menu -->
        <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">

            <div class="app-brand demo">
                <a href="<?php echo e(route('dashboard')); ?>" class="app-brand-link">
                    <span class="app-brand-logo demo me-1">
                        <svg width="25" viewBox="0 0 25 42" version="1.1" xmlns="http://www.w3.org/2000/svg">
                            <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                <g transform="translate(3.000000, 1.000000)">
                                    <polygon fill="#696CFF" opacity="0.2" points="18.1 -0.3 1.2 15.6 0 23.4 18.1 24.5"></polygon>
                                    <polygon fill="#696CFF" points="18.1 -0.3 1.2 15.6 12.7 18.6"></polygon>
                                    <polygon fill="#696CFF" opacity="0.5" points="11.7 20.2 8.6 17.4 19.3 3.4"></polygon>
                                    <polygon fill="#696CFF" points="18.1 -0.3 19.3 3.4 11.7 20.2 0 23.4 18.1 24.5"></polygon>
                                    <polygon fill="#696CFF" opacity="0.6" points="0 23.4 11.7 20.2 18.1 24.5"></polygon>
                                </g>
                            </g>
                        </svg>
                    </span>
                    <span class="app-brand-text demo menu-text fw-bold">BuildFlow</span>
                </a>
                <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
                    <i class="icon-base bx bx-chevron-left icon-sm"></i>
                </a>
            </div>

            <div class="menu-divider mt-0"></div>
            <div class="menu-inner-shadow"></div>

            <ul class="menu-inner py-1">

                <!-- Principal -->
                <li class="menu-header small text-uppercase">
                    <span class="menu-header-text">Principal</span>
                </li>
                <li class="menu-item <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('dashboard')); ?>" class="menu-link">
                        <i class="menu-icon icon-base bx bx-home-circle"></i>
                        <div>Tableau de bord</div>
                    </a>
                </li>

                <!-- Contacts -->
                <li class="menu-header small text-uppercase">
                    <span class="menu-header-text">Contacts</span>
                </li>
                <li class="menu-item <?php echo e(request()->routeIs('clients.*', 'suppliers.*', 'employees.*') ? 'active open' : ''); ?>">
                    <a href="javascript:void(0);" class="menu-link menu-toggle">
                        <i class="menu-icon icon-base bx bx-group"></i>
                        <div>Contacts</div>
                    </a>
                    <ul class="menu-sub">
                        <li class="menu-item <?php echo e(request()->routeIs('clients.*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('clients.index')); ?>" class="menu-link"><div>Clients</div></a>
                        </li>
                        <li class="menu-item <?php echo e(request()->routeIs('suppliers.*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('suppliers.index')); ?>" class="menu-link"><div>Fournisseurs</div></a>
                        </li>
                        <li class="menu-item <?php echo e(request()->routeIs('employees.*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('employees.index')); ?>" class="menu-link"><div>Employés</div></a>
                        </li>
                    </ul>
                </li>

                <!-- Chantiers -->
                <li class="menu-header small text-uppercase">
                    <span class="menu-header-text">Chantiers</span>
                </li>
                <li class="menu-item <?php echo e(request()->routeIs('projects.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('projects.index')); ?>" class="menu-link">
                        <i class="menu-icon icon-base bx bx-building"></i>
                        <div>Chantiers</div>
                    </a>
                </li>
                <li class="menu-item <?php echo e(request()->routeIs('expenses.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('expenses.index')); ?>" class="menu-link">
                        <i class="menu-icon icon-base bx bx-receipt"></i>
                        <div>Dépenses</div>
                    </a>
                </li>
                <li class="menu-item <?php echo e(request()->routeIs('purchase-orders.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('purchase-orders.index')); ?>" class="menu-link">
                        <i class="menu-icon icon-base bx bx-file-blank"></i>
                        <div>Bons de commande</div>
                    </a>
                </li>
                <li class="menu-item <?php echo e(request()->routeIs('tasks.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('tasks.index')); ?>" class="menu-link">
                        <i class="menu-icon icon-base bx bx-task"></i>
                        <div>Tâches</div>
                    </a>
                </li>
                <li class="menu-item <?php echo e(request()->routeIs('attendances.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('attendances.index')); ?>" class="menu-link">
                        <i class="menu-icon icon-base bx bx-time-five"></i>
                        <div>Pointage</div>
                    </a>
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('site_reports.view')): ?>
                <li class="menu-item <?php echo e(request()->routeIs('site-reports.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('site-reports.index')); ?>" class="menu-link">
                        <i class="menu-icon icon-base bx bx-notepad"></i>
                        <div>Comptes-rendus</div>
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reception_reports.view')): ?>
                <li class="menu-item <?php echo e(request()->routeIs('reception-reports.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('reception-reports.index')); ?>" class="menu-link">
                        <i class="menu-icon icon-base bx bx-clipboard"></i>
                        <div>PV Réception</div>
                    </a>
                </li>
                <?php endif; ?>

                <!-- Commercial -->
                <li class="menu-header small text-uppercase">
                    <span class="menu-header-text">Commercial</span>
                </li>
                <li class="menu-item <?php echo e(request()->routeIs('quotes.*', 'amendments.*', 'progress-billings.*', 'invoices.*', 'payments.*') ? 'active open' : ''); ?>">
                    <a href="javascript:void(0);" class="menu-link menu-toggle">
                        <i class="menu-icon icon-base bx bx-briefcase"></i>
                        <div>Ventes</div>
                    </a>
                    <ul class="menu-sub">
                        <li class="menu-item <?php echo e(request()->routeIs('quotes.*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('quotes.index')); ?>" class="menu-link"><div>Devis</div></a>
                        </li>
                        <li class="menu-item <?php echo e(request()->routeIs('amendments.*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('amendments.index')); ?>" class="menu-link"><div>Avenants</div></a>
                        </li>
                        <li class="menu-item <?php echo e(request()->routeIs('progress-billings.*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('progress-billings.index')); ?>" class="menu-link"><div>Situations</div></a>
                        </li>
                        <li class="menu-item <?php echo e(request()->routeIs('invoices.*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('invoices.index')); ?>" class="menu-link"><div>Factures</div></a>
                        </li>
                        <li class="menu-item <?php echo e(request()->routeIs('payments.*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('payments.index')); ?>" class="menu-link"><div>Paiements</div></a>
                        </li>
                    </ul>
                </li>

                <!-- Ressources -->
                <li class="menu-header small text-uppercase">
                    <span class="menu-header-text">Ressources</span>
                </li>
                <li class="menu-item <?php echo e(request()->routeIs('documents.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('documents.index')); ?>" class="menu-link">
                        <i class="menu-icon icon-base bx bx-folder-open"></i>
                        <div>Documents</div>
                    </a>
                </li>
                <li class="menu-item <?php echo e(request()->routeIs('materials.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('materials.index')); ?>" class="menu-link">
                        <i class="menu-icon icon-base bx bx-cube-alt"></i>
                        <div>Matériaux</div>
                    </a>
                </li>
                <li class="menu-item <?php echo e(request()->routeIs('dosage.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('dosage.index')); ?>" class="menu-link">
                        <i class="menu-icon icon-base bx bx-calculator"></i>
                        <div>Dosages DBE</div>
                    </a>
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('equipments.view')): ?>
                <li class="menu-item <?php echo e(request()->routeIs('equipments.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('equipments.index')); ?>" class="menu-link">
                        <i class="menu-icon icon-base bx bx-wrench"></i>
                        <div>Matériels</div>
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('stock.view')): ?>
                <li class="menu-item <?php echo e(request()->routeIs('warehouses.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('warehouses.index')); ?>" class="menu-link">
                        <i class="menu-icon icon-base bx bx-archive"></i>
                        <div>Dépôts</div>
                    </a>
                </li>
                <li class="menu-item <?php echo e(request()->routeIs('stock.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('stock.dashboard')); ?>" class="menu-link">
                        <i class="menu-icon icon-base bx bx-package"></i>
                        <div>Stock</div>
                    </a>
                </li>
                <?php endif; ?>

                <!-- Rapports -->
                <li class="menu-header small text-uppercase">
                    <span class="menu-header-text">Rapports</span>
                </li>
                <li class="menu-item <?php echo e(request()->routeIs('reports.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('reports.index')); ?>" class="menu-link">
                        <i class="menu-icon icon-base bx bx-bar-chart-alt-2"></i>
                        <div>Rapports</div>
                    </a>
                </li>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings.view')): ?>
                <!-- Administration -->
                <li class="menu-header small text-uppercase">
                    <span class="menu-header-text">Administration</span>
                </li>
                <li class="menu-item <?php echo e(request()->routeIs('settings.*', 'expense-categories.*') ? 'active open' : ''); ?>">
                    <a href="javascript:void(0);" class="menu-link menu-toggle">
                        <i class="menu-icon icon-base bx bx-cog"></i>
                        <div>Paramètres</div>
                    </a>
                    <ul class="menu-sub">
                        <li class="menu-item <?php echo e(request()->routeIs('settings.*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('settings.index')); ?>#entreprise" class="menu-link"><div>Entreprise</div></a>
                        </li>
                        <li class="menu-item">
                            <a href="<?php echo e(route('settings.index')); ?>#regions" class="menu-link"><div>Régions</div></a>
                        </li>
                        <li class="menu-item">
                            <a href="<?php echo e(route('settings.index')); ?>#metiers" class="menu-link"><div>Postes / Fonctions</div></a>
                        </li>
                        <li class="menu-item">
                            <a href="<?php echo e(route('settings.index')); ?>#unites" class="menu-link"><div>Types d'unités</div></a>
                        </li>
                        <li class="menu-item">
                            <a href="<?php echo e(route('settings.index')); ?>#categories" class="menu-link"><div>Catégories dépenses</div></a>
                        </li>
                        <li class="menu-item">
                            <a href="<?php echo e(route('settings.index')); ?>#salaires" class="menu-link"><div>Grille salariale</div></a>
                        </li>
                        <li class="menu-item">
                            <a href="<?php echo e(route('settings.index')); ?>#mat_categories" class="menu-link"><div>Catégories matériaux</div></a>
                        </li>
                    </ul>
                </li>
                <li class="menu-item <?php echo e(request()->routeIs('users.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('users.index')); ?>" class="menu-link">
                        <i class="menu-icon icon-base bx bx-shield-quarter"></i>
                        <div>Utilisateurs</div>
                    </a>
                </li>
                <?php endif; ?>

            </ul>
        </aside>
        <!-- / Sidebar -->

        <!-- Layout page -->
        <div class="layout-page">

            <!-- Navbar -->
            <nav class="layout-navbar container-xxl navbar-detached navbar navbar-expand-xl align-items-center bg-navbar-theme" id="layout-navbar">

                <div class="layout-menu-toggle navbar-nav align-items-xl-center me-4 me-xl-0 d-xl-none">
                    <a class="nav-item nav-link px-0 me-xl-6" href="javascript:void(0)">
                        <i class="icon-base bx bx-menu icon-md"></i>
                    </a>
                </div>

                <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">

                    <!-- Breadcrumb -->
                    <div class="d-none d-xl-flex align-items-center me-auto">
                        <?php echo e($breadcrumb ?? ''); ?>

                    </div>

                    <ul class="navbar-nav flex-row align-items-center ms-auto gap-2">

                        <!-- Notifications -->
                        <?php $unreadCount = auth()->user()?->unreadNotifications()->count(); ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link hide-arrow position-relative" href="javascript:void(0);" data-bs-toggle="dropdown">
                                <i class="icon-base bx bx-bell icon-md"></i>
                                <?php if($unreadCount > 0): ?>
                                <span class="badge bg-danger rounded-pill position-absolute top-0 start-100 translate-middle" style="font-size:.6rem;padding:2px 5px;">
                                    <?php echo e($unreadCount > 9 ? '9+' : $unreadCount); ?>

                                </span>
                                <?php endif; ?>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end p-0" style="width:340px;max-height:400px;overflow-y:auto;">
                                <div class="d-flex justify-content-between align-items-center p-3 border-bottom">
                                    <span class="fw-semibold small">Notifications</span>
                                    <a href="<?php echo e(route('notifications.index')); ?>" class="small text-primary">Voir tout</a>
                                </div>
                                <?php $__empty_1 = true; $__currentLoopData = auth()->user()?->notifications()->latest()->take(5)->get() ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php $nd = is_array($notif->data) ? $notif->data : json_decode($notif->data, true); ?>
                                <a href="<?php echo e(route('notifications.read', $notif->id)); ?>"
                                   class="dropdown-item d-flex gap-2 align-items-start p-3 <?php echo e(is_null($notif->read_at) ? 'bg-primary bg-opacity-10' : ''); ?>">
                                    <i class="icon-base bx <?php echo e($nd['icon'] ?? 'bx-bell'); ?> text-<?php echo e($nd['color'] ?? 'primary'); ?> mt-1"></i>
                                    <div>
                                        <p class="mb-0 small fw-semibold"><?php echo e($nd['title'] ?? ''); ?></p>
                                        <p class="mb-0 text-muted" style="font-size:.75rem"><?php echo e(Str::limit($nd['message'] ?? '', 60)); ?></p>
                                        <p class="mb-0 text-muted" style="font-size:.7rem"><?php echo e($notif->created_at->diffForHumans()); ?></p>
                                    </div>
                                </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="text-center text-muted py-4 small">
                                    <i class="icon-base bx bx-bell-off d-block mb-1 fs-4 opacity-25"></i>Aucune notification
                                </div>
                                <?php endif; ?>
                            </div>
                        </li>

                        <!-- User -->
                        <li class="nav-item navbar-dropdown dropdown-user dropdown">
                            <a class="nav-link dropdown-toggle hide-arrow p-0" href="javascript:void(0);" data-bs-toggle="dropdown">
                                <div class="avatar avatar-online">
                                    <img src="<?php echo e(auth()->user()->avatar_url); ?>" alt="<?php echo e(auth()->user()->name); ?>" class="w-px-40 h-auto rounded-circle">
                                </div>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <div class="d-flex">
                                            <div class="flex-shrink-0 me-3">
                                                <div class="avatar avatar-online">
                                                    <img src="<?php echo e(auth()->user()->avatar_url); ?>" alt class="w-px-40 h-auto rounded-circle">
                                                </div>
                                            </div>
                                            <div class="flex-grow-1">
                                                <h6 class="mb-0"><?php echo e(auth()->user()->name); ?></h6>
                                                <small class="text-muted"><?php echo e(auth()->user()->company?->name); ?></small>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li><div class="dropdown-divider my-1"></div></li>
                                <li>
                                    <a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>">
                                        <i class="icon-base bx bx-user icon-md me-2"></i> Mon profil
                                    </a>
                                </li>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('settings.view')): ?>
                                <li>
                                    <a class="dropdown-item" href="<?php echo e(route('settings.index')); ?>">
                                        <i class="icon-base bx bx-cog icon-md me-2"></i> Paramètres
                                    </a>
                                </li>
                                <?php endif; ?>
                                <li><div class="dropdown-divider my-1"></div></li>
                                <li>
                                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="dropdown-item text-danger">
                                            <i class="icon-base bx bx-power-off icon-md me-2"></i> Déconnexion
                                        </button>
                                    </form>
                                </li>
                            </ul>
                        </li>

                    </ul>
                </div>
            </nav>
            <!-- / Navbar -->

            <!-- Content wrapper -->
            <div class="content-wrapper">

                <!-- Content -->
                <div class="container-xxl flex-grow-1 container-p-y">

                    <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible mb-4" role="alert">
                        <i class="icon-base bx bx-check-circle me-2"></i><?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible mb-4" role="alert">
                        <i class="icon-base bx bx-error-circle me-2"></i><?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                    <?php endif; ?>

                    <?php echo e($slot); ?>


                </div>
                <!-- / Content -->

                <!-- Footer -->
                <footer class="content-footer footer bg-footer-theme">
                    <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                        <div class="mb-2 mb-md-0">
                            © <script>document.write(new Date().getFullYear());</script>
                            BuildFlow
                        </div>
                    </div>
                </footer>
                <!-- / Footer -->

                <div class="content-backdrop fade"></div>
            </div>
            <!-- / Content wrapper -->

        </div>
        <!-- / Layout page -->

    </div>

    <!-- Overlay -->
    <div class="layout-overlay layout-menu-toggle"></div>
    <!-- Drag Target -->
    <div class="drag-target"></div>
</div>
<!-- / Layout wrapper -->

<?php echo app('Illuminate\Foundation\Vite')([
    'resources/assets/vendor/js/helpers.js',
    'resources/assets/js/config.js',
    'resources/assets/vendor/js/menu.js',
    'resources/assets/js/main.js',
    'resources/js/app.js'
]); ?>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /media/rado/New Volume/BuildFlow/resources/views/components/layouts/app.blade.php ENDPATH**/ ?>