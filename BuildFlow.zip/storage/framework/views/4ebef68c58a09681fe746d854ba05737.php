<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Gestion des Chantiers']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Gestion des Chantiers']); ?>
     <?php $__env->slot('breadcrumb', null, []); ?> 
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>" class="text-decoration-none opacity-50 text-dark">Accueil</a></li>
                <li class="breadcrumb-item active fw-bold text-dark">Chantiers</li>
            </ol>
        </nav>
     <?php $__env->endSlot(); ?>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold text-dark mb-0">Chantiers</h3>
            <p class="text-secondary small mb-0">Suivez l'avancement de vos chantiers et la rentabilité associée.</p>
        </div>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('projects.create')): ?>
        <a href="<?php echo e(route('projects.create')); ?>" class="btn btn-primary shadow-app d-flex align-items-center gap-2">
            <i class="bi bi-plus-circle-fill fs-5"></i>
            <span>Nouveau chantier</span>
        </a>
        <?php endif; ?>
    </div>

    
    <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['class' => 'mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
        <form method="GET" class="row g-3 align-items-center">
            <div class="col-md-4">
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="bi bi-search"></i></span>
                    <input type="text" name="search" class="form-control"
                           placeholder="Rechercher..." value="<?php echo e(request('search')); ?>">
                </div>
            </div>
            <div class="col-md-3">
                <select name="status" class="form-select">
                    <option value="">Tous les statuts</option>
                    <?php $__currentLoopData = ['active' => 'En cours', 'completed' => 'Terminé', 'draft' => 'Brouillon']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $lbl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($val); ?>" <?php echo e(request('status') === $val ? 'selected' : ''); ?>><?php echo e($lbl); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-auto ms-auto d-flex gap-2">
                <button type="submit" class="btn btn-primary">Filtrer</button>
                <?php if(request()->anyFilled(['search', 'status'])): ?>
                <a href="<?php echo e(route('projects.index')); ?>" class="btn btn-label-secondary">Réinitialiser</a>
                <?php endif; ?>
            </div>
        </form>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>

    <?php
    $statusConfig = [
        'draft'     => ['label' => 'Brouillon',  'class' => 'bg-label-secondary'],
        'active'    => ['label' => 'En cours',   'class' => 'bg-label-success'],
        'on_hold'   => ['label' => 'En pause',    'class' => 'bg-label-warning'],
        'completed' => ['label' => 'Terminé',     'class' => 'bg-label-primary'],
        'cancelled' => ['label' => 'Annulé',      'class' => 'bg-label-danger'],
    ];
    ?>

    <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['class' => 'p-0 overflow-hidden']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'p-0 overflow-hidden']); ?>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4 text-uppercase text-xxs">Chantier & Référence</th>
                        <th class="text-uppercase text-xxs">Client</th>
                        <th class="text-uppercase text-xxs">Statut</th>
                        <th class="text-uppercase text-xxs">Budget</th>
                        <th class="text-uppercase text-xxs">Date Début</th>
                        <th class="text-end pe-4 text-uppercase text-xxs">Actions</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php $sc = $statusConfig[$project->status] ?? ['label' => $project->status, 'class' => 'bg-label-secondary']; ?>
                    <tr>
                        <td class="ps-4">
                            <div class="d-flex align-items-center">
                                <div class="bg-label-primary rounded p-2 me-3">
                                    <i class="bi bi-building fs-5"></i>
                                </div>
                                <div>
                                    <a href="<?php echo e(route('projects.show', $project)); ?>" class="text-body fw-bold d-block">
                                        <?php echo e($project->name); ?>

                                    </a>
                                    <small class="text-muted text-uppercase"><?php echo e($project->reference); ?></small>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="d-flex align-items-center">
                                <span class="fw-medium text-dark"><?php echo e($project->client?->name ?? '—'); ?></span>
                            </div>
                        </td>
                        <td>
                            <span class="badge <?php echo e($sc['class']); ?>">
                                <?php echo e($sc['label']); ?>

                            </span>
                        </td>
                        <td>
                            <span class="fw-bold text-dark">
                                <?php echo e($project->budget ? number_format($project->budget, 0, ',', ' ') : '—'); ?>

                                <?php if($project->budget): ?> <small class="text-muted fw-normal">MGA</small> <?php endif; ?>
                            </span>
                        </td>
                        <td>
                            <div class="small text-muted">
                                <i class="bi bi-calendar3 me-1"></i>
                                <?php echo e($project->start_date?->format('d M Y') ?? '—'); ?>

                            </div>
                        </td>
                        <td class="text-end pe-4">
                            <div class="d-flex justify-content-end gap-2">
                                <a href="<?php echo e(route('projects.show', $project)); ?>" class="btn-action-view" title="Voir détails">
                                    <i class="bi bi-eye"></i>
                                </a>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('projects.edit')): ?>
                                <a href="<?php echo e(route('projects.edit', $project)); ?>" class="btn-action-edit" title="Modifier">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('projects.delete')): ?>
                                <form method="POST" action="<?php echo e(route('projects.destroy', $project)); ?>"
                                      onsubmit="return confirm('Voulez-vous vraiment supprimer ce chantier ?')">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="btn-action-delete" title="Supprimer">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-5">
                            <div class="py-5">
                                <i class="bi bi-building fs-1 opacity-25 d-block mb-3"></i>
                                <h5 class="text-muted">Aucun chantier trouvé</h5>
                                <p class="text-muted small mb-0">Commencez par créer votre premier chantier pour le suivre ici.</p>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($projects->hasPages()): ?>
        <div class="card-footer bg-white py-3 border-top border-light">
            <?php echo e($projects->links()); ?>

        </div>
        <?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH /media/rado/New Volume/BuildFlow/resources/views/projects/index.blade.php ENDPATH**/ ?>