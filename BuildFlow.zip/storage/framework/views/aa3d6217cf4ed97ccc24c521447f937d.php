<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Kanban — Tâches']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Kanban — Tâches']); ?>
     <?php $__env->slot('breadcrumb', null, []); ?> 
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Accueil</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('tasks.index')); ?>">Tâches</a></li>
        <li class="breadcrumb-item active">Kanban</li>
     <?php $__env->endSlot(); ?>

    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="mb-0"><i class="bi bi-grid-3x3-gap me-2"></i>Kanban</h4>
        <div class="d-flex gap-2 align-items-center">
            <form method="GET" class="d-flex gap-2">
                <select name="project_id" class="form-select form-select-sm" onchange="this.form.submit()">
                    <option value="">Tous les chantiers</option>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($p->id); ?>" <?php if($projectId == $p->id): echo 'selected'; endif; ?>><?php echo e($p->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </form>
            <a href="<?php echo e(route('tasks.index')); ?>" class="btn btn-outline-secondary btn-sm">
                <i class="bi bi-list-ul me-1"></i>Liste
            </a>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tasks.create')): ?>
                <a href="<?php echo e(route('tasks.create', ['project_id' => $projectId])); ?>" class="btn btn-primary btn-sm">
                    <i class="bi bi-plus-lg"></i>
                </a>
            <?php endif; ?>
        </div>
    </div>

    <?php
    $colConfig = [
        'a_faire'  => ['label' => 'À faire',   'icon' => 'bi-circle',       'hdr' => 'bg-secondary text-white'],
        'en_cours' => ['label' => 'En cours',   'icon' => 'bi-arrow-repeat', 'hdr' => 'bg-primary text-white'],
        'en_pause' => ['label' => 'En pause',   'icon' => 'bi-pause-circle', 'hdr' => 'bg-warning text-dark'],
        'termine'  => ['label' => 'Terminées',  'icon' => 'bi-check-circle', 'hdr' => 'bg-success text-white'],
    ];
    ?>

    <div class="row g-3">
        <?php $__currentLoopData = $colConfig; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $cfg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
                <div class="card h-100">
                    <div class="card-header <?php echo e($cfg['hdr']); ?> py-2">
                        <strong><i class="bi <?php echo e($cfg['icon']); ?> me-1"></i><?php echo e($cfg['label']); ?></strong>
                        <span class="badge bg-white text-dark ms-1"><?php echo e($columns[$status]->count()); ?></span>
                    </div>
                    <div class="card-body p-2" style="min-height:200px">
                        <?php $__empty_1 = true; $__currentLoopData = $columns[$status]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="card card-body p-2 mb-2 shadow-sm">
                                <div class="d-flex justify-content-between align-items-start mb-1">
                                    <a href="<?php echo e(route('tasks.show', $task)); ?>" class="fw-semibold text-dark text-decoration-none small">
                                        <?php echo e($task->title); ?>

                                    </a>
                                    <span class="badge <?php echo e($task->priority_badge_class); ?> ms-1"><?php echo e(substr($task->priority,0,1)); ?></span>
                                </div>
                                <?php if($task->due_date): ?>
                                    <div class="small <?php echo e($task->isOverdue() ? 'text-danger fw-semibold' : 'text-muted'); ?>">
                                        <i class="bi bi-calendar3 me-1"></i><?php echo e($task->due_date->format('d/m/Y')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if($task->employees->count()): ?>
                                    <div class="mt-1">
                                        <?php $__currentLoopData = $task->employees->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="badge bg-light text-dark border" style="font-size:.65rem"><?php echo e($emp->first_name); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-muted text-center small mt-3">Aucune tâche</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH /media/rado/New Volume/BuildFlow/resources/views/tasks/kanban.blade.php ENDPATH**/ ?>