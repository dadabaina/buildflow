<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => $project->name]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($project->name)]); ?>
     <?php $__env->slot('breadcrumb', null, []); ?> 
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>" class="text-decoration-none opacity-50 text-dark">Accueil</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('projects.index')); ?>" class="text-decoration-none opacity-50 text-dark">Chantiers</a></li>
                <li class="breadcrumb-item active fw-bold text-dark"><?php echo e($project->name); ?></li>
            </ol>
        </nav>
     <?php $__env->endSlot(); ?>

    <?php
    $statusConfig = [
        'prospection'    => ['label' => 'Prospection',    'class' => 'badge-soft-info',      'icon' => 'bi-search'],
        'devis_en_cours' => ['label' => 'Devis en cours', 'class' => 'badge-soft-warning',   'icon' => 'bi-file-earmark-pencil'],
        'devis_envoye'   => ['label' => 'Devis envoyé',   'class' => 'badge-soft-primary',   'icon' => 'bi-send'],
        'en_cours'       => ['label' => 'En cours',       'class' => 'badge-soft-success',   'icon' => 'bi-play-fill'],
        'en_pause'       => ['label' => 'En pause',       'class' => 'badge-soft-warning',   'icon' => 'bi-pause-fill'],
        'termine'        => ['label' => 'Terminé',        'class' => 'badge-soft-primary',   'icon' => 'bi-check-all'],
        'cloture'        => ['label' => 'Clôturé',        'class' => 'badge-soft-secondary', 'icon' => 'bi-lock'],
        'annule'         => ['label' => 'Annulé',         'class' => 'badge-soft-danger',    'icon' => 'bi-x'],
    ];
    $statusLabels = array_map(fn($s) => $s['label'], $statusConfig);
    $sc = $statusConfig[$project->status] ?? ['label' => $project->status, 'class' => 'badge-soft-secondary', 'icon' => 'bi-info-circle'];
    $nextStatuses = App\Models\Project::$statusTransitions[$project->status] ?? [];
    ?>

    
    <div class="card border-0 shadow-sm-app rounded-4 mb-4 overflow-hidden">
        <div class="card-body p-0">
            <div class="p-4 p-md-5 bg-dark text-white position-relative">
                <div class="position-relative z-index-1">
                    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
                        <div>
                            <span class="badge rounded-pill <?php echo e($sc['class']); ?> bg-opacity-25 text-white border-0 px-3 py-2 mb-3">
                                <i class="<?php echo e($sc['icon']); ?> me-1"></i> <?php echo e($sc['label']); ?>

                            </span>
                            <h2 class="fw-bold mb-1"><?php echo e($project->name); ?></h2>
                            <p class="text-white-50 mb-0">
                                <i class="bi bi-hash me-1"></i><?php echo e($project->reference); ?> 
                                <span class="mx-2">·</span> 
                                <i class="bi bi-geo-alt me-1"></i><?php echo e($project->region?->name ?? 'Région non définie'); ?>

                            </p>
                        </div>
                        <div class="d-flex gap-2">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('projects.change_status')): ?>
                            <?php if(count($nextStatuses) > 0): ?>
                            <div class="dropdown">
                                <button class="btn btn-warning fw-bold px-4 dropdown-toggle" data-bs-toggle="dropdown">
                                    <i class="bi bi-arrow-right-circle me-2"></i>Changer le statut
                                </button>
                                <ul class="dropdown-menu shadow-app border-0">
                                    <?php $__currentLoopData = $nextStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ns): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <form method="POST" action="<?php echo e(route('projects.status', $project)); ?>">
                                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                            <input type="hidden" name="status" value="<?php echo e($ns); ?>">
                                            <button type="submit" class="dropdown-item py-2">
                                                <i class="bi bi-arrow-right me-2 text-muted"></i><?php echo e($statusLabels[$ns] ?? $ns); ?>

                                            </button>
                                        </form>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('projects.edit')): ?>
                            <a href="<?php echo e(route('projects.edit', $project)); ?>" class="btn btn-light fw-bold px-4">
                                <i class="bi bi-pencil-square me-2"></i>Modifier
                            </a>
                            <?php endif; ?>
                            <div class="dropdown">
                                <button class="btn btn-outline-light px-3" data-bs-toggle="dropdown">
                                    <i class="bi bi-three-dots-vertical"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end shadow-app border-0">
                                    <li><a class="dropdown-item py-2" href="#"><i class="bi bi-printer me-2 text-muted"></i> Imprimer fiche</a></li>
                                    <li><a class="dropdown-item py-2" href="#"><i class="bi bi-share me-2 text-muted"></i> Partager</a></li>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('projects.delete')): ?>
                                    <li><hr class="dropdown-divider"></li>
                                    <li>
                                        <form method="POST" action="<?php echo e(route('projects.destroy', $project)); ?>" onsubmit="return confirm('Supprimer ce chantier ?')">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="dropdown-item py-2 text-danger"><i class="bi bi-trash me-2"></i> Supprimer</button>
                                        </form>
                                    </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="position-absolute top-0 end-0 p-5 opacity-10 d-none d-lg-block">
                    <i class="bi bi-building" style="font-size: 10rem;"></i>
                </div>
            </div>
            
            
            <div class="bg-white p-4 border-top border-light">
                <div class="row g-4 text-center">
                    <div class="col-6 col-md-3 border-end border-light">
                        <div class="text-muted small fw-medium mb-1 text-uppercase">Budget Global</div>
                        <div class="fw-bold text-dark fs-5"><?php echo e(number_format($project->budget, 0, ',', ' ')); ?> <small class="text-muted">MGA</small></div>
                    </div>
                    <div class="col-6 col-md-3 border-end border-light">
                        <div class="text-muted small fw-medium mb-1 text-uppercase">Total Dépenses</div>
                        <?php $totalExpenses = $project->expenses->sum('total_amount'); ?>
                        <div class="fw-bold text-danger fs-5"><?php echo e(number_format($totalExpenses, 0, ',', ' ')); ?> <small class="opacity-50">MGA</small></div>
                    </div>
                    <div class="col-6 col-md-3 border-end border-light">
                        <div class="text-muted small fw-medium mb-1 text-uppercase">Avancement tâches</div>
                        <?php
                            $tTotal = $project->tasks->count();
                            $tDone  = $project->tasks->where('status', 'termine')->count();
                            $tPct   = $tTotal > 0 ? round($tDone / $tTotal * 100) : 0;
                        ?>
                        <div class="fw-bold text-primary fs-5"><?php echo e($tPct); ?><small class="text-muted">%</small></div>
                        <div class="progress mt-1" style="height:4px;"><div class="progress-bar bg-primary" style="width:<?php echo e($tPct); ?>%"></div></div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="text-muted small fw-medium mb-1 text-uppercase">Rentabilité</div>
                        <?php $marginPercent = $project->budget > 0 ? (($project->budget - $totalExpenses) / $project->budget) * 100 : 0; ?>
                        <div class="fw-bold text-primary fs-5"><?php echo e(number_format($marginPercent, 1)); ?>%</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div x-data="{ activeTab: 'infos' }">
        <div class="card border-0 shadow-sm-app rounded-4 mb-4 bg-white">
            <div class="card-body p-2">
                <ul class="nav nav-pills nav-fill gap-1 flex-wrap">
                    <li class="nav-item">
                        <button class="nav-link rounded-3 py-2 px-3 d-flex align-items-center justify-content-center gap-2" :class="{ 'active shadow-sm': activeTab === 'infos' }" @click="activeTab = 'infos'">
                            <i class="bi bi-info-circle"></i> <span>Vue d'ensemble</span>
                        </button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link rounded-3 py-2 px-3 d-flex align-items-center justify-content-center gap-2" :class="{ 'active shadow-sm': activeTab === 'team' }" @click="activeTab = 'team'">
                            <i class="bi bi-people"></i> <span>Équipe</span>
                            <span class="badge rounded-pill bg-light text-primary ms-1"><?php echo e($project->employees->count()); ?></span>
                        </button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link rounded-3 py-2 px-3 d-flex align-items-center justify-content-center gap-2" :class="{ 'active shadow-sm': activeTab === 'expenses' }" @click="activeTab = 'expenses'">
                            <i class="bi bi-receipt"></i> <span>Dépenses</span>
                            <span class="badge rounded-pill bg-light text-primary ms-1"><?php echo e($project->expenses->count()); ?></span>
                        </button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link rounded-3 py-2 px-3 d-flex align-items-center justify-content-center gap-2" :class="{ 'active shadow-sm': activeTab === 'bc' }" @click="activeTab = 'bc'">
                            <i class="bi bi-cart3"></i> <span>BCs</span>
                            <span class="badge rounded-pill bg-light text-primary ms-1"><?php echo e($project->purchaseOrders->count()); ?></span>
                        </button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link rounded-3 py-2 px-3 d-flex align-items-center justify-content-center gap-2" :class="{ 'active shadow-sm': activeTab === 'tasks' }" @click="activeTab = 'tasks'">
                            <i class="bi bi-check2-square"></i> <span>Tâches</span>
                            <span class="badge rounded-pill bg-light text-primary ms-1"><?php echo e($project->tasks->count()); ?></span>
                        </button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link rounded-3 py-2 px-3 d-flex align-items-center justify-content-center gap-2" :class="{ 'active shadow-sm': activeTab === 'pointage' }" @click="activeTab = 'pointage'">
                            <i class="bi bi-clock-history"></i> <span>Pointage</span>
                            <span class="badge rounded-pill bg-light text-primary ms-1"><?php echo e($project->attendances->count()); ?></span>
                        </button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link rounded-3 py-2 px-3 d-flex align-items-center justify-content-center gap-2" :class="{ 'active shadow-sm': activeTab === 'quotes' }" @click="activeTab = 'quotes'">
                            <i class="bi bi-file-earmark-text"></i> <span>Devis & Factures</span>
                        </button>
                    </li>
                </ul>
            </div>
        </div>

        
        <div class="tab-content">
            
            <div x-show="activeTab === 'infos'" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform translate-y-2">
                <div class="row g-4">
                    <div class="col-lg-7">
                        <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['title' => 'Détails du chantier','icon' => 'bi bi-card-text']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Détails du chantier','icon' => 'bi bi-card-text']); ?>
                            <div class="row g-4">
                                <div class="col-sm-6">
                                    <label class="text-muted small text-uppercase fw-bold mb-1 d-block">Client</label>
                                    <?php if($project->client): ?>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar bg-light rounded-circle p-2 me-2 d-flex align-items-center justify-content-center" style="width: 32px; height: 32px;">
                                                <i class="bi bi-person text-primary"></i>
                                            </div>
                                            <a href="<?php echo e(route('clients.show', $project->client)); ?>" class="text-decoration-none fw-bold text-dark">
                                                <?php echo e($project->client->name); ?>

                                            </a>
                                        </div>
                                    <?php else: ?>
                                        <span class="text-muted">—</span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-sm-6">
                                    <label class="text-muted small text-uppercase fw-bold mb-1 d-block">Période du chantier</label>
                                    <div class="fw-bold text-dark">
                                        <i class="bi bi-calendar-event me-2 text-primary"></i>
                                        <?php echo e($project->start_date?->format('d M Y') ?? '—'); ?> 
                                        <i class="bi bi-arrow-right mx-2 text-muted"></i>
                                        <?php echo e($project->end_date?->format('d M Y') ?? '—'); ?>

                                    </div>
                                </div>
                                <?php if($project->description): ?>
                                <div class="col-12 mt-4">
                                    <label class="text-muted small text-uppercase fw-bold mb-2 d-block">Description / Objectifs</label>
                                    <div class="p-3 bg-light rounded-3 text-secondary border-0" style="white-space: pre-line;"><?php echo e($project->description); ?></div>
                                </div>
                                <?php endif; ?>
                            </div>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
                    </div>
                    <div class="col-lg-5">
                        <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['title' => 'Récapitulatif Financier','icon' => 'bi bi-pie-chart']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Récapitulatif Financier','icon' => 'bi bi-pie-chart']); ?>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item d-flex justify-content-between align-items-center px-0 py-3">
                                    <span class="text-muted">Budget initial</span>
                                    <span class="fw-bold text-dark"><?php echo e(number_format($project->budget, 0, ',', ' ')); ?> MGA</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center px-0 py-3">
                                    <span class="text-muted">Montant du marché (TTC)</span>
                                    <span class="fw-bold text-primary"><?php echo e(number_format($project->contract_amount, 0, ',', ' ')); ?> MGA</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center px-0 py-3">
                                    <span class="text-muted">Avance perçue</span>
                                    <span class="fw-bold text-success"><?php echo e(number_format($project->advance_received, 0, ',', ' ')); ?> MGA</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center px-0 py-3">
                                    <span class="text-muted">Reste à facturer</span>
                                    <span class="fw-bold text-warning"><?php echo e(number_format($project->contract_amount - $project->advance_received, 0, ',', ' ')); ?> MGA</span>
                                </li>
                            </ul>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>

            
            <div x-show="activeTab === 'team'" x-cloak x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform translate-y-2">
                <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['title' => 'Membres assignés','icon' => 'bi bi-people-fill']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Membres assignés','icon' => 'bi bi-people-fill']); ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="border-0">Collaborateur</th>
                                    <th class="border-0">Poste / Fonction</th>
                                    <th class="border-0">Fournisseur</th>
                                    <th class="border-0">Contact</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $project->employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar bg-primary-subtle text-primary rounded-circle p-2 me-3 d-flex align-items-center justify-content-center fw-bold" style="width: 36px; height: 36px;">
                                                <?php echo e(substr($emp->full_name, 0, 1)); ?>

                                            </div>
                                            <a href="<?php echo e(route('employees.show', $emp)); ?>" class="text-decoration-none fw-bold text-dark">
                                                <?php echo e($emp->full_name); ?>

                                            </a>
                                        </div>
                                    </td>
                                    <td><span class="badge-soft-info px-3 py-1 rounded-pill small"><?php echo e($emp->jobType?->name ?? '—'); ?></span></td>
                                    <td><span class="text-muted small"><?php echo e($emp->supplier?->name ?? 'Effectif Interne'); ?></span></td>
                                    <td><div class="small fw-medium"><i class="bi bi-telephone me-2 text-muted"></i><?php echo e($emp->phone ?? '—'); ?></div></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="4" class="text-center py-5 text-muted">Aucun membre assigné à ce chantier.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
            </div>

            
            <div x-show="activeTab === 'expenses'" x-cloak x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform translate-y-2">
                <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['title' => 'Journal des dépenses','icon' => 'bi bi-receipt']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Journal des dépenses','icon' => 'bi bi-receipt']); ?>
                     <?php $__env->slot('headerActions', null, []); ?> 
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expenses.create')): ?>
                        <a href="<?php echo e(route('expenses.create', ['project_id' => $project->id])); ?>" class="btn btn-sm btn-primary px-3 shadow-sm-app">
                            <i class="bi bi-plus-lg me-1"></i> Ajouter une dépense
                        </a>
                        <?php endif; ?>
                     <?php $__env->endSlot(); ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="border-0">Description</th>
                                    <th class="border-0">Catégorie</th>
                                    <th class="border-0">Montant</th>
                                    <th class="border-0">Date</th>
                                    <th class="border-0">Statut</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $project->expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><a href="<?php echo e(route('expenses.show', $exp)); ?>" class="text-decoration-none fw-bold text-dark"><?php echo e(Str::limit($exp->description, 50)); ?></a></td>
                                    <td><span class="text-muted small"><i class="bi bi-tag me-1"></i><?php echo e($exp->expenseCategory?->name ?? '—'); ?></span></td>
                                    <td class="fw-bold text-danger"><?php echo e(number_format($exp->total_amount, 0, ',', ' ')); ?> <small>MGA</small></td>
                                    <td><span class="small text-muted"><?php echo e($exp->expense_date?->format('d/m/Y')); ?></span></td>
                                    <td>
                                        <?php 
                                            $esc = [
                                                'pending' => 'badge-soft-warning', 
                                                'validated' => 'badge-soft-success', 
                                                'rejected' => 'badge-soft-danger',
                                                'saisie' => 'badge-soft-secondary'
                                            ]; 
                                        ?>
                                        <span class="badge rounded-pill <?php echo e($esc[$exp->status] ?? 'badge-soft-secondary'); ?> px-3 py-1"><?php echo e(ucfirst($exp->status)); ?></span>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="5" class="text-center py-5 text-muted">Aucune dépense enregistrée.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
            </div>

            
            <div x-show="activeTab === 'bc'" x-cloak x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform translate-y-2">
                <?php
                    $pendingBC = $project->purchaseOrders->whereIn('status', ['brouillon','envoye','partiellement_livre'])->sum('total_ttc');
                ?>
                <?php if($pendingBC > 0): ?>
                <div class="alert alert-warning d-flex align-items-center mb-3">
                    <i class="bi bi-clock me-2"></i>
                    Total commandes en attente : <strong class="ms-2"><?php echo e(number_format($pendingBC, 0, ',', ' ')); ?> MGA</strong>
                </div>
                <?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['title' => 'Bons de commande','icon' => 'bi bi-cart3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Bons de commande','icon' => 'bi bi-cart3']); ?>
                     <?php $__env->slot('headerActions', null, []); ?> 
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('purchase_orders.create')): ?>
                        <a href="<?php echo e(route('purchase-orders.create', ['project_id' => $project->id])); ?>" class="btn btn-sm btn-primary px-3 shadow-sm-app">
                            <i class="bi bi-plus-lg me-1"></i>Nouveau BC
                        </a>
                        <?php endif; ?>
                     <?php $__env->endSlot(); ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="border-0">Référence</th>
                                    <th class="border-0">Fournisseur</th>
                                    <th class="border-0">Date</th>
                                    <th class="border-0">Total TTC</th>
                                    <th class="border-0">Statut</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $project->purchaseOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $po): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><a href="<?php echo e(route('purchase-orders.show', $po)); ?>" class="font-monospace small text-decoration-none fw-bold text-primary"><?php echo e($po->reference); ?></a></td>
                                    <td class="text-muted small"><?php echo e($po->supplier->name ?? '—'); ?></td>
                                    <td class="text-muted small"><?php echo e($po->order_date->format('d/m/Y')); ?></td>
                                    <td class="fw-bold small"><?php echo e(number_format($po->total_ttc, 0, ',', ' ')); ?> <small>MGA</small></td>
                                    <td><span class="badge <?php echo e($po->status_badge_class); ?> px-2 py-1 rounded-pill" style="font-size:0.7rem"><?php echo e($po->status_libelle); ?></span></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="5" class="text-center py-5 text-muted">Aucun bon de commande.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
            </div>

            
            <div x-show="activeTab === 'tasks'" x-cloak x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform translate-y-2">
                <?php
                    $tasksDone  = $project->tasks->where('status', 'termine')->count();
                    $tasksTotal = $project->tasks->count();
                    $tasksPct   = $tasksTotal > 0 ? round($tasksDone / $tasksTotal * 100) : 0;
                ?>
                <?php if($tasksTotal > 0): ?>
                <div class="card border-0 shadow-sm-app rounded-4 mb-3 p-3">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="fw-bold text-dark">Avancement : <?php echo e($tasksDone); ?>/<?php echo e($tasksTotal); ?> tâches terminées</span>
                        <span class="fw-bold text-primary"><?php echo e($tasksPct); ?>%</span>
                    </div>
                    <div class="progress" style="height: 10px;">
                        <div class="progress-bar bg-success" style="width: <?php echo e($tasksPct); ?>%"></div>
                    </div>
                </div>
                <?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['title' => 'Tâches du chantier','icon' => 'bi bi-check2-square']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Tâches du chantier','icon' => 'bi bi-check2-square']); ?>
                     <?php $__env->slot('headerActions', null, []); ?> 
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tasks.create')): ?>
                        <a href="<?php echo e(route('tasks.create', ['project_id' => $project->id])); ?>" class="btn btn-sm btn-primary px-3 shadow-sm-app">
                            <i class="bi bi-plus-lg me-1"></i>Nouvelle tâche
                        </a>
                        <?php endif; ?>
                        <a href="<?php echo e(route('tasks.kanban', ['project_id' => $project->id])); ?>" class="btn btn-sm btn-light border ms-2">
                            <i class="bi bi-kanban me-1"></i>Kanban
                        </a>
                     <?php $__env->endSlot(); ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="border-0">Tâche</th>
                                    <th class="border-0">Priorité</th>
                                    <th class="border-0">Échéance</th>
                                    <th class="border-0">Statut</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $project->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <a href="<?php echo e(route('tasks.show', $task)); ?>" class="text-decoration-none fw-bold text-dark"><?php echo e(Str::limit($task->title, 50)); ?></a>
                                        <?php if($task->isOverdue()): ?>
                                            <span class="badge bg-danger ms-2 small">En retard</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><span class="badge <?php echo e($task->priority_badge_class); ?> px-2 rounded-pill small"><?php echo e(ucfirst($task->priority)); ?></span></td>
                                    <td class="text-muted small <?php echo e($task->isOverdue() ? 'text-danger fw-bold' : ''); ?>"><?php echo e($task->due_date?->format('d/m/Y') ?? '—'); ?></td>
                                    <td><span class="badge <?php echo e($task->status_badge_class); ?> px-2 py-1 rounded-pill" style="font-size:0.7rem"><?php echo e($task->status_libelle); ?></span></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="4" class="text-center py-5 text-muted">Aucune tâche.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
            </div>

            
            <div x-show="activeTab === 'pointage'" x-cloak x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform translate-y-2">
                <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['title' => 'Pointages récents','icon' => 'bi bi-clock-history']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Pointages récents','icon' => 'bi bi-clock-history']); ?>
                     <?php $__env->slot('headerActions', null, []); ?> 
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('attendances.create')): ?>
                        <a href="<?php echo e(route('attendances.create', ['project_id' => $project->id])); ?>" class="btn btn-sm btn-primary px-3 shadow-sm-app">
                            <i class="bi bi-plus-lg me-1"></i>Saisir pointage
                        </a>
                        <?php endif; ?>
                        <a href="<?php echo e(route('attendances.index', ['project_id' => $project->id])); ?>" class="btn btn-sm btn-light border ms-2">
                            <i class="bi bi-list me-1"></i>Voir tout
                        </a>
                     <?php $__env->endSlot(); ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="border-0">Salarié</th>
                                    <th class="border-0">Date</th>
                                    <th class="border-0">Entrée</th>
                                    <th class="border-0">Sortie</th>
                                    <th class="border-0">Heures</th>
                                    <th class="border-0">Statut</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $project->attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $att): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="fw-bold small"><?php echo e($att->employee->full_name ?? '—'); ?></td>
                                    <td class="text-muted small"><?php echo e($att->work_date->format('d/m/Y')); ?></td>
                                    <td class="text-muted small"><?php echo e($att->check_in ?? '—'); ?></td>
                                    <td class="text-muted small"><?php echo e($att->check_out ?? '—'); ?></td>
                                    <td class="fw-bold small"><?php echo e($att->hours_worked ? number_format($att->hours_worked, 1).'h' : '—'); ?></td>
                                    <td><span class="badge <?php echo e($att->status_badge_class); ?> px-2 py-1 rounded-pill" style="font-size:0.7rem"><?php echo e($att->status_libelle); ?></span></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="6" class="text-center py-5 text-muted">Aucun pointage.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
            </div>

            
            <div x-show="activeTab === 'quotes'" x-cloak x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform translate-y-2">
                <div class="row g-4">
                    <div class="col-md-6">
                        <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['title' => 'Devis associés','icon' => 'bi bi-file-earmark-text']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Devis associés','icon' => 'bi bi-file-earmark-text']); ?>
                             <?php $__env->slot('headerActions', null, []); ?> 
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('quotes.create')): ?>
                                <a href="<?php echo e(route('quotes.create', ['project_id' => $project->id])); ?>" class="btn btn-sm btn-light border shadow-sm-app">
                                    <i class="bi bi-plus-lg"></i>
                                </a>
                                <?php endif; ?>
                             <?php $__env->endSlot(); ?>
                            <div class="table-responsive">
                                <table class="table table-hover table-sm align-middle mb-0">
                                    <thead><tr><th>Réf</th><th>Total TTC</th><th>Statut</th></tr></thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $project->quotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><a href="<?php echo e(route('quotes.show', $quote)); ?>" class="font-monospace small text-decoration-none fw-bold text-primary"><?php echo e($quote->reference); ?></a></td>
                                            <td class="fw-bold small"><?php echo e(number_format($quote->total_ttc, 0, ',', ' ')); ?></td>
                                            <td><span class="badge-soft-secondary px-2 py-1 rounded-pill" style="font-size: 0.7rem"><?php echo e($quote->status); ?></span></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr><td colspan="3" class="text-center py-3 text-muted small">Aucun devis.</td></tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['title' => 'Factures émises','icon' => 'bi bi-file-earmark-check']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Factures émises','icon' => 'bi bi-file-earmark-check']); ?>
                            <div class="table-responsive">
                                <table class="table table-hover table-sm align-middle mb-0">
                                    <thead><tr><th>Réf</th><th>Total TTC</th><th>Statut</th></tr></thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $project->invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><a href="<?php echo e(route('invoices.show', $invoice)); ?>" class="font-monospace small text-decoration-none fw-bold text-info"><?php echo e($invoice->reference); ?></a></td>
                                            <td class="fw-bold small"><?php echo e(number_format($invoice->total_ttc, 0, ',', ' ')); ?></td>
                                            <td><span class="badge-soft-info px-2 py-1 rounded-pill" style="font-size: 0.7rem"><?php echo e($invoice->status); ?></span></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr><td colspan="3" class="text-center py-3 text-muted small">Aucune facture.</td></tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH /media/rado/New Volume/BuildFlow/resources/views/projects/show.blade.php ENDPATH**/ ?>